Version HTML/CSS/JS statique de l'application EdgeFlow.

- Logique de l'application conservée
- Dépendances chargées via CDN (React, Recharts, Lucide, Motion, Supabase...)
- Ouvrir via un petit serveur local ou héberger sur Netlify / GitHub Pages

Exemple local:
python -m http.server 8000
Puis ouvrir http://localhost:8000

Option Supabase : dans index.html, avant le script module, vous pouvez définir window.__EDGEFLOW_ENV avec VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY.
