import React, { useState, useEffect, useMemo } from 'react';
import { LayoutDashboard, Calendar as CalendarIcon, BookOpen, History, FlaskConical, Settings as SettingsIcon, LogOut, Moon, Sun, Plus, Search, User, TrendingUp, TrendingDown, Activity, ChevronRight, Filter, Download, MoreVertical, X, Trash2, Zap, Target, Brain, Shield, Image as ImageIcon, PieChart as PieChartIcon, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths, isSameMonth, startOfWeek, endOfWeek } from 'date-fns';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, Cell } from 'recharts';
import { translations } from './translations.js';
import { supabase } from './lib/supabase.js';
// Utility for tailwind classes
function cn(...inputs) {
    return twMerge(clsx(inputs));
}
// --- Components ---
const Badge = ({ children, className }) => (React.createElement("span", { className: cn("px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase", className) }, children));
const StatCard = ({ label, value, icon: Icon, trend, color }) => (React.createElement(motion.div, { whileHover: { y: -4 }, className: "card card-hover flex flex-col gap-4" },
    React.createElement("div", { className: "flex justify-between items-start" },
        React.createElement("div", { className: cn("p-3 rounded-xl bg-gradient-to-br opacity-80", color.replace('text-', 'from-').replace('text-', 'to-') + '/20') },
            React.createElement(Icon, { size: 20, className: color })),
        trend && (React.createElement("span", { className: cn("px-2 py-1 rounded-lg text-[10px] font-black flex items-center gap-1", trend > 0 ? "bg-[var(--ok)]/10 text-[var(--ok)]" : "bg-[var(--ko)]/10 text-[var(--ko)]") },
            trend > 0 ? React.createElement(TrendingUp, { size: 10 }) : React.createElement(TrendingDown, { size: 10 }),
            Math.abs(trend),
            "%"))),
    React.createElement("div", null,
        React.createElement("div", { className: "text-[var(--muted)] text-[10px] font-bold uppercase tracking-[0.1em] mb-1" }, label),
        React.createElement("div", { className: "text-3xl font-black tracking-tight text-gradient" }, value))));
// --- Views ---
const PropFirmTracker = ({ trades, balance }) => {
    const totalPnl = useMemo(() => trades.reduce((acc, t) => acc + t.pnl, 0), [trades]);
    const dailyPnl = useMemo(() => trades
        .filter(t => isSameDay(new Date(t.date), new Date()))
        .reduce((acc, t) => acc + t.pnl, 0), [trades]);
    // Mock targets for a 100k account
    const target = 10000;
    const dailyLimit = -5000;
    const maxLimit = -10000;
    const progress = useMemo(() => Math.min(Math.max((totalPnl / target) * 100, 0), 100), [totalPnl, target]);
    const dailyDrawdown = useMemo(() => Math.min(Math.max((dailyPnl / dailyLimit) * 100, 0), 100), [dailyPnl, dailyLimit]);
    const maxDrawdown = useMemo(() => Math.min(Math.max((totalPnl / maxLimit) * 100, 0), 100), [totalPnl, maxLimit]);
    const status = useMemo(() => totalPnl >= target ? 'PASSED' :
        (dailyPnl <= dailyLimit * 0.8 || totalPnl <= maxLimit * 0.8) ? 'CRITICAL' :
            (dailyPnl < 0 || totalPnl < 0) ? 'WARNING' : 'HEALTHY', [totalPnl, dailyPnl, target, dailyLimit, maxLimit]);
    return (React.createElement("div", { className: "card flex flex-col gap-4 bg-[var(--surface)] border-[var(--line)] relative overflow-hidden" },
        React.createElement("div", { className: "absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-transparent to-[var(--brand2)]/5 -mr-12 -mt-12 blur-2xl" }),
        React.createElement("div", { className: "flex items-center justify-between relative z-10" },
            React.createElement("div", { className: "flex items-center gap-2 text-[var(--brand2)]" },
                React.createElement(Activity, { size: 18 }),
                React.createElement("h3", { className: "font-bold text-sm uppercase tracking-widest" }, "Prop Firm Objectives")),
            React.createElement("div", { className: "flex items-center gap-2" },
                React.createElement(Badge, { className: cn("text-[8px] font-black px-2 py-0.5", status === 'PASSED' ? "bg-[var(--ok)]/20 text-[var(--ok)]" :
                        status === 'CRITICAL' ? "bg-[var(--ko)]/20 text-[var(--ko)]" :
                            status === 'WARNING' ? "bg-orange-500/20 text-orange-500" :
                                "bg-blue-500/20 text-blue-500") }, status),
                React.createElement(Badge, { className: "bg-[var(--brand2)]/10 text-[var(--brand2)] text-[8px] font-black px-2 py-0.5" }, "Phase 1"))),
        React.createElement("div", { className: "flex flex-col gap-4 relative z-10" },
            React.createElement("div", { className: "flex flex-col gap-1.5" },
                React.createElement("div", { className: "flex justify-between text-[10px] font-bold uppercase" },
                    React.createElement("span", { className: "text-[var(--muted)]" }, "Profit Target"),
                    React.createElement("span", null,
                        "$",
                        totalPnl.toFixed(0),
                        " / $",
                        target)),
                React.createElement("div", { className: "h-2 bg-[var(--line)] rounded-full overflow-hidden" },
                    React.createElement("div", { className: "h-full bg-[var(--brand)] transition-all duration-500", style: { width: `${progress}%` } }))),
            React.createElement("div", { className: "flex flex-col gap-1.5" },
                React.createElement("div", { className: "flex justify-between text-[10px] font-bold uppercase" },
                    React.createElement("span", { className: "text-[var(--muted)]" }, "Daily Loss Limit"),
                    React.createElement("span", { className: cn(dailyPnl < 0 ? "text-[var(--ko)]" : "text-[var(--ok)]") },
                        "$",
                        dailyPnl.toFixed(0),
                        " / $",
                        dailyLimit)),
                React.createElement("div", { className: "h-2 bg-[var(--line)] rounded-full overflow-hidden" },
                    React.createElement("div", { className: "h-full bg-[var(--ko)] transition-all duration-500", style: { width: `${dailyDrawdown}%` } }))),
            React.createElement("div", { className: "flex flex-col gap-1.5" },
                React.createElement("div", { className: "flex justify-between text-[10px] font-bold uppercase" },
                    React.createElement("span", { className: "text-[var(--muted)]" }, "Max Loss Limit"),
                    React.createElement("span", { className: cn(totalPnl < 0 ? "text-[var(--ko)]" : "text-[var(--ok)]") },
                        "$",
                        totalPnl.toFixed(0),
                        " / $",
                        maxLimit)),
                React.createElement("div", { className: "h-2 bg-[var(--line)] rounded-full overflow-hidden" },
                    React.createElement("div", { className: "h-full bg-[var(--ko)] transition-all duration-500", style: { width: `${maxDrawdown}%` } }))))));
};
const Dashboard = ({ trades, theme, onAddTrade, settings, setIsBrokerModalOpen, isSyncing, onSync, t }) => {
    const totalPnl = useMemo(() => trades.reduce((acc, t) => acc + t.pnl, 0), [trades]);
    const wins = useMemo(() => trades.filter(t => t.status === 'WIN'), [trades]);
    const losses = useMemo(() => trades.filter(t => t.status === 'LOSS'), [trades]);
    const winRate = useMemo(() => trades.length > 0 ? (wins.length / trades.length) * 100 : 0, [trades, wins]);
    const totalWinAmount = useMemo(() => wins.reduce((acc, t) => acc + t.pnl, 0), [wins]);
    const totalLossAmount = useMemo(() => Math.abs(losses.reduce((acc, t) => acc + t.pnl, 0)), [losses]);
    const profitFactor = useMemo(() => totalLossAmount > 0 ? totalWinAmount / totalLossAmount : totalWinAmount > 0 ? Infinity : 0, [totalWinAmount, totalLossAmount]);
    const avgWin = useMemo(() => wins.length > 0 ? totalWinAmount / wins.length : 0, [wins, totalWinAmount]);
    const avgLoss = useMemo(() => losses.length > 0 ? totalLossAmount / losses.length : 0, [losses, totalLossAmount]);
    const rrRatio = useMemo(() => avgLoss > 0 ? avgWin / avgLoss : 0, [avgWin, avgLoss]);
    const expectancy = useMemo(() => trades.length > 0 ? (totalPnl / trades.length) : 0, [trades, totalPnl]);
    // Advanced Stats
    const bestTrade = useMemo(() => trades.length > 0 ? Math.max(...trades.map(t => t.pnl)) : 0, [trades]);
    const worstTrade = useMemo(() => trades.length > 0 ? Math.min(...trades.map(t => t.pnl)) : 0, [trades]);
    // Calculate streaks
    const streaks = useMemo(() => {
        let maxWinStreak = 0;
        let maxLossStreak = 0;
        let tempStreak = 0;
        trades.slice().reverse().forEach(t => {
            if (t.status === 'WIN') {
                if (tempStreak > 0)
                    tempStreak++;
                else
                    tempStreak = 1;
                maxWinStreak = Math.max(maxWinStreak, tempStreak);
            }
            else if (t.status === 'LOSS') {
                if (tempStreak < 0)
                    tempStreak--;
                else
                    tempStreak = -1;
                maxLossStreak = Math.max(maxLossStreak, Math.abs(tempStreak));
            }
            else {
                tempStreak = 0;
            }
        });
        return { maxWinStreak, maxLossStreak };
    }, [trades]);
    // Prepare chart data
    const chartData = useMemo(() => {
        let cumulativePnl = 0;
        return trades.slice().reverse().map((t, i) => {
            cumulativePnl += t.pnl;
            return {
                name: i + 1,
                pnl: cumulativePnl,
                tradePnl: t.pnl
            };
        });
    }, [trades]);
    // Performance by Day of Week
    const pnlByDay = useMemo(() => {
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return days.map(day => {
            const dayTrades = trades.filter(t => format(new Date(t.date), 'EEEE') === day);
            return {
                day,
                pnl: dayTrades.reduce((acc, t) => acc + t.pnl, 0),
                count: dayTrades.length
            };
        });
    }, [trades]);
    // Performance by Setup
    const pnlBySetup = useMemo(() => {
        const setups = Array.from(new Set(trades.map(t => t.setup || 'Unknown')));
        return setups.map(setup => {
            const setupTrades = trades.filter(t => (t.setup || 'Unknown') === setup);
            return {
                setup,
                pnl: setupTrades.reduce((acc, t) => acc + t.pnl, 0),
                count: setupTrades.length,
                winRate: setupTrades.length > 0 ? (setupTrades.filter(t => t.status === 'WIN').length / setupTrades.length) * 100 : 0
            };
        });
    }, [trades]);
    // Performance by Asset
    const pnlByAsset = useMemo(() => {
        const assets = Array.from(new Set(trades.map(t => t.symbol)));
        return assets.map(asset => {
            const assetTrades = trades.filter(t => t.symbol === asset);
            return {
                asset,
                pnl: assetTrades.reduce((acc, t) => acc + t.pnl, 0),
                count: assetTrades.length,
                winRate: assetTrades.length > 0 ? (assetTrades.filter(t => t.status === 'WIN').length / assetTrades.length) * 100 : 0
            };
        }).sort((a, b) => b.pnl - a.pnl).slice(0, 5);
    }, [trades]);
    // Performance by Hour
    const pnlByHour = useMemo(() => {
        const hours = Array.from({ length: 24 }, (_, i) => i);
        return hours.map(hour => {
            const hourTrades = trades.filter(t => {
                const tradeHour = parseInt((t.entryTime || '00:00').split(':')[0]);
                return tradeHour === hour;
            });
            return {
                hour: `${hour}:00`,
                pnl: hourTrades.reduce((acc, t) => acc + t.pnl, 0),
                count: hourTrades.length
            };
        }).filter(h => h.count > 0);
    }, [trades]);
    // Performance by Session
    const pnlBySession = useMemo(() => {
        const getSession = (time) => {
            const hour = parseInt(time.split(':')[0]);
            if (hour >= 0 && hour < 8)
                return 'Asia';
            if (hour >= 8 && hour < 13)
                return 'London';
            if (hour >= 13 && hour < 21)
                return 'New York';
            return 'After Hours';
        };
        const sessions = ['Asia', 'London', 'New York', 'After Hours'];
        return sessions.map(session => {
            const sessionTrades = trades.filter(t => getSession(t.entryTime || '00:00') === session);
            return {
                session,
                pnl: sessionTrades.reduce((acc, t) => acc + t.pnl, 0),
                count: sessionTrades.length,
                winRate: sessionTrades.length > 0 ? (sessionTrades.filter(t => t.status === 'WIN').length / sessionTrades.length) * 100 : 0
            };
        });
    }, [trades]);
    // Best of Highlights
    const bestDay = useMemo(() => pnlByDay.reduce((prev, current) => (prev.pnl > current.pnl) ? prev : current, pnlByDay[0] || { day: 'N/A', pnl: 0 }), [pnlByDay]);
    const bestHour = useMemo(() => pnlByHour.reduce((prev, current) => (prev.pnl > current.pnl) ? prev : current, pnlByHour[0] || { hour: 'N/A', pnl: 0 }), [pnlByHour]);
    const bestPair = useMemo(() => pnlByAsset[0] || { asset: 'N/A', pnl: 0 }, [pnlByAsset]);
    const bestSession = useMemo(() => pnlBySession.reduce((prev, current) => (prev.pnl > current.pnl) ? prev : current, pnlBySession[0] || { session: 'N/A', pnl: 0 }), [pnlBySession]);
    const pnlByRating = useMemo(() => {
        const ratings = ['A+', 'A', 'B', 'C', 'D', 'F'];
        return ratings.map(rating => {
            const ratingTrades = trades.filter(t => t.rating === rating);
            return {
                rating,
                pnl: ratingTrades.reduce((acc, t) => acc + t.pnl, 0),
                count: ratingTrades.length,
                winRate: ratingTrades.length > 0 ? (ratingTrades.filter(t => t.status === 'WIN').length / ratingTrades.length) * 100 : 0
            };
        }).filter(r => r.count > 0);
    }, [trades]);
    if (trades.length === 0) {
        return (React.createElement("div", { className: "flex flex-col gap-12 py-12" },
            React.createElement("div", { className: "flex flex-col gap-6 max-w-2xl" },
                React.createElement(motion.div, { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, className: "flex items-center gap-3 px-4 py-2 rounded-full bg-[var(--brand)]/10 border border-[var(--brand)]/20 w-fit" },
                    React.createElement("span", { className: "w-2 h-2 rounded-full bg-[var(--brand)] animate-pulse" }),
                    React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--brand)]" }, "Welcome to EdgeFlow")),
                React.createElement(motion.h1, { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { delay: 0.1 }, className: "text-5xl lg:text-7xl font-black tracking-tighter leading-[0.9] text-white" },
                    t.yourEdge,
                    " ",
                    React.createElement("br", null),
                    React.createElement("span", { className: "text-gradient" }, t.quantified)),
                React.createElement(motion.p, { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { delay: 0.2 }, className: "text-lg text-[var(--muted)] max-w-lg" }, t.startDocumenting)),
            React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-8" }, [
                { title: t.journaling, desc: t.journalingDesc, icon: BookOpen, color: 'text-[var(--brand)]' },
                { title: t.analytics, desc: t.analyticsDesc, icon: Activity, color: 'text-[var(--brand2)]' },
                { title: t.backtesting, desc: t.backtestingDesc, icon: FlaskConical, color: 'text-[var(--ok)]' },
            ].map((feature, i) => (React.createElement(motion.div, { key: i, initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, transition: { delay: 0.3 + (i * 0.1) }, className: "card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-4 group hover:border-[var(--brand)]/30 transition-all" },
                React.createElement("div", { className: cn("w-12 h-12 rounded-2xl bg-[var(--bg)] flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform", feature.color) },
                    React.createElement(feature.icon, { size: 24 })),
                React.createElement("h3", { className: "text-xl font-black tracking-tight" }, feature.title),
                React.createElement("p", { className: "text-sm text-[var(--muted)] leading-relaxed" }, feature.desc))))),
            React.createElement(motion.div, { initial: { opacity: 0, scale: 0.95 }, animate: { opacity: 1, scale: 1 }, transition: { delay: 0.6 }, className: "card bg-gradient-to-br from-[var(--brand)]/20 to-[var(--brand2)]/20 border-[var(--brand)]/30 p-12 flex flex-col items-center text-center gap-8 relative overflow-hidden" },
                React.createElement("div", { className: "absolute top-0 right-0 w-64 h-64 bg-[var(--brand)]/10 blur-[100px] -mr-32 -mt-32" }),
                React.createElement("div", { className: "absolute bottom-0 left-0 w-64 h-64 bg-[var(--brand2)]/10 blur-[100px] -ml-32 -mb-32" }),
                React.createElement("div", { className: "flex flex-col gap-2 relative z-10" },
                    React.createElement("h2", { className: "text-3xl font-black tracking-tight" }, t.readyToStart),
                    React.createElement("p", { className: "text-[var(--muted)] font-bold uppercase tracking-widest text-xs" }, t.firstTradeWaiting)),
                React.createElement("button", { onClick: onAddTrade, className: "btn btn-primary py-5 px-12 rounded-2xl text-sm font-black uppercase tracking-[0.2em] relative z-10 shadow-2xl shadow-[var(--brand-glow)]" }, t.logFirstTrade))));
    }
    return (React.createElement("div", { className: "flex flex-col gap-10 pb-20" },
        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-6" },
            React.createElement("div", { className: "md:col-span-2 lg:col-span-2 card bg-gradient-to-br from-[var(--surface)] to-[var(--bg)] border-[var(--line)] p-10 flex flex-col justify-between relative overflow-hidden group min-h-[240px]" },
                React.createElement("div", { className: "absolute top-0 right-0 w-64 h-64 bg-[var(--brand)]/10 blur-[100px] -mr-32 -mt-32 group-hover:bg-[var(--brand)]/20 transition-all duration-700" }),
                React.createElement("div", { className: "flex items-center justify-between relative z-10" },
                    React.createElement("div", { className: "flex flex-col" },
                        React.createElement("span", { className: "text-[10px] font-black uppercase tracking-[0.3em] text-[var(--muted)]" }, t.netPerformance),
                        React.createElement("h2", { className: "text-sm font-bold text-white mt-1" }, t.totalProfit)),
                    React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)] shadow-inner" },
                        React.createElement(Activity, { size: 24 }))),
                React.createElement("div", { className: "flex flex-col relative z-10" },
                    React.createElement("span", { className: cn("text-6xl font-black tracking-tighter leading-none", totalPnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                        totalPnl >= 0 ? '+' : '',
                        totalPnl.toFixed(0),
                        React.createElement("span", { className: "text-2xl ml-1" }, "\u20AC")),
                    React.createElement("div", { className: "flex items-center gap-2 mt-4" },
                        React.createElement("div", { className: "flex items-center gap-1 px-2 py-1 rounded-lg bg-[var(--ok)]/10 text-[var(--ok)] text-[10px] font-black uppercase tracking-widest" },
                            React.createElement(TrendingUp, { size: 10 }),
                            " +12.4%"),
                        React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" }, t.vsLastMonth)))),
            React.createElement("div", { className: "md:col-span-2 lg:col-span-2 card bg-[var(--surface)] border-[var(--line)] p-10 flex flex-col justify-between relative overflow-hidden group min-h-[240px]" },
                React.createElement("div", { className: "absolute top-0 right-0 w-64 h-64 bg-[var(--ok)]/5 blur-[100px] -mr-32 -mt-32 group-hover:bg-[var(--ok)]/10 transition-all duration-700" }),
                React.createElement("div", { className: "flex items-center justify-between relative z-10" },
                    React.createElement("div", { className: "flex flex-col" },
                        React.createElement("span", { className: "text-[10px] font-black uppercase tracking-[0.3em] text-[var(--muted)]" }, t.successRate),
                        React.createElement("h2", { className: "text-sm font-bold text-white mt-1" }, t.winLossDist)),
                    React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--ok)]/10 flex items-center justify-center text-[var(--ok)] shadow-inner" },
                        React.createElement(Target, { size: 24 }))),
                React.createElement("div", { className: "flex items-end justify-between relative z-10" },
                    React.createElement("div", { className: "flex flex-col" },
                        React.createElement("span", { className: "text-6xl font-black tracking-tighter leading-none text-white" },
                            winRate.toFixed(0),
                            React.createElement("span", { className: "text-2xl ml-1" }, "%")),
                        React.createElement("div", { className: "flex items-center gap-3 mt-4" },
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-[var(--ok)]" }, t.wins),
                                React.createElement("span", { className: "text-sm font-black text-white" }, wins.length)),
                            React.createElement("div", { className: "w-[1px] h-6 bg-[var(--line)]" }),
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-[var(--ko)]" }, t.losses),
                                React.createElement("span", { className: "text-sm font-black text-white" }, losses.length)))),
                    React.createElement("div", { className: "relative w-24 h-24 flex items-center justify-center" },
                        React.createElement("svg", { className: "w-full h-full transform -rotate-90" },
                            React.createElement("circle", { cx: "48", cy: "48", r: "40", stroke: "var(--line)", strokeWidth: "8", fill: "transparent" }),
                            React.createElement("circle", { cx: "48", cy: "48", r: "40", stroke: "var(--ok)", strokeWidth: "8", fill: "transparent", strokeDasharray: 251.2, strokeDashoffset: 251.2 * (1 - winRate / 100), strokeLinecap: "round", className: "transition-all duration-1000" })),
                        React.createElement("div", { className: "absolute inset-0 flex items-center justify-center" },
                            React.createElement(Zap, { size: 20, className: "text-[var(--ok)]" }))))),
            React.createElement("div", { className: "md:col-span-2 lg:col-span-2 flex flex-col gap-6" },
                React.createElement("div", { className: "flex-1 card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col justify-between group overflow-hidden relative" },
                    React.createElement("div", { className: "absolute top-0 right-0 w-32 h-32 bg-[var(--brand)]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[var(--brand)]/10 transition-all" }),
                    React.createElement("div", { className: "flex justify-between items-start relative z-10" },
                        React.createElement("div", { className: "flex flex-col" },
                            React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.brokerStatus),
                            React.createElement("div", { className: "flex items-center gap-2 mt-1" },
                                React.createElement("span", { className: cn("text-xl font-black tracking-tighter", settings.broker?.status === 'CONNECTED' ? "text-[var(--ok)]" : "text-white") }, isSyncing ? t.syncing : settings.broker?.status === 'CONNECTED' ? `${t.connected}: ${settings.broker.provider}` : t.notConnected),
                                isSyncing && React.createElement(RefreshCw, { size: 14, className: "animate-spin text-[var(--brand)]" })),
                            settings.broker?.status === 'CONNECTED' && !isSyncing && (React.createElement("div", { className: "flex flex-col gap-0.5 mt-2" },
                                React.createElement("span", { className: "text-[10px] font-black text-white/80 tracking-tight" },
                                    "ID: ",
                                    settings.broker.id.substring(0, 8),
                                    "..."),
                                React.createElement("span", { className: "text-[10px] font-black text-[var(--ok)] tracking-tight" },
                                    "Balance: ",
                                    settings.balance.toLocaleString(),
                                    "\u20AC"))),
                            settings.broker?.lastSync && !isSyncing && (React.createElement("span", { className: "text-[8px] font-bold text-[var(--muted)] uppercase tracking-widest mt-2 block" },
                                t.lastSync,
                                ": ",
                                format(new Date(settings.broker.lastSync), 'HH:mm:ss')))),
                        React.createElement("div", { className: cn("w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-500", isSyncing ? "bg-[var(--brand)]/20 text-[var(--brand)] animate-pulse" :
                                settings.broker?.status === 'CONNECTED' ? "bg-[var(--ok)]/10 text-[var(--ok)]" : "bg-[var(--ko)]/10 text-[var(--ko)]") }, isSyncing ? React.createElement(RefreshCw, { size: 18, className: "animate-spin" }) :
                            settings.broker?.status === 'CONNECTED' ? React.createElement(Activity, { size: 18 }) : React.createElement(LogOut, { size: 18 }))),
                    React.createElement("div", { className: "flex gap-2 mt-4 relative z-10" },
                        React.createElement("button", { onClick: () => setIsBrokerModalOpen(true), disabled: isSyncing, className: "btn btn-primary py-2 px-4 text-[8px] font-black uppercase tracking-widest flex-1 disabled:opacity-50" }, settings.broker?.status === 'CONNECTED' ? t.manage : t.connect),
                        settings.broker?.status === 'CONNECTED' && (React.createElement("button", { onClick: onSync, disabled: isSyncing, className: "btn border-[var(--line)] py-2 px-4 text-[8px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:border-[var(--brand)] transition-all disabled:opacity-50" },
                            React.createElement(RefreshCw, { size: 10, className: cn(isSyncing && "animate-spin") }),
                            t.syncNow)))),
                React.createElement("div", { className: "flex-1 card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col justify-between group overflow-hidden relative" },
                    React.createElement("div", { className: "absolute top-0 right-0 w-32 h-32 bg-[var(--brand2)]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[var(--brand2)]/10 transition-all" }),
                    React.createElement("div", { className: "flex justify-between items-start relative z-10" },
                        React.createElement("div", { className: "flex flex-col" },
                            React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.profitFactor),
                            React.createElement("span", { className: "text-3xl font-black tracking-tighter text-white mt-1" }, profitFactor === Infinity ? '∞' : profitFactor.toFixed(2))),
                        React.createElement("div", { className: "w-10 h-10 rounded-xl bg-[var(--brand2)]/10 flex items-center justify-center text-[var(--brand2)]" },
                            React.createElement(Zap, { size: 18 }))),
                    React.createElement("div", { className: "h-1.5 bg-[var(--line)] rounded-full mt-4 overflow-hidden relative z-10" },
                        React.createElement("div", { className: "h-full bg-[var(--brand2)] transition-all duration-1000", style: { width: `${Math.min((profitFactor / 3) * 100, 100)}%` } }))))),
        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" },
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex items-center gap-4 group hover:border-[var(--brand)] transition-all" },
                React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]" },
                    React.createElement(CalendarIcon, { size: 20 })),
                React.createElement("div", { className: "flex flex-col" },
                    React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.bestDay),
                    React.createElement("span", { className: "text-sm font-black text-white" }, bestDay.day),
                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--ok)]" },
                        "+",
                        bestDay.pnl.toFixed(0),
                        "\u20AC"))),
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex items-center gap-4 group hover:border-[var(--brand2)] transition-all" },
                React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--brand2)]/10 flex items-center justify-center text-[var(--brand2)]" },
                    React.createElement(Activity, { size: 20 })),
                React.createElement("div", { className: "flex flex-col" },
                    React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.bestPair),
                    React.createElement("span", { className: "text-sm font-black text-white" }, bestPair.asset),
                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--ok)]" },
                        "+",
                        bestPair.pnl.toFixed(0),
                        "\u20AC"))),
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex items-center gap-4 group hover:border-[var(--ok)] transition-all" },
                React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--ok)]/10 flex items-center justify-center text-[var(--ok)]" },
                    React.createElement(TrendingUp, { size: 20 })),
                React.createElement("div", { className: "flex flex-col" },
                    React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.bestSession),
                    React.createElement("span", { className: "text-sm font-black text-white" }, bestSession.session),
                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--ok)]" },
                        "+",
                        bestSession.pnl.toFixed(0),
                        "\u20AC"))),
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex items-center gap-4 group hover:border-[var(--brand)] transition-all" },
                React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]" },
                    React.createElement(Zap, { size: 20 })),
                React.createElement("div", { className: "flex flex-col" },
                    React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.bestHour),
                    React.createElement("span", { className: "text-sm font-black text-white" }, bestHour.hour),
                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--ok)]" },
                        "+",
                        bestHour.pnl.toFixed(0),
                        "\u20AC")))),
        React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-10 flex flex-col gap-8" },
            React.createElement("div", { className: "flex justify-between items-center" },
                React.createElement("div", { className: "flex flex-col gap-1" },
                    React.createElement("h3", { className: "text-xl font-black tracking-tight" }, "Performance by Setup Rating"),
                    React.createElement("p", { className: "text-[var(--muted)] text-xs font-bold uppercase tracking-widest" }, "Analyze your edge based on trade quality")),
                React.createElement("div", { className: "p-3 rounded-xl bg-[var(--brand)]/10 text-[var(--brand)]" },
                    React.createElement(Brain, { size: 20 }))),
            React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" }, pnlByRating.map((r, i) => (React.createElement("div", { key: i, className: "p-6 rounded-3xl bg-[var(--bg)] border border-[var(--line)] flex flex-col gap-4 hover:border-[var(--brand)]/30 transition-all group" },
                React.createElement("div", { className: "flex justify-between items-center" },
                    React.createElement("div", { className: "flex items-center gap-3" },
                        React.createElement("div", { className: cn("w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm", r.rating === 'A+' || r.rating === 'A' ? "bg-[var(--ok)]/10 text-[var(--ok)]" :
                                r.rating === 'B' ? "bg-blue-500/10 text-blue-500" :
                                    "bg-[var(--ko)]/10 text-[var(--ko)]") }, r.rating),
                        React.createElement("div", { className: "flex flex-col" },
                            React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Rating"),
                            React.createElement("span", { className: "text-sm font-black text-white" },
                                r.count,
                                " Trades"))),
                    React.createElement("div", { className: "flex flex-col items-end" },
                        React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Win Rate"),
                        React.createElement("span", { className: "text-sm font-black text-[var(--ok)]" },
                            r.winRate.toFixed(0),
                            "%"))),
                React.createElement("div", { className: "flex justify-between items-end mt-2" },
                    React.createElement("div", { className: "flex flex-col" },
                        React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Net P&L"),
                        React.createElement("span", { className: cn("text-xl font-black tracking-tighter", r.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                            r.pnl >= 0 ? '+' : '',
                            r.pnl.toFixed(0),
                            "\u20AC")),
                    React.createElement("div", { className: "w-24 h-1 bg-[var(--line)] rounded-full overflow-hidden" },
                        React.createElement("div", { className: cn("h-full transition-all duration-1000", r.pnl >= 0 ? "bg-[var(--ok)]" : "bg-[var(--ko)]"), style: { width: `${Math.min(Math.abs(r.pnl) / 1000 * 100, 100)}%` } })))))))),
        React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-8" },
            React.createElement("div", { className: "lg:col-span-8 flex flex-col gap-8" },
                React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-10 flex flex-col gap-10 shadow-2xl relative overflow-hidden" },
                    React.createElement("div", { className: "absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[var(--brand)] via-[var(--brand2)] to-[var(--brand)] opacity-50" }),
                    React.createElement("div", { className: "flex justify-between items-end" },
                        React.createElement("div", { className: "flex flex-col gap-2" },
                            React.createElement("div", { className: "flex items-center gap-3" },
                                React.createElement("div", { className: "w-2 h-2 rounded-full bg-[var(--brand)] animate-pulse" }),
                                React.createElement("h3", { className: "font-black text-2xl tracking-tighter text-white" }, "Equity Curve")),
                            React.createElement("p", { className: "text-[var(--muted)] text-[10px] font-black uppercase tracking-[0.2em]" }, "Cumulative performance & drawdown analysis")),
                        React.createElement("div", { className: "flex items-center gap-4" },
                            React.createElement("div", { className: "flex flex-col items-end" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Current Drawdown"),
                                React.createElement("span", { className: "text-sm font-black text-[var(--ko)]" }, "-2.4%")),
                            React.createElement("div", { className: "h-8 w-[1px] bg-[var(--line)]" }),
                            React.createElement("div", { className: "flex gap-2" }, ['1W', '1M', '3M', 'ALL'].map((p) => (React.createElement("button", { key: p, className: cn("px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all", p === 'ALL' ? "bg-[var(--brand)] text-white shadow-lg shadow-[var(--brand-glow)]" : "bg-[var(--bg)] text-[var(--muted)] hover:text-white") }, p)))))),
                    React.createElement("div", { className: "h-[450px] w-full" },
                        React.createElement(ResponsiveContainer, { width: "100%", height: "100%" },
                            React.createElement(AreaChart, { data: chartData, margin: { top: 10, right: 10, left: 0, bottom: 0 } },
                                React.createElement("defs", null,
                                    React.createElement("linearGradient", { id: "colorPnl", x1: "0", y1: "0", x2: "0", y2: "1" },
                                        React.createElement("stop", { offset: "5%", stopColor: "var(--brand)", stopOpacity: 0.4 }),
                                        React.createElement("stop", { offset: "95%", stopColor: "var(--brand)", stopOpacity: 0 }))),
                                React.createElement(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--line)", vertical: false, opacity: 0.5 }),
                                React.createElement(XAxis, { dataKey: "name", stroke: "var(--muted)", fontSize: 10, tickLine: false, axisLine: false, tick: { fontWeight: 900 }, dy: 15 }),
                                React.createElement(YAxis, { stroke: "var(--muted)", fontSize: 10, tickLine: false, axisLine: false, tickFormatter: (value) => `${value}€`, tick: { fontWeight: 900 }, dx: -15 }),
                                React.createElement(Tooltip, { contentStyle: { backgroundColor: 'var(--surface)', border: '1px solid var(--line)', borderRadius: '24px', boxShadow: '0 30px 60px rgba(0,0,0,0.5)', padding: '24px', backdropFilter: 'blur(10px)' }, itemStyle: { color: 'var(--brand)', fontWeight: 900, fontSize: '18px' }, labelStyle: { color: 'var(--muted)', fontWeight: 900, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.2em', marginBottom: '8px' }, cursor: { stroke: 'var(--brand)', strokeWidth: 2, strokeDasharray: '5 5' } }),
                                React.createElement(Area, { type: "monotone", dataKey: "pnl", stroke: "var(--brand)", fillOpacity: 1, fill: "url(#colorPnl)", strokeWidth: 5, animationDuration: 2000, animationEasing: "ease-in-out" }))))),
                React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8" },
                    React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-8 group" },
                        React.createElement("div", { className: "flex justify-between items-center" },
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("h3", { className: "font-black text-lg tracking-tight text-white" }, "Daily Edge"),
                                React.createElement("p", { className: "text-[var(--muted)] text-[10px] font-black uppercase tracking-widest" }, "P&L distribution by weekday")),
                            React.createElement(CalendarIcon, { size: 18, className: "text-[var(--muted)] group-hover:text-[var(--brand)] transition-colors" })),
                        React.createElement("div", { className: "h-64 w-full" },
                            React.createElement(ResponsiveContainer, { width: "100%", height: "100%" },
                                React.createElement(BarChart, { data: pnlByDay },
                                    React.createElement(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--line)", vertical: false, opacity: 0.3 }),
                                    React.createElement(XAxis, { dataKey: "day", stroke: "var(--muted)", fontSize: 10, tickLine: false, axisLine: false, tickFormatter: (val) => val.substring(0, 3), tick: { fontWeight: 900 } }),
                                    React.createElement(YAxis, { hide: true }),
                                    React.createElement(Tooltip, { cursor: { fill: 'var(--line)', opacity: 0.2 }, contentStyle: { backgroundColor: 'var(--surface)', border: '1px solid var(--line)', borderRadius: '16px' } }),
                                    React.createElement(Bar, { dataKey: "pnl", radius: [6, 6, 0, 0] }, pnlByDay.map((entry, index) => (React.createElement(Cell, { key: `cell-${index}`, fill: entry.pnl >= 0 ? 'var(--ok)' : 'var(--ko)' })))))))),
                    React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-8 group" },
                        React.createElement("div", { className: "flex justify-between items-center" },
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("h3", { className: "font-black text-lg tracking-tight text-white" }, "Session Edge"),
                                React.createElement("p", { className: "text-[var(--muted)] text-[10px] font-black uppercase tracking-widest" }, "P&L distribution by trading session")),
                            React.createElement(Activity, { size: 18, className: "text-[var(--muted)] group-hover:text-[var(--brand)] transition-colors" })),
                        React.createElement("div", { className: "flex flex-col gap-5" }, pnlBySession.map((s, i) => (React.createElement("div", { key: i, className: "flex flex-col gap-2" },
                            React.createElement("div", { className: "flex justify-between items-center" },
                                React.createElement("div", { className: "flex items-center gap-2" },
                                    React.createElement("div", { className: cn("w-2 h-2 rounded-full", s.session === 'London' ? "bg-blue-400" : s.session === 'New York' ? "bg-orange-400" : "bg-purple-400") }),
                                    React.createElement("span", { className: "text-sm font-black text-white" }, s.session)),
                                React.createElement("span", { className: cn("text-xs font-black", s.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                                    s.pnl >= 0 ? '+' : '',
                                    s.pnl.toFixed(0),
                                    "\u20AC")),
                            React.createElement("div", { className: "h-1.5 bg-[var(--line)] rounded-full overflow-hidden" },
                                React.createElement("div", { className: cn("h-full transition-all duration-1000", s.pnl >= 0 ? "bg-[var(--ok)]" : "bg-[var(--ko)]"), style: { width: `${Math.max(Math.min((Math.abs(s.pnl) / (totalPnl || 1000)) * 100, 100), 5)}%` } }))))))),
                    React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-8 group" },
                        React.createElement("div", { className: "flex justify-between items-center" },
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("h3", { className: "font-black text-lg tracking-tight text-white" }, "Hourly Edge"),
                                React.createElement("p", { className: "text-[var(--muted)] text-[10px] font-black uppercase tracking-widest" }, "P&L distribution by entry hour")),
                            React.createElement(Activity, { size: 18, className: "text-[var(--muted)] group-hover:text-[var(--brand)] transition-colors" })),
                        React.createElement("div", { className: "h-64 w-full" },
                            React.createElement(ResponsiveContainer, { width: "100%", height: "100%" },
                                React.createElement(AreaChart, { data: pnlByHour },
                                    React.createElement(CartesianGrid, { strokeDasharray: "3 3", stroke: "var(--line)", vertical: false, opacity: 0.3 }),
                                    React.createElement(XAxis, { dataKey: "hour", stroke: "var(--muted)", fontSize: 10, tickLine: false, axisLine: false, tick: { fontWeight: 900 } }),
                                    React.createElement(YAxis, { hide: true }),
                                    React.createElement(Tooltip, { contentStyle: { backgroundColor: 'var(--surface)', border: '1px solid var(--line)', borderRadius: '16px' } }),
                                    React.createElement(Area, { type: "monotone", dataKey: "pnl", stroke: "var(--brand)", fill: "var(--brand)", fillOpacity: 0.1, strokeWidth: 3 }))))),
                    React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-8 group" },
                        React.createElement("div", { className: "flex justify-between items-center" },
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("h3", { className: "font-black text-lg tracking-tight text-white" }, "Top Assets"),
                                React.createElement("p", { className: "text-[var(--muted)] text-[10px] font-black uppercase tracking-widest" }, "Most profitable instruments")),
                            React.createElement(PieChartIcon, { size: 18, className: "text-[var(--muted)] group-hover:text-[var(--brand2)] transition-colors" })),
                        React.createElement("div", { className: "flex flex-col gap-5" }, pnlByAsset.map((a, i) => (React.createElement("div", { key: i, className: "flex items-center justify-between group/item" },
                            React.createElement("div", { className: "flex items-center gap-4" },
                                React.createElement("div", { className: "w-10 h-10 rounded-xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-center font-black text-xs text-white group-hover/item:border-[var(--brand)] transition-colors" }, a.asset.substring(0, 3)),
                                React.createElement("div", { className: "flex flex-col" },
                                    React.createElement("span", { className: "text-sm font-black text-white" }, a.asset),
                                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" },
                                        a.count,
                                        " Trades"))),
                            React.createElement("div", { className: "flex flex-col items-end" },
                                React.createElement("span", { className: cn("text-sm font-black", a.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                                    a.pnl >= 0 ? '+' : '',
                                    a.pnl.toFixed(0),
                                    "\u20AC"),
                                React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" },
                                    a.winRate.toFixed(0),
                                    "% WR"))))))))),
            React.createElement("div", { className: "lg:col-span-4 flex flex-col gap-8" },
                React.createElement(PropFirmTracker, { trades: trades, balance: 100000 }),
                React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-10 flex flex-col gap-8 shadow-2xl relative overflow-hidden group" },
                    React.createElement("div", { className: "absolute top-0 right-0 w-32 h-32 bg-[var(--brand)]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[var(--brand)]/10 transition-all" }),
                    React.createElement("div", { className: "flex flex-col" },
                        React.createElement("h3", { className: "font-black text-xl tracking-tighter text-white" }, "Performance DNA"),
                        React.createElement("p", { className: "text-[var(--muted)] text-[10px] font-black uppercase tracking-widest" }, "Your trading behavior quantified")),
                    React.createElement("div", { className: "flex flex-col gap-6" },
                        React.createElement("div", { className: "p-6 rounded-3xl bg-[var(--bg)]/50 border border-[var(--line)] flex flex-col gap-4 hover:border-[var(--brand)]/30 transition-all" },
                            React.createElement("div", { className: "flex justify-between items-center" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Risk/Reward Efficiency"),
                                React.createElement("div", { className: "px-2 py-1 rounded-lg bg-[var(--brand)]/10 text-[var(--brand)] text-[8px] font-black uppercase tracking-widest" },
                                    "1:",
                                    rrRatio.toFixed(2))),
                            React.createElement("div", { className: "flex items-end justify-between" },
                                React.createElement("div", { className: "flex flex-col" },
                                    React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-[var(--ok)]" }, "Avg Win"),
                                    React.createElement("span", { className: "text-2xl font-black text-white" },
                                        "+",
                                        avgWin.toFixed(0),
                                        "\u20AC")),
                                React.createElement("div", { className: "flex flex-col items-end" },
                                    React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-[var(--ko)]" }, "Avg Loss"),
                                    React.createElement("span", { className: "text-2xl font-black text-white" },
                                        "-",
                                        avgLoss.toFixed(0),
                                        "\u20AC"))),
                            React.createElement("div", { className: "h-1.5 bg-[var(--line)] rounded-full overflow-hidden flex" },
                                React.createElement("div", { className: "h-full bg-[var(--ok)]", style: { width: `${(avgWin / (avgWin + avgLoss)) * 100}%` } }),
                                React.createElement("div", { className: "h-full bg-[var(--ko)]", style: { width: `${(avgLoss / (avgWin + avgLoss)) * 100}%` } }))),
                        React.createElement("div", { className: "grid grid-cols-2 gap-6" },
                            React.createElement("div", { className: "p-6 rounded-3xl bg-[var(--bg)]/50 border border-[var(--line)] flex flex-col gap-2 hover:border-[var(--ok)]/30 transition-all" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Win Streak"),
                                React.createElement("div", { className: "flex items-baseline gap-2" },
                                    React.createElement("span", { className: "text-4xl font-black text-white" }, streaks.maxWinStreak),
                                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--ok)] uppercase tracking-widest" }, "Trades"))),
                            React.createElement("div", { className: "p-6 rounded-3xl bg-[var(--bg)]/50 border border-[var(--line)] flex flex-col gap-2 hover:border-[var(--ko)]/30 transition-all" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Loss Streak"),
                                React.createElement("div", { className: "flex items-baseline gap-2" },
                                    React.createElement("span", { className: "text-4xl font-black text-white" }, streaks.maxLossStreak),
                                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--ko)] uppercase tracking-widest" }, "Trades")))),
                        React.createElement("div", { className: "p-6 rounded-3xl bg-[var(--bg)]/50 border border-[var(--line)] flex flex-col gap-4 hover:border-[var(--brand2)]/30 transition-all" },
                            React.createElement("div", { className: "flex justify-between items-center" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Trade Extremes"),
                                React.createElement(Zap, { size: 14, className: "text-[var(--brand2)]" })),
                            React.createElement("div", { className: "flex flex-col gap-3" },
                                React.createElement("div", { className: "flex justify-between items-center" },
                                    React.createElement("span", { className: "text-xs font-bold text-[var(--muted)]" }, "Best Trade"),
                                    React.createElement("span", { className: "text-sm font-black text-[var(--ok)]" },
                                        "+",
                                        bestTrade.toFixed(0),
                                        "\u20AC")),
                                React.createElement("div", { className: "h-[1px] bg-[var(--line)]" }),
                                React.createElement("div", { className: "flex justify-between items-center" },
                                    React.createElement("span", { className: "text-xs font-bold text-[var(--muted)]" }, "Worst Trade"),
                                    React.createElement("span", { className: "text-sm font-black text-[var(--ko)]" },
                                        "-",
                                        Math.abs(worstTrade).toFixed(0),
                                        "\u20AC"))))))))));
};
const Calendar = ({ trades, t }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const startOfFirstWeek = startOfWeek(monthStart, { weekStartsOn: 1 });
    const endOfLastWeek = endOfWeek(monthEnd, { weekStartsOn: 1 });
    const allDays = eachDayOfInterval({ start: startOfFirstWeek, end: endOfLastWeek });
    const weeks = [];
    let currentWeek = [];
    allDays.forEach((day, i) => {
        currentWeek.push(day);
        if ((i + 1) % 7 === 0) {
            weeks.push(currentWeek);
            currentWeek = [];
        }
    });
    const getDayTrades = (day) => trades.filter(t => isSameDay(new Date(t.date), day));
    const totalMonthPnl = trades
        .filter(t => isSameMonth(new Date(t.date), currentDate))
        .reduce((acc, t) => acc + t.pnl, 0);
    return (React.createElement("div", { className: "flex flex-col gap-8" },
        React.createElement("div", { className: "flex flex-col gap-4" },
            React.createElement("div", { className: "flex justify-between items-center" },
                React.createElement("div", { className: "flex flex-col" },
                    React.createElement("h2", { className: "text-3xl font-black text-gradient" }, "Journal quotidien"),
                    React.createElement("div", { className: "text-sm font-bold text-[var(--muted)] uppercase tracking-widest" }, format(currentDate, 'MMMM yyyy'))),
                React.createElement("div", { className: "flex gap-2" },
                    React.createElement("button", { onClick: () => setCurrentDate(subMonths(currentDate, 1)), className: "btn p-3 rounded-xl" },
                        React.createElement(ChevronRight, { size: 18, className: "rotate-180" })),
                    React.createElement("button", { onClick: () => setCurrentDate(new Date()), className: "btn px-6 rounded-xl font-black text-xs uppercase tracking-widest" }, "Today"),
                    React.createElement("button", { onClick: () => setCurrentDate(addMonths(currentDate, 1)), className: "btn p-3 rounded-xl" },
                        React.createElement(ChevronRight, { size: 18 })))),
            React.createElement("div", { className: "flex items-center gap-4 p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                React.createElement("div", { className: "flex flex-col" },
                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" }, "Monthly Performance"),
                    React.createElement("span", { className: cn("text-xl font-black", totalMonthPnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                        totalMonthPnl >= 0 ? '+' : '',
                        totalMonthPnl.toFixed(2),
                        " \u20AC")),
                React.createElement("div", { className: "h-8 w-[1px] bg-[var(--line)]" }),
                React.createElement("div", { className: "flex flex-col" },
                    React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" }, "Trades"),
                    React.createElement("span", { className: "text-xl font-black" }, trades.filter(t => isSameMonth(new Date(t.date), currentDate)).length)))),
        React.createElement("div", { className: "flex flex-col gap-10" }, weeks.map((weekDays, wIdx) => {
            const weekPnl = weekDays.reduce((acc, day) => {
                return acc + getDayTrades(day).reduce((dAcc, t) => dAcc + t.pnl, 0);
            }, 0);
            return (React.createElement("div", { key: wIdx, className: "flex flex-col gap-4" },
                React.createElement("div", { className: "flex items-center gap-4" },
                    React.createElement("div", { className: "text-[10px] font-black text-[var(--muted)] uppercase tracking-[0.2em] whitespace-nowrap" },
                        "Week ",
                        wIdx + 1),
                    React.createElement("div", { className: "h-[1px] flex-1 bg-gradient-to-r from-[var(--line)] to-transparent" }),
                    React.createElement("div", { className: cn("text-[10px] font-black uppercase tracking-widest", weekPnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                        weekPnl >= 0 ? '+' : '',
                        weekPnl.toFixed(2),
                        " \u20AC")),
                React.createElement("div", { className: "grid grid-cols-7 gap-4" },
                    wIdx === 0 && ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(d => (React.createElement("div", { key: d, className: "text-center text-[var(--muted)] text-[10px] font-black uppercase tracking-[0.2em] py-2" }, d))),
                    weekDays.map(day => {
                        const dayTrades = getDayTrades(day);
                        const dailyPnl = dayTrades.reduce((acc, t) => acc + t.pnl, 0);
                        const isCurrentMonth = isSameMonth(day, currentDate);
                        return (React.createElement(motion.div, { key: day.toString(), whileHover: { y: -4 }, className: cn("bg-[var(--surface)] border border-[var(--line)] min-h-[160px] p-4 rounded-2xl flex flex-col gap-3 transition-all hover:border-[var(--brand)]/50 cursor-pointer group relative overflow-hidden", !isCurrentMonth && "opacity-20 grayscale", isSameDay(day, new Date()) && "ring-2 ring-[var(--brand)]/50 border-[var(--brand)]") },
                            isSameDay(day, new Date()) && (React.createElement("div", { className: "absolute top-0 right-0 w-12 h-12 bg-gradient-to-bl from-[var(--brand)]/20 to-transparent rounded-bl-full" })),
                            React.createElement("span", { className: "text-xs font-black text-[var(--muted)] group-hover:text-white transition-colors" }, format(day, 'dd')),
                            React.createElement("div", { className: "flex flex-col gap-1.5 mt-auto" },
                                dayTrades.slice(0, 3).map(t => (React.createElement("div", { key: t.id, className: cn("text-[9px] font-black px-2 py-1 rounded-lg flex justify-between items-center", t.pnl >= 0 ? "bg-[var(--ok)]/10 text-[var(--ok)]" : "bg-[var(--ko)]/10 text-[var(--ko)]") },
                                    React.createElement("span", null, t.symbol),
                                    React.createElement("span", null,
                                        t.pnl.toFixed(0),
                                        "\u20AC")))),
                                dayTrades.length > 3 && (React.createElement("div", { className: "text-[8px] font-bold text-[var(--muted)] text-center" },
                                    "+",
                                    dayTrades.length - 3,
                                    " more")),
                                dayTrades.length > 0 && (React.createElement("div", { className: cn("mt-2 pt-2 border-t border-[var(--line)] text-[11px] font-black text-right", dailyPnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                                    dailyPnl >= 0 ? '+' : '',
                                    dailyPnl.toFixed(2),
                                    "\u20AC")))));
                    }))));
        }))));
};
const TradesList = ({ trades, onDelete, onSelect, t }) => {
    const [search, setSearch] = useState('');
    const [statusFilter, setStatusFilter] = useState('ALL');
    const filteredTrades = trades.filter(t => {
        const matchesSearch = t.symbol.toLowerCase().includes(search.toLowerCase());
        const matchesStatus = statusFilter === 'ALL' || t.status === statusFilter;
        return matchesSearch && matchesStatus;
    });
    return (React.createElement("div", { className: "flex flex-col gap-8" },
        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6" },
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-2" },
                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Total Trades"),
                React.createElement("span", { className: "text-3xl font-black tracking-tight" }, trades.length)),
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-2" },
                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Win Rate"),
                React.createElement("span", { className: "text-3xl font-black tracking-tight text-[var(--ok)]" },
                    trades.length > 0 ? ((trades.filter(t => t.status === 'WIN').length / trades.length) * 100).toFixed(1) : 0,
                    "%")),
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-2" },
                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Net P&L"),
                React.createElement("span", { className: cn("text-3xl font-black tracking-tight", trades.reduce((acc, t) => acc + t.pnl, 0) >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                    trades.reduce((acc, t) => acc + t.pnl, 0).toFixed(2),
                    "\u20AC")),
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-2" },
                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Avg R"),
                React.createElement("span", { className: "text-3xl font-black tracking-tight" },
                    trades.length > 0 ? (trades.reduce((acc, t) => acc + (t.rMultiple || 0), 0) / trades.length).toFixed(2) : 0,
                    "R"))),
        React.createElement("div", { className: "card overflow-hidden p-0 flex flex-col border-[var(--line)] bg-[var(--surface)] shadow-xl" },
            React.createElement("div", { className: "p-8 border-b border-[var(--line)] flex flex-col md:flex-row justify-between items-center gap-6 bg-[var(--surface)]/50" },
                React.createElement("div", { className: "flex flex-col" },
                    React.createElement("h3", { className: "font-black text-xl tracking-tight" }, "Trading History"),
                    React.createElement("p", { className: "text-[var(--muted)] text-xs font-bold uppercase tracking-widest" }, "Detailed position logs")),
                React.createElement("div", { className: "flex gap-4 w-full md:w-auto" },
                    React.createElement("div", { className: "relative flex-1 md:w-80" },
                        React.createElement(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 text-[var(--muted)]", size: 18 }),
                        React.createElement("input", { type: "text", placeholder: "Search symbol, setup, notes...", value: search, onChange: (e) => setSearch(e.target.value), className: "input pl-12 w-full py-3 text-sm" })),
                    React.createElement("select", { value: statusFilter, onChange: (e) => setStatusFilter(e.target.value), className: "input w-40 py-3 text-sm font-bold" },
                        React.createElement("option", { value: "ALL" }, "All Status"),
                        React.createElement("option", { value: "WIN" }, "Wins (TP)"),
                        React.createElement("option", { value: "LOSS" }, "Losses (SL)"),
                        React.createElement("option", { value: "BREAKEVEN" }, "Breakeven"),
                        React.createElement("option", { value: "PENDING" }, "Pending")))),
            React.createElement("div", { className: "overflow-x-auto custom-scrollbar" },
                React.createElement("table", { className: "w-full text-left border-collapse" },
                    React.createElement("thead", null,
                        React.createElement("tr", { className: "bg-[var(--bg)]/50" },
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "Asset"),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "Type"),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "Status"),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "Rating"),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "Entry"),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "Exit"),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "P&L"),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "Date"),
                            React.createElement("th", { className: "p-6" }))),
                    React.createElement("tbody", null, filteredTrades.map(trade => (React.createElement("tr", { key: trade.id, onClick: () => onSelect(trade), className: "border-t border-[var(--line)] hover:bg-[var(--surface-hover)] transition-all group cursor-pointer" },
                        React.createElement("td", { className: "p-6" },
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("span", { className: "font-black text-white tracking-tight" }, trade.symbol),
                                React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" }, trade.setup || 'No Setup'))),
                        React.createElement("td", { className: "p-6" },
                            React.createElement("span", { className: cn("px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest", trade.type === 'BUY' ? "bg-[var(--ok)]/10 text-[var(--ok)]" : "bg-[var(--ko)]/10 text-[var(--ko)]") }, trade.type)),
                        React.createElement("td", { className: "p-6" },
                            React.createElement("div", { className: "flex items-center gap-2" },
                                React.createElement("div", { className: cn("w-2 h-2 rounded-full", trade.status === 'WIN' ? "bg-[var(--ok)] shadow-[0_0_8px_var(--ok)]" :
                                        trade.status === 'LOSS' ? "bg-[var(--ko)] shadow-[0_0_8px_var(--ko)]" :
                                            trade.status === 'BREAKEVEN' ? "bg-gray-400" : "bg-[var(--brand)] shadow-[0_0_8px_var(--brand)]") }),
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-white" }, trade.status))),
                        React.createElement("td", { className: "p-6" },
                            React.createElement("div", { className: cn("w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs", trade.rating === 'A+' || trade.rating === 'A' ? "bg-[var(--ok)]/10 text-[var(--ok)]" :
                                    trade.rating === 'B' ? "bg-blue-500/10 text-blue-500" :
                                        "bg-[var(--ko)]/10 text-[var(--ko)]") }, trade.rating || '-')),
                        React.createElement("td", { className: "p-6 font-mono text-xs font-bold text-[var(--muted)] group-hover:text-white transition-colors" }, trade.entryPrice.toFixed(5)),
                        React.createElement("td", { className: "p-6 font-mono text-xs font-bold text-[var(--muted)] group-hover:text-white transition-colors" }, trade.exitPrice?.toFixed(5) || '—'),
                        React.createElement("td", { className: "p-6" },
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("span", { className: cn("font-black tracking-tight", trade.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                                    trade.pnl >= 0 ? '+' : '',
                                    trade.pnl.toFixed(2),
                                    "\u20AC"),
                                React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" },
                                    trade.rMultiple,
                                    "R"))),
                        React.createElement("td", { className: "p-6" },
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("span", { className: "text-xs font-bold text-white" }, format(new Date(trade.date), 'MMM d, yyyy')),
                                React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" }, trade.entryTime))),
                        React.createElement("td", { className: "p-6 text-right" },
                            React.createElement("div", { className: "flex items-center justify-end gap-2" },
                                React.createElement("button", { onClick: (e) => { e.stopPropagation(); onDelete(trade.id); }, className: "p-2.5 rounded-xl text-[var(--muted)] hover:text-[var(--ko)] hover:bg-[var(--ko)]/10 opacity-0 group-hover:opacity-100 transition-all" },
                                    React.createElement(Trash2, { size: 18 })),
                                React.createElement(ChevronRight, { size: 18, className: "text-[var(--muted)] group-hover:translate-x-1 transition-transform" })))))))),
                filteredTrades.length === 0 && (React.createElement("div", { className: "flex flex-col items-center justify-center py-32 text-center px-6" },
                    React.createElement("div", { className: "w-20 h-20 rounded-3xl bg-[var(--line)]/20 flex items-center justify-center text-[var(--muted)] mb-6" },
                        React.createElement(History, { size: 40 })),
                    React.createElement("h3", { className: "text-xl font-black tracking-tight mb-2" }, "No positions found"),
                    React.createElement("p", { className: "text-[var(--muted)] text-sm max-w-xs" }, "Try adjusting your filters or search terms to find what you're looking for.")))))));
};
const BacktestingLab = ({ sessions, onAddSession, onDeleteSession, t }) => {
    const [isCreating, setIsCreating] = useState(false);
    const [activeSession, setActiveSession] = useState(null);
    const handleCreateSession = (e) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const newSession = {
            id: Math.random().toString(36).substr(2, 9),
            name: formData.get('name'),
            strategy: formData.get('strategy'),
            date: new Date().toISOString(),
            trades: [],
            initialBalance: Number(formData.get('balance')),
            currentBalance: Number(formData.get('balance')),
        };
        onAddSession(newSession);
        setIsCreating(false);
    };
    const handleAddTradeToSession = (e) => {
        e.preventDefault();
        if (!activeSession)
            return;
        const formData = new FormData(e.currentTarget);
        const pnl = Number(formData.get('pnl'));
        const newTrade = {
            id: Math.random().toString(36).substr(2, 9),
            symbol: formData.get('symbol'),
            type: formData.get('type'),
            status: formData.get('status'),
            entryPrice: Number(formData.get('entry')),
            exitPrice: Number(formData.get('exit')),
            pnl: pnl,
            date: new Date().toISOString(),
        };
        const updatedSession = {
            ...activeSession,
            trades: [newTrade, ...activeSession.trades],
            currentBalance: activeSession.currentBalance + pnl
        };
        setActiveSession(updatedSession);
        onAddSession(updatedSession); // This will update the existing session in parent state
    };
    if (activeSession) {
        return (React.createElement("div", { className: "flex flex-col gap-6" },
            React.createElement("div", { className: "flex justify-between items-center" },
                React.createElement("div", { className: "flex items-center gap-4" },
                    React.createElement("button", { onClick: () => setActiveSession(null), className: "btn p-2" },
                        React.createElement(TrendingDown, { size: 16, className: "rotate-90" })),
                    React.createElement("div", null,
                        React.createElement("h2", { className: "text-2xl font-black" }, activeSession.name),
                        React.createElement("p", { className: "text-[var(--muted)] text-xs uppercase font-bold tracking-widest" }, activeSession.strategy))),
                React.createElement("div", { className: "flex gap-4" },
                    React.createElement("div", { className: "text-right" },
                        React.createElement("div", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Current Balance"),
                        React.createElement("div", { className: "text-xl font-black text-[var(--brand)]" },
                            "$",
                            activeSession.currentBalance.toFixed(2))))),
            React.createElement("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6" },
                React.createElement("div", { className: "lg:col-span-1 flex flex-col gap-6" },
                    React.createElement("div", { className: "card flex flex-col gap-4" },
                        React.createElement("h3", { className: "font-bold text-lg" }, "Add Backtest Trade"),
                        React.createElement("form", { onSubmit: handleAddTradeToSession, className: "flex flex-col gap-4" },
                            React.createElement("div", { className: "grid grid-cols-2 gap-4" },
                                React.createElement("div", { className: "flex flex-col gap-1" },
                                    React.createElement("label", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Symbol"),
                                    React.createElement("input", { name: "symbol", placeholder: "EURUSD", className: "input", required: true })),
                                React.createElement("div", { className: "flex flex-col gap-1" },
                                    React.createElement("label", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Type"),
                                    React.createElement("select", { name: "type", className: "input" },
                                        React.createElement("option", { value: "BUY" }, "BUY"),
                                        React.createElement("option", { value: "SELL" }, "SELL")))),
                            React.createElement("div", { className: "grid grid-cols-2 gap-4" },
                                React.createElement("div", { className: "flex flex-col gap-1" },
                                    React.createElement("label", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Status"),
                                    React.createElement("select", { name: "status", className: "input" },
                                        React.createElement("option", { value: "WIN" }, "WIN"),
                                        React.createElement("option", { value: "LOSS" }, "LOSS"),
                                        React.createElement("option", { value: "BREAKEVEN" }, "BREAKEVEN"))),
                                React.createElement("div", { className: "flex flex-col gap-1" },
                                    React.createElement("label", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "P&L ($)"),
                                    React.createElement("input", { name: "pnl", type: "number", step: "0.01", placeholder: "50.00", className: "input", required: true }))),
                            React.createElement("button", { type: "submit", className: "btn btn-primary w-full" }, "Add Trade"))),
                    React.createElement("div", { className: "card flex flex-col gap-4" },
                        React.createElement("h3", { className: "font-bold text-lg" }, "Session Stats"),
                        React.createElement("div", { className: "flex flex-col gap-2" },
                            React.createElement("div", { className: "flex justify-between" },
                                React.createElement("span", { className: "text-[var(--muted)] text-sm" }, "Total Trades"),
                                React.createElement("span", { className: "font-bold" }, activeSession.trades.length)),
                            React.createElement("div", { className: "flex justify-between" },
                                React.createElement("span", { className: "text-[var(--muted)] text-sm" }, "Win Rate"),
                                React.createElement("span", { className: "font-bold" },
                                    activeSession.trades.length > 0
                                        ? ((activeSession.trades.filter(t => t.status === 'WIN').length / activeSession.trades.length) * 100).toFixed(1)
                                        : 0,
                                    "%")),
                            React.createElement("div", { className: "flex justify-between" },
                                React.createElement("span", { className: "text-[var(--muted)] text-sm" }, "Net Profit"),
                                React.createElement("span", { className: cn("font-bold", activeSession.currentBalance - activeSession.initialBalance >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                                    "$",
                                    (activeSession.currentBalance - activeSession.initialBalance).toFixed(2)))))),
                React.createElement("div", { className: "lg:col-span-2 card overflow-hidden p-0" },
                    React.createElement("div", { className: "p-4 border-b border-[var(--line)] flex justify-between items-center" },
                        React.createElement("h3", { className: "font-bold" }, "Session Trades"),
                        React.createElement("button", { className: "btn py-1 px-3 text-xs" },
                            React.createElement(Download, { size: 14 }),
                            " Export CSV")),
                    React.createElement("div", { className: "overflow-x-auto" },
                        React.createElement("table", { className: "w-full text-left border-collapse" },
                            React.createElement("thead", null,
                                React.createElement("tr", { className: "bg-[var(--line)]/30" },
                                    React.createElement("th", { className: "p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, "Symbol"),
                                    React.createElement("th", { className: "p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, "Type"),
                                    React.createElement("th", { className: "p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, "Status"),
                                    React.createElement("th", { className: "p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, "P&L"),
                                    React.createElement("th", { className: "p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, "Date"))),
                            React.createElement("tbody", null,
                                activeSession.trades.map(trade => (React.createElement("tr", { key: trade.id, className: "border-t border-[var(--line)] hover:bg-[var(--line)]/10 transition-colors" },
                                    React.createElement("td", { className: "p-3 font-bold text-sm" }, trade.symbol),
                                    React.createElement("td", { className: "p-3" },
                                        React.createElement(Badge, { className: "text-[8px]" }, trade.type)),
                                    React.createElement("td", { className: "p-3" },
                                        React.createElement(Badge, { className: cn("text-[8px]", trade.status === 'WIN' ? "bg-green-100 text-green-700" :
                                                trade.status === 'LOSS' ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700") }, trade.status)),
                                    React.createElement("td", { className: cn("p-3 font-black text-sm", trade.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                                        trade.pnl >= 0 ? '+' : '',
                                        trade.pnl.toFixed(2)),
                                    React.createElement("td", { className: "p-3 text-[var(--muted)] text-[10px]" }, format(new Date(trade.date), 'MMM d, HH:mm'))))),
                                activeSession.trades.length === 0 && (React.createElement("tr", null,
                                    React.createElement("td", { colSpan: 5, className: "p-10 text-center text-[var(--muted)] italic text-sm" }, "No trades in this session yet."))))))))));
    }
    return (React.createElement("div", { className: "flex flex-col gap-6" },
        React.createElement("div", { className: "flex justify-between items-center" },
            React.createElement("div", null,
                React.createElement("h2", { className: "text-2xl font-black tracking-tight" }, "Strategy Lab"),
                React.createElement("p", { className: "text-[var(--muted)] text-sm" }, "Test your edge against historical data.")),
            React.createElement("button", { onClick: () => setIsCreating(true), className: "btn btn-primary gap-2" },
                React.createElement(Plus, { size: 18 }),
                " New Session")),
        isCreating && (React.createElement(motion.div, { initial: { opacity: 0, y: 10 }, animate: { opacity: 1, y: 0 }, className: "card flex flex-col gap-4" },
            React.createElement("div", { className: "flex justify-between items-center" },
                React.createElement("h3", { className: "font-bold" }, "Create Backtest Session"),
                React.createElement("button", { onClick: () => setIsCreating(false), className: "text-[var(--muted)] hover:text-[var(--text)]" },
                    React.createElement(X, { size: 18 }))),
            React.createElement("form", { onSubmit: handleCreateSession, className: "grid grid-cols-1 md:grid-cols-3 gap-4" },
                React.createElement("div", { className: "flex flex-col gap-1" },
                    React.createElement("label", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Session Name"),
                    React.createElement("input", { name: "name", placeholder: "E.g. EURUSD Q1 2024", className: "input", required: true })),
                React.createElement("div", { className: "flex flex-col gap-1" },
                    React.createElement("label", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Strategy"),
                    React.createElement("input", { name: "strategy", placeholder: "E.g. SMC / ICT", className: "input", required: true })),
                React.createElement("div", { className: "flex flex-col gap-1" },
                    React.createElement("label", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Initial Balance ($)"),
                    React.createElement("input", { name: "balance", type: "number", defaultValue: "10000", className: "input", required: true })),
                React.createElement("div", { className: "md:col-span-3 flex gap-3 mt-2" },
                    React.createElement("button", { type: "button", onClick: () => setIsCreating(false), className: "btn flex-1" }, "Cancel"),
                    React.createElement("button", { type: "submit", className: "btn btn-primary flex-1" }, "Start Session"))))),
        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" },
            sessions.map(session => (React.createElement("div", { key: session.id, onClick: () => setActiveSession(session), className: "card hover:border-[var(--brand)] transition-all cursor-pointer group relative" },
                React.createElement("button", { onClick: (e) => { e.stopPropagation(); onDeleteSession(session.id); }, className: "absolute top-4 right-4 p-2 text-[var(--muted)] hover:text-[var(--ko)] opacity-0 group-hover:opacity-100 transition-all" },
                    React.createElement(X, { size: 16 })),
                React.createElement("div", { className: "flex flex-col gap-4" },
                    React.createElement("div", { className: "flex items-center gap-3" },
                        React.createElement("div", { className: "w-10 h-10 rounded-xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]" },
                            React.createElement(FlaskConical, { size: 20 })),
                        React.createElement("div", null,
                            React.createElement("h3", { className: "font-bold" }, session.name),
                            React.createElement("p", { className: "text-[var(--muted)] text-[10px] font-bold uppercase tracking-widest" }, session.strategy))),
                    React.createElement("div", { className: "grid grid-cols-2 gap-4 py-4 border-y border-[var(--line)]" },
                        React.createElement("div", null,
                            React.createElement("div", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Trades"),
                            React.createElement("div", { className: "text-lg font-black" }, session.trades.length)),
                        React.createElement("div", null,
                            React.createElement("div", { className: "text-[10px] font-bold text-[var(--muted)] uppercase" }, "Net P&L"),
                            React.createElement("div", { className: cn("text-lg font-black", session.currentBalance - session.initialBalance >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                                "$",
                                (session.currentBalance - session.initialBalance).toFixed(2)))),
                    React.createElement("div", { className: "flex justify-between items-center text-[10px] font-bold text-[var(--muted)] uppercase" },
                        React.createElement("span", null,
                            "Created ",
                            format(new Date(session.date), 'MMM d, yyyy')),
                        React.createElement("span", { className: "flex items-center gap-1 text-[var(--brand)]" },
                            "Open Session ",
                            React.createElement(ChevronRight, { size: 12 }))))))),
            sessions.length === 0 && !isCreating && (React.createElement("div", { className: "col-span-full card text-center py-20" },
                React.createElement(FlaskConical, { size: 48, className: "mx-auto text-[var(--muted)] mb-4" }),
                React.createElement("h3", { className: "text-xl font-bold" }, "No backtesting sessions"),
                React.createElement("p", { className: "text-[var(--muted)]" }, "Start a session to test your strategy on historical data."))))));
};
const Journal = ({ entries, onAdd, onDelete, t }) => {
    const [isAdding, setIsAdding] = useState(false);
    return (React.createElement("div", { className: "flex flex-col gap-6" },
        React.createElement("div", { className: "flex justify-between items-center" },
            React.createElement("h2", { className: "text-xl font-bold" }, "Daily Journal"),
            React.createElement("button", { onClick: () => setIsAdding(true), className: "btn btn-primary gap-2" },
                React.createElement(Plus, { size: 18 }),
                " New Entry")),
        isAdding && (React.createElement(motion.div, { initial: { opacity: 0, y: 10 }, animate: { opacity: 1, y: 0 }, className: "card flex flex-col gap-4" },
            React.createElement("div", { className: "flex justify-between items-center" },
                React.createElement("h3", { className: "font-bold tracking-tight" }, "New Journal Entry"),
                React.createElement("button", { onClick: () => setIsAdding(false), className: "text-[var(--muted)] hover:text-[var(--text)]" },
                    React.createElement(X, { size: 18 }))),
            React.createElement("form", { onSubmit: (e) => { e.preventDefault(); onAdd(e); setIsAdding(false); }, className: "flex flex-col gap-4" },
                React.createElement("div", { className: "flex gap-4" }, ['HAPPY', 'NEUTRAL', 'SAD'].map((mood) => (React.createElement("label", { key: mood, className: "flex-1 flex flex-col items-center gap-2 p-4 rounded-xl border border-[var(--line)] cursor-pointer hover:bg-[var(--line)]/30 transition-all has-[:checked]:ring-2 has-[:checked]:ring-[var(--brand)]" },
                    React.createElement("input", { type: "radio", name: "mood", value: mood, className: "hidden", defaultChecked: mood === 'HAPPY' }),
                    React.createElement("span", { className: "text-2xl" }, mood === 'HAPPY' ? '😊' : mood === 'NEUTRAL' ? '😐' : '😔'),
                    React.createElement("span", { className: "text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, mood))))),
                React.createElement("textarea", { name: "content", placeholder: "How was your trading day? What did you learn?", className: "input min-h-[150px]", required: true }),
                React.createElement("div", { className: "flex gap-3" },
                    React.createElement("button", { type: "button", onClick: () => setIsAdding(false), className: "btn flex-1" }, "Cancel"),
                    React.createElement("button", { type: "submit", className: "btn btn-primary flex-1" }, "Save Entry"))))),
        React.createElement("div", { className: "flex flex-col gap-4" },
            entries.map(entry => (React.createElement("div", { key: entry.id, className: "card flex flex-col gap-3 group" },
                React.createElement("div", { className: "flex justify-between items-start" },
                    React.createElement("div", { className: "flex items-center gap-3" },
                        React.createElement("span", { className: "text-xl" }, entry.mood === 'HAPPY' ? '😊' : entry.mood === 'NEUTRAL' ? '😐' : '😔'),
                        React.createElement("div", null,
                            React.createElement("div", { className: "font-bold text-sm" }, format(new Date(entry.date), 'EEEE, MMMM d')),
                            React.createElement("div", { className: "text-[var(--muted)] text-[10px] uppercase font-bold tracking-widest" }, format(new Date(entry.date), 'HH:mm')))),
                    React.createElement("button", { onClick: () => onDelete(entry.id), className: "p-2 text-[var(--muted)] hover:text-[var(--ko)] opacity-0 group-hover:opacity-100 transition-all" },
                        React.createElement(X, { size: 16 }))),
                React.createElement("p", { className: "text-sm text-[var(--text)]/80 leading-relaxed whitespace-pre-wrap" }, entry.content)))),
            entries.length === 0 && !isAdding && (React.createElement("div", { className: "card text-center py-20" },
                React.createElement(BookOpen, { size: 48, className: "mx-auto text-[var(--muted)] mb-4" }),
                React.createElement("h3", { className: "text-xl font-bold" }, "No entries yet"),
                React.createElement("p", { className: "text-[var(--muted)]" }, "Start documenting your trading journey to improve your psychology."))))));
};
const Settings = ({ settings, onUpdate, setIsBrokerModalOpen, t, onExportBackup, onImportBackup }) => {
    return (React.createElement("div", { className: "flex flex-col gap-6 max-w-2xl" },
        React.createElement("div", null,
            React.createElement("h2", { className: "text-2xl font-black tracking-tight" }, "App Settings"),
            React.createElement("p", { className: "text-[var(--muted)] text-sm" }, "Configure your trading environment.")),
        React.createElement("div", { className: "card flex flex-col gap-6" },
            React.createElement("div", { className: "flex flex-col gap-2" },
                React.createElement("label", { className: "text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, "Account Currency"),
                React.createElement("select", { value: settings.currency, onChange: (e) => onUpdate({ ...settings, currency: e.target.value }), className: "input" },
                    React.createElement("option", { value: "USD" }, "USD ($)"),
                    React.createElement("option", { value: "EUR" }, "EUR (\u20AC)"),
                    React.createElement("option", { value: "GBP" }, "GBP (\u00A3)"),
                    React.createElement("option", { value: "JPY" }, "JPY (\u00A5)"))),
            React.createElement("div", { className: "flex flex-col gap-2" },
                React.createElement("label", { className: "text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, "Initial Balance"),
                React.createElement("input", { type: "number", value: settings.balance, onChange: (e) => onUpdate({ ...settings, balance: Number(e.target.value) }), className: "input" })),
            React.createElement("div", { className: "flex flex-col gap-2" },
                React.createElement("label", { className: "text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, "Broker Connection"),
                React.createElement("div", { className: "p-6 rounded-2xl bg-[var(--bg)] border border-[var(--line)] flex flex-col gap-4" }, settings.broker ? (React.createElement("div", { className: "flex items-center justify-between" },
                    React.createElement("div", { className: "flex items-center gap-4" },
                        React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--ok)]/10 border border-[var(--ok)]/20 flex items-center justify-center text-[var(--ok)]" },
                            React.createElement(Activity, { size: 24 })),
                        React.createElement("div", { className: "flex flex-col" },
                            React.createElement("span", { className: "text-sm font-black text-white" }, settings.broker.provider),
                            React.createElement("span", { className: "text-[10px] font-bold text-[var(--ok)] uppercase tracking-widest" }, "Connected"),
                            settings.broker.lastSync && (React.createElement("span", { className: "text-[8px] font-bold text-[var(--muted)] uppercase tracking-widest mt-0.5" },
                                "Last sync: ",
                                format(new Date(settings.broker.lastSync), 'yyyy-MM-dd HH:mm'))))),
                    React.createElement("button", { onClick: () => onUpdate({ ...settings, broker: undefined }), className: "btn border-[var(--ko)] text-[var(--ko)] hover:bg-[var(--ko)] hover:text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest" }, "Disconnect"))) : (React.createElement(React.Fragment, null,
                    React.createElement("div", { className: "flex items-center justify-between" },
                        React.createElement("div", { className: "flex items-center gap-4" },
                            React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-center text-[var(--muted)]" },
                                React.createElement(Activity, { size: 24 })),
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("span", { className: "text-sm font-black text-white" }, "MetaTrader 4/5"),
                                React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" }, "Not Connected"))),
                        React.createElement("button", { onClick: () => setIsBrokerModalOpen(true), className: "btn btn-primary px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest" }, "Connect")),
                    React.createElement("div", { className: "h-[1px] bg-[var(--line)]" }),
                    React.createElement("div", { className: "flex items-center justify-between" },
                        React.createElement("div", { className: "flex items-center gap-4" },
                            React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-center text-[var(--muted)]" },
                                React.createElement(Activity, { size: 24 })),
                            React.createElement("div", { className: "flex flex-col" },
                                React.createElement("span", { className: "text-sm font-black text-white" }, "Interactive Brokers"),
                                React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest" }, "Not Connected"))),
                        React.createElement("button", { onClick: () => setIsBrokerModalOpen(true), className: "btn btn-primary px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest" }, "Connect")))))),
            React.createElement("div", { className: "flex flex-col gap-2" },
                React.createElement("label", { className: "text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, t.theme),
                React.createElement("div", { className: "flex gap-4" },
                    React.createElement("button", { onClick: () => onUpdate({ ...settings, theme: 'light' }), className: cn("flex-1 btn gap-2", settings.theme === 'light' && "bg-[var(--brand)] text-white border-none") },
                        React.createElement(Sun, { size: 16 }),
                        " Light"),
                    React.createElement("button", { onClick: () => onUpdate({ ...settings, theme: 'dark' }), className: cn("flex-1 btn gap-2", settings.theme === 'dark' && "bg-[var(--brand)] text-white border-none") },
                        React.createElement(Moon, { size: 16 }),
                        " Dark"))),
            React.createElement("div", { className: "flex flex-col gap-2" },
                React.createElement("label", { className: "text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, t.language),
                React.createElement("div", { className: "flex gap-4" },
                    React.createElement("button", { onClick: () => onUpdate({ ...settings, language: 'en' }), className: cn("flex-1 btn gap-2", settings.language === 'en' && "bg-[var(--brand)] text-white border-none") }, "English"),
                    React.createElement("button", { onClick: () => onUpdate({ ...settings, language: 'fr' }), className: cn("flex-1 btn gap-2", settings.language === 'fr' && "bg-[var(--brand)] text-white border-none") }, "Fran\u00E7ais")))),
        React.createElement("div", { className: "card flex flex-col gap-6" },
            React.createElement("div", { className: "flex flex-col gap-1" },
                React.createElement("h3", { className: "text-lg font-black tracking-tight" }, t.backupData),
                React.createElement("p", { className: "text-xs text-[var(--muted)]" }, t.backupDesc)),
            React.createElement("div", { className: "flex gap-4" },
                React.createElement("button", { onClick: onExportBackup, className: "flex-1 btn btn-primary gap-2" },
                    React.createElement(Download, { size: 16 }),
                    " ",
                    t.exportJson),
                React.createElement("label", { className: "flex-1 btn gap-2 cursor-pointer" },
                    React.createElement(RefreshCw, { size: 16 }),
                    " ",
                    t.importJson,
                    React.createElement("input", { type: "file", accept: ".json", className: "hidden", onChange: onImportBackup })))),
        React.createElement("div", { className: "card border-[var(--ko)]/20 bg-[var(--ko)]/5" },
            React.createElement("h3", { className: "text-[var(--ko)] font-bold mb-2" }, t.dangerZone),
            React.createElement("p", { className: "text-xs text-[var(--muted)] mb-4" }, "Deleting your data is permanent and cannot be undone."),
            React.createElement("button", { onClick: () => {
                    if (confirm('Are you sure you want to delete all your data?')) {
                        localStorage.clear();
                        window.location.reload();
                    }
                }, className: "btn border-[var(--ko)] text-[var(--ko)] hover:bg-[var(--ko)] hover:text-white" }, t.resetData))));
};
const TradeDrawer = ({ trade, onClose, theme, onUpdate, t }) => {
    const [notes, setNotes] = useState(trade?.notes || '');
    const [screenshot, setScreenshot] = useState(trade?.screenshotUrl || '');
    const [rating, setRating] = useState(trade?.rating);
    useEffect(() => {
        if (trade) {
            setNotes(trade.notes || '');
            setScreenshot(trade.screenshotUrl || '');
            setRating(trade.rating);
        }
    }, [trade]);
    const handleSave = () => {
        if (trade) {
            onUpdate({ ...trade, notes, screenshotUrl: screenshot, rating });
        }
    };
    return (React.createElement(AnimatePresence, null, trade && (React.createElement(React.Fragment, null,
        React.createElement(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, onClick: onClose, className: "fixed inset-0 bg-black/60 backdrop-blur-md z-[60]" }),
        React.createElement(motion.div, { id: "trade-drawer-content", initial: { x: '100%' }, animate: { x: 0 }, exit: { x: '100%' }, transition: { type: 'spring', damping: 30, stiffness: 300 }, className: "fixed right-0 top-0 h-full w-full max-w-2xl bg-[var(--bg)] shadow-2xl z-[70] flex flex-col border-l border-[var(--line)] overflow-hidden" },
            React.createElement("div", { className: "p-8 border-b border-[var(--line)] flex justify-between items-center bg-[var(--surface)]/50 backdrop-blur-xl" },
                React.createElement("div", { className: "flex items-center gap-4" },
                    React.createElement("div", { className: cn("w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg", trade.status === 'WIN' ? "bg-[var(--ok)]/20 text-[var(--ok)]" :
                            trade.status === 'LOSS' ? "bg-[var(--ko)]/20 text-[var(--ko)]" : "bg-[var(--brand)]/20 text-[var(--brand)]") },
                        React.createElement(Activity, { size: 24 })),
                    React.createElement("div", { className: "flex flex-col" },
                        React.createElement("h2", { className: "text-2xl font-black tracking-tighter text-white" },
                            trade.symbol,
                            " Position"),
                        React.createElement("p", { className: "text-[var(--muted)] text-[10px] font-bold uppercase tracking-widest flex items-center gap-2" },
                            format(new Date(trade.date), 'MMMM d, yyyy'),
                            " ",
                            React.createElement("span", { className: "w-1 h-1 rounded-full bg-[var(--line)]" }),
                            " ",
                            trade.entryTime))),
                React.createElement("button", { onClick: onClose, className: "p-3 rounded-2xl bg-[var(--line)]/50 hover:bg-[var(--line)] text-[var(--muted)] hover:text-white transition-all" },
                    React.createElement(X, { size: 20 }))),
            React.createElement("div", { className: "flex-1 overflow-y-auto custom-scrollbar p-8" },
                React.createElement("div", { className: "flex flex-col gap-10" },
                    React.createElement("div", { className: "grid grid-cols-3 gap-6" },
                        React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-1" },
                            React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Result"),
                            React.createElement("span", { className: cn("text-2xl font-black tracking-tight", trade.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]") },
                                trade.pnl >= 0 ? '+' : '',
                                trade.pnl.toFixed(2),
                                "\u20AC")),
                        React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-1" },
                            React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "R-Multiple"),
                            React.createElement("span", { className: "text-2xl font-black tracking-tight text-white" },
                                trade.rMultiple,
                                "R")),
                        React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-1" },
                            React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Risk"),
                            React.createElement("span", { className: "text-2xl font-black tracking-tight text-white" },
                                trade.riskPercent,
                                "%"))),
                    React.createElement("div", { className: "flex flex-col gap-4" },
                        React.createElement("h3", { className: "text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2" },
                            React.createElement(History, { size: 14 }),
                            " Trade Lifecycle"),
                        React.createElement("div", { className: "relative p-8 rounded-3xl bg-[var(--surface)] border border-[var(--line)] flex flex-col gap-10 overflow-hidden group" },
                            React.createElement("div", { className: "absolute top-0 right-0 w-32 h-32 bg-[var(--brand)]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[var(--brand)]/10 transition-all" }),
                            React.createElement("div", { className: "relative flex items-center justify-between" },
                                React.createElement("div", { className: "absolute left-0 right-0 h-1 bg-[var(--line)] z-0" }),
                                React.createElement("div", { className: cn("absolute left-0 h-1 z-10 transition-all duration-1000", trade.status === 'WIN' ? "bg-[var(--ok)]" : trade.status === 'LOSS' ? "bg-[var(--ko)]" : "bg-[var(--brand)]"), style: { width: trade.exitPrice ? '100%' : '50%' } }),
                                React.createElement("div", { className: "relative z-20 flex flex-col items-center gap-2" },
                                    React.createElement("div", { className: "w-4 h-4 rounded-full bg-[var(--brand)] border-4 border-[var(--bg)] shadow-[0_0_10px_var(--brand)]" }),
                                    React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-white" }, "Entry")),
                                React.createElement("div", { className: "relative z-20 flex flex-col items-center gap-2" },
                                    React.createElement("div", { className: cn("w-4 h-4 rounded-full border-4 border-[var(--bg)]", trade.exitPrice ? (trade.status === 'WIN' ? "bg-[var(--ok)] shadow-[0_0_10px_var(--ok)]" : "bg-[var(--ko)] shadow-[0_0_10px_var(--ko)]") : "bg-[var(--line)]") }),
                                    React.createElement("span", { className: "text-[8px] font-black uppercase tracking-widest text-white" }, "Exit"))),
                            React.createElement("div", { className: "grid grid-cols-2 gap-8" },
                                React.createElement("div", { className: "flex flex-col gap-1" },
                                    React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Duration"),
                                    React.createElement("span", { className: "text-sm font-black text-white" }, "4h 22m")),
                                React.createElement("div", { className: "flex flex-col gap-1 text-right" },
                                    React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Holding Time"),
                                    React.createElement("span", { className: "text-sm font-black text-white" }, "Intraday"))))),
                    React.createElement("div", { className: "flex flex-col gap-4" },
                        React.createElement("h3", { className: "text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2" },
                            React.createElement(Target, { size: 14 }),
                            " Execution Details"),
                        React.createElement("div", { className: "grid grid-cols-2 gap-4" },
                            React.createElement("div", { className: "flex justify-between items-center p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                                React.createElement("span", { className: "text-sm font-bold text-[var(--muted)]" }, "Entry Price"),
                                React.createElement("span", { className: "font-mono font-black text-white" }, trade.entryPrice.toFixed(5))),
                            React.createElement("div", { className: "flex justify-between items-center p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                                React.createElement("span", { className: "text-sm font-bold text-[var(--muted)]" }, "Exit Price"),
                                React.createElement("span", { className: "font-mono font-black text-white" }, trade.exitPrice?.toFixed(5) || '—')),
                            React.createElement("div", { className: "flex justify-between items-center p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                                React.createElement("span", { className: "text-sm font-bold text-[var(--muted)]" }, "Stop Loss"),
                                React.createElement("span", { className: "font-mono font-black text-[var(--ko)]" }, trade.stopLoss?.toFixed(5) || '—')),
                            React.createElement("div", { className: "flex justify-between items-center p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                                React.createElement("span", { className: "text-sm font-bold text-[var(--muted)]" }, "Take Profit"),
                                React.createElement("span", { className: "font-mono font-black text-[var(--ok)]" }, trade.takeProfit?.toFixed(5) || '—')))),
                    React.createElement("div", { className: "flex flex-col gap-4" },
                        React.createElement("h3", { className: "text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2" },
                            React.createElement(Brain, { size: 14 }),
                            " Psychology & Context"),
                        React.createElement("div", { className: "grid grid-cols-2 gap-4" },
                            React.createElement("div", { className: "flex flex-col gap-2 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Emotion Before"),
                                React.createElement("span", { className: "text-sm font-black text-white" }, trade.emotionBefore || 'Not recorded')),
                            React.createElement("div", { className: "flex flex-col gap-2 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Emotion After"),
                                React.createElement("span", { className: "text-sm font-black text-white" }, trade.emotionAfter || 'Not recorded'))),
                        React.createElement("div", { className: "grid grid-cols-2 gap-4" },
                            React.createElement("div", { className: "flex flex-col gap-2 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Setup / Strategy"),
                                React.createElement("span", { className: "text-sm font-black text-white" }, trade.setup || 'No setup specified')),
                            React.createElement("div", { className: "flex flex-col gap-2 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)]" },
                                React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Trade Rating"),
                                React.createElement("select", { value: rating || '', onChange: (e) => setRating(e.target.value), className: "bg-transparent text-sm font-black text-white outline-none" },
                                    React.createElement("option", { value: "", className: "bg-[var(--surface)]" }, "No Rating"),
                                    React.createElement("option", { value: "A+", className: "bg-[var(--surface)]" }, "A+"),
                                    React.createElement("option", { value: "A", className: "bg-[var(--surface)]" }, "A"),
                                    React.createElement("option", { value: "B", className: "bg-[var(--surface)]" }, "B"),
                                    React.createElement("option", { value: "C", className: "bg-[var(--surface)]" }, "C"),
                                    React.createElement("option", { value: "D", className: "bg-[var(--surface)]" }, "D"),
                                    React.createElement("option", { value: "F", className: "bg-[var(--surface)]" }, "F"))))),
                    React.createElement("div", { className: "flex flex-col gap-4" },
                        React.createElement("h3", { className: "text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2" },
                            React.createElement(ImageIcon, { size: 14 }),
                            " Visual Evidence"),
                        React.createElement("div", { className: "flex flex-col gap-4" },
                            React.createElement("div", { className: "h-[300px] w-full rounded-3xl overflow-hidden border border-[var(--line)] shadow-2xl" },
                                React.createElement("iframe", { src: `https://s.tradingview.com/widgetembed/?frameElementId=tradingview_76d87&symbol=${trade.symbol.includes('/') ? trade.symbol.replace('/', '') : trade.symbol}&interval=D&hidesidetoolbar=1&hidetoptoolbar=1&symboledit=1&saveimage=1&toolbarbg=f1f3f6&studies=%5B%5D&theme=${theme}&style=1&timezone=Etc%2FUTC&studies_overrides=%7B%7D&overrides=%7B%7D&enabled_features=%5B%5D&disabled_features=%5B%5D&locale=en&utm_source=edgeflow&utm_medium=widget&utm_campaign=chart&utm_term=${trade.symbol}`, width: "100%", height: "100%", frameBorder: "0", scrolling: "no", allowFullScreen: true })),
                            React.createElement("div", { className: "flex flex-col gap-3" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, "Screenshot URL"),
                                React.createElement("input", { type: "text", value: screenshot, onChange: (e) => setScreenshot(e.target.value), placeholder: "https://tradingview.com/x/...", className: "input" }),
                                screenshot && (React.createElement(motion.img, { initial: { opacity: 0, scale: 0.95 }, animate: { opacity: 1, scale: 1 }, src: screenshot, alt: "Trade Screenshot", className: "rounded-3xl border border-[var(--line)] w-full shadow-2xl", referrerPolicy: "no-referrer" }))))),
                    React.createElement("div", { className: "flex flex-col gap-4" },
                        React.createElement("h3", { className: "text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2" },
                            React.createElement(BookOpen, { size: 14 }),
                            " Trade Journal"),
                        React.createElement("textarea", { value: notes, onChange: (e) => setNotes(e.target.value), placeholder: "Describe your setup, emotions, and mistakes...", className: "input min-h-[200px] py-6 leading-relaxed text-base" })))),
            React.createElement("div", { className: "p-8 border-t border-[var(--line)] bg-[var(--surface)]/50 backdrop-blur-xl flex gap-4" },
                React.createElement("button", { onClick: async () => {
                        const element = document.getElementById('trade-drawer-content');
                        if (!element)
                            return;
                        const canvas = await html2canvas(element, { scale: 2, backgroundColor: theme === 'dark' ? '#05070a' : '#ffffff' });
                        const link = document.createElement('a');
                        link.download = `edgeflow-trade-${trade.symbol}-${trade.id}.png`;
                        link.href = canvas.toDataURL();
                        link.click();
                    }, className: "btn flex-1 gap-3 py-4 rounded-2xl font-black uppercase tracking-widest text-xs" },
                    React.createElement(Download, { size: 16 }),
                    " Export Position"),
                React.createElement("button", { onClick: handleSave, className: "btn btn-primary flex-1 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl shadow-[var(--brand-glow)]" }, "Save Changes")))))));
};
// --- Main App ---
const BrokerModal = ({ isOpen, onClose, onConnect, isSyncing }) => {
    const [step, setStep] = useState('SELECT');
    const [provider, setProvider] = useState('');
    if (!isOpen)
        return null;
    return (React.createElement(AnimatePresence, null,
        React.createElement("div", { className: "fixed inset-0 z-[100] flex items-center justify-center p-4" },
            React.createElement(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, onClick: onClose, className: "absolute inset-0 bg-black/80 backdrop-blur-sm" }),
            React.createElement(motion.div, { initial: { opacity: 0, scale: 0.9, y: 20 }, animate: { opacity: 1, scale: 1, y: 0 }, exit: { opacity: 0, scale: 0.9, y: 20 }, className: "relative w-full max-w-md bg-[var(--surface)] border border-[var(--line)] rounded-3xl shadow-2xl overflow-hidden" },
                React.createElement("div", { className: "p-8 border-b border-[var(--line)] flex justify-between items-center" },
                    React.createElement("h3", { className: "text-xl font-black tracking-tight" }, "Connect Broker"),
                    React.createElement("button", { onClick: onClose, className: "p-2 hover:bg-[var(--line)] rounded-xl transition-all" },
                        React.createElement(X, { size: 20 }))),
                React.createElement("div", { className: "p-8" }, isSyncing ? (React.createElement("div", { className: "flex flex-col items-center justify-center py-12 gap-6" },
                    React.createElement("div", { className: "relative" },
                        React.createElement(RefreshCw, { size: 48, className: "text-[var(--brand)] animate-spin" }),
                        React.createElement("div", { className: "absolute inset-0 bg-[var(--brand)]/20 blur-xl rounded-full animate-pulse" })),
                    React.createElement("div", { className: "flex flex-col items-center gap-2" },
                        React.createElement("h4", { className: "text-lg font-black text-white" },
                            "Connecting to ",
                            provider,
                            "..."),
                        React.createElement("p", { className: "text-xs text-[var(--muted)] font-bold uppercase tracking-widest" }, "Synchronizing your trade data")))) : step === 'SELECT' ? (React.createElement("div", { className: "flex flex-col gap-4" },
                    React.createElement("p", { className: "text-sm text-[var(--muted)] mb-2" }, "Select your trading platform to sync your trades automatically."),
                    ['METATRADER', 'TRADOVATE', 'OANDA', 'IBKR'].map((p) => (React.createElement("button", { key: p, onClick: () => { setProvider(p); setStep('FORM'); }, className: "flex items-center justify-between p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)] hover:border-[var(--brand)] transition-all group" },
                        React.createElement("div", { className: "flex items-center gap-4" },
                            React.createElement("div", { className: "w-10 h-10 rounded-xl bg-[var(--surface)] flex items-center justify-center text-[var(--brand)]" },
                                React.createElement(Activity, { size: 20 })),
                            React.createElement("span", { className: "font-black text-sm" }, p)),
                        React.createElement(ChevronRight, { size: 18, className: "text-[var(--muted)] group-hover:translate-x-1 transition-transform" })))))) : (React.createElement("form", { onSubmit: (e) => { e.preventDefault(); onConnect(provider); }, className: "flex flex-col gap-6" },
                    React.createElement("div", { className: "flex flex-col gap-2" },
                        React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "Account ID"),
                        React.createElement("input", { type: "text", placeholder: "Enter your account number", className: "input", required: true })),
                    React.createElement("div", { className: "flex flex-col gap-2" },
                        React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, "API Key / Password"),
                        React.createElement("input", { type: "password", placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022", className: "input", required: true })),
                    React.createElement("div", { className: "flex gap-3 mt-4" },
                        React.createElement("button", { type: "button", onClick: () => setStep('SELECT'), className: "btn flex-1" }, "Back"),
                        React.createElement("button", { type: "submit", className: "btn btn-primary flex-1" },
                            "Connect ",
                            provider)),
                    React.createElement("div", { className: "mt-6 p-4 rounded-2xl bg-[var(--brand)]/5 border border-[var(--brand)]/10" },
                        React.createElement("h4", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--brand)] mb-2 flex items-center gap-2" },
                            React.createElement(Zap, { size: 10 }),
                            " How to verify connection?"),
                        React.createElement("ul", { className: "flex flex-col gap-2" },
                            React.createElement("li", { className: "text-[9px] text-[var(--muted)] font-medium flex gap-2" },
                                React.createElement("span", { className: "text-[var(--brand)]" }, "1."),
                                "Check the \"Broker Status\" card on your dashboard. It should turn green."),
                            React.createElement("li", { className: "text-[9px] text-[var(--muted)] font-medium flex gap-2" },
                                React.createElement("span", { className: "text-[var(--brand)]" }, "2."),
                                "Your account balance and ID will appear instantly after sync."),
                            React.createElement("li", { className: "text-[9px] text-[var(--muted)] font-medium flex gap-2" },
                                React.createElement("span", { className: "text-[var(--brand)]" }, "3."),
                                "Try the \"Sync Now\" button to see real-time data flow."))),
                    React.createElement("p", { className: "text-[10px] text-center text-[var(--muted)] mt-4" }, "Your credentials are encrypted and never stored on our servers."))))))));
};
const AdminView = ({ t }) => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const fetchUsers = async () => {
            // In a real app, you'd need a service role or edge function to list all users
            // For this demo, we'll fetch from a 'profiles' table
            const { data, error } = await supabase
                .from('profiles')
                .select('*');
            if (data)
                setUsers(data);
            setLoading(false);
        };
        fetchUsers();
    }, []);
    return (React.createElement("div", { className: "flex flex-col gap-8" },
        React.createElement("div", { className: "flex flex-col gap-1" },
            React.createElement("h2", { className: "text-3xl font-black text-gradient" }, t.adminPanel),
            React.createElement("p", { className: "text-[var(--muted)] text-sm font-bold uppercase tracking-widest" }, t.userManagement)),
        React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] overflow-hidden" },
            React.createElement("div", { className: "overflow-x-auto" },
                React.createElement("table", { className: "w-full text-left border-collapse" },
                    React.createElement("thead", null,
                        React.createElement("tr", { className: "border-b border-[var(--line)] bg-[var(--bg)]/50" },
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.users),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.role),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.status),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)]" }, t.lastLogin),
                            React.createElement("th", { className: "p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)] text-right" }, t.actions))),
                    React.createElement("tbody", null, loading ? (React.createElement("tr", null,
                        React.createElement("td", { colSpan: 5, className: "p-10 text-center text-[var(--muted)]" }, "Loading users..."))) : users.length > 0 ? users.map((user) => (React.createElement("tr", { key: user.id, className: "border-b border-[var(--line)] hover:bg-[var(--surface-hover)] transition-colors group" },
                        React.createElement("td", { className: "p-6" },
                            React.createElement("div", { className: "flex items-center gap-4" },
                                React.createElement("div", { className: "w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--brand)] to-[var(--brand2)] flex items-center justify-center text-white font-black" }, (user.username || user.email || 'U').charAt(0)),
                                React.createElement("div", { className: "flex flex-col" },
                                    React.createElement("span", { className: "text-sm font-black text-white" }, user.username || 'Anonymous'),
                                    React.createElement("span", { className: "text-xs text-[var(--muted)]" }, user.email)))),
                        React.createElement("td", { className: "p-6" },
                            React.createElement(Badge, { className: cn(user.role === 'admin' ? "bg-[var(--brand)]/20 text-[var(--brand)]" : "bg-[var(--muted)]/20 text-[var(--muted)]") }, user.role)),
                        React.createElement("td", { className: "p-6" },
                            React.createElement("div", { className: "flex items-center gap-2" },
                                React.createElement("div", { className: cn("w-1.5 h-1.5 rounded-full", user.status === 'active' ? "bg-[var(--ok)]" : "bg-[var(--ko)]") }),
                                React.createElement("span", { className: "text-xs font-bold text-white" }, user.status === 'active' ? t.active : t.suspended))),
                        React.createElement("td", { className: "p-6 text-xs font-bold text-[var(--muted)]" }, user.last_login ? format(new Date(user.last_login), 'yyyy-MM-dd HH:mm') : 'N/A'),
                        React.createElement("td", { className: "p-6 text-right" },
                            React.createElement("div", { className: "flex items-center justify-end gap-2" },
                                React.createElement("button", { onClick: async () => {
                                        const newRole = user.role === 'admin' ? 'trader' : 'admin';
                                        const { error } = await supabase
                                            .from('profiles')
                                            .update({ role: newRole })
                                            .eq('id', user.id);
                                        if (!error) {
                                            setUsers(users.map(u => u.id === user.id ? { ...u, role: newRole } : u));
                                        }
                                    }, className: "text-[10px] font-black uppercase tracking-widest text-[var(--brand)] hover:underline" }, user.role === 'admin' ? 'Demote' : 'Promote'),
                                React.createElement("button", { className: "p-2 rounded-lg hover:bg-[var(--surface)] text-[var(--muted)] hover:text-white transition-all" },
                                    React.createElement(MoreVertical, { size: 16 }))))))) : (React.createElement("tr", null,
                        React.createElement("td", { colSpan: 5, className: "p-10 text-center text-[var(--muted)]" }, "No users found in database."))))))),
        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-8" },
            React.createElement("div", { className: "card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-6" },
                React.createElement("div", { className: "flex items-center gap-3" },
                    React.createElement("div", { className: "w-10 h-10 rounded-xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]" },
                        React.createElement(SettingsIcon, { size: 20 })),
                    React.createElement("h3", { className: "text-lg font-black tracking-tight" }, t.systemSettings)),
                React.createElement("div", { className: "flex flex-col gap-4" },
                    React.createElement("div", { className: "flex items-center justify-between p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)]" },
                        React.createElement("span", { className: "text-sm font-bold text-white" }, "Maintenance Mode"),
                        React.createElement("div", { className: "w-12 h-6 rounded-full bg-[var(--line)] relative cursor-pointer" },
                            React.createElement("div", { className: "absolute left-1 top-1 w-4 h-4 rounded-full bg-[var(--muted)]" }))),
                    React.createElement("div", { className: "flex items-center justify-between p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)]" },
                        React.createElement("span", { className: "text-sm font-bold text-white" }, "New User Registration"),
                        React.createElement("div", { className: "w-12 h-6 rounded-full bg-[var(--brand)] relative cursor-pointer" },
                            React.createElement("div", { className: "absolute right-1 top-1 w-4 h-4 rounded-full bg-white" }))))))));
};
const App = () => {
    const [isAuthed, setIsAuthed] = useState(false);
    const [user, setUser] = useState(null);
    const [userRole, setUserRole] = useState('trader');
    const [view, setView] = useState('dashboard');
    const [theme, setTheme] = useState('dark');
    const [settings, setSettings] = useState({ theme: 'dark', language: 'fr', currency: 'USD', balance: 100000 });
    const [trades, setTrades] = useState([]);
    const [journalEntries, setJournalEntries] = useState([]);
    const [backtestSessions, setBacktestSessions] = useState([]);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isBrokerModalOpen, setIsBrokerModalOpen] = useState(false);
    const [isSyncing, setIsSyncing] = useState(false);
    const [selectedTrade, setSelectedTrade] = useState(null);
    const [authLoading, setAuthLoading] = useState(true);
    // Auth Listener
    useEffect(() => {
        supabase.auth.getSession().then(({ data: { session } }) => {
            setUser(session?.user ?? null);
            setIsAuthed(!!session);
            setAuthLoading(false);
        });
        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
            setUser(session?.user ?? null);
            setIsAuthed(!!session);
        });
        return () => subscription.unsubscribe();
    }, []);
    // Fetch User Profile (Role)
    useEffect(() => {
        if (user) {
            const fetchProfile = async () => {
                const { data, error } = await supabase
                    .from('profiles')
                    .select('role')
                    .eq('id', user.id)
                    .single();
                if (data) {
                    setUserRole(data.role);
                }
                else if (error && error.code === 'PGRST116') {
                    // Profile doesn't exist, create it
                    await supabase.from('profiles').insert([
                        { id: user.id, email: user.email, role: 'trader', status: 'active', username: user.email?.split('@')[0] }
                    ]);
                }
            };
            fetchProfile();
        }
    }, [user]);
    // Load data from Supabase or LocalStorage
    useEffect(() => {
        const loadData = async () => {
            if (user) {
                // Load from Supabase
                const [tradesRes, journalRes, backtestRes, settingsRes] = await Promise.all([
                    supabase.from('trades').select('*').eq('user_id', user.id).order('date', { ascending: false }),
                    supabase.from('journal_entries').select('*').eq('user_id', user.id).order('date', { ascending: false }),
                    supabase.from('backtest_sessions').select('*').eq('user_id', user.id).order('date', { ascending: false }),
                    supabase.from('settings').select('*').eq('user_id', user.id).single()
                ]);
                if (tradesRes.data)
                    setTrades(tradesRes.data);
                if (journalRes.data)
                    setJournalEntries(journalRes.data);
                if (backtestRes.data)
                    setBacktestSessions(backtestRes.data);
                if (settingsRes.data) {
                    setSettings(settingsRes.data);
                    setTheme(settingsRes.data.theme);
                }
            }
            else {
                // Fallback to LocalStorage
                const savedTrades = localStorage.getItem('ef_trades');
                if (savedTrades)
                    setTrades(JSON.parse(savedTrades));
                const savedJournal = localStorage.getItem('ef_journal');
                if (savedJournal)
                    setJournalEntries(JSON.parse(savedJournal));
                const savedBacktest = localStorage.getItem('ef_backtest');
                if (savedBacktest)
                    setBacktestSessions(JSON.parse(savedBacktest));
                const savedSettings = localStorage.getItem('ef_settings');
                if (savedSettings) {
                    const parsed = JSON.parse(savedSettings);
                    setSettings(parsed);
                    setTheme(parsed.theme);
                }
            }
        };
        loadData();
    }, [user]);
    // Save data effect (only for local storage if not authed)
    useEffect(() => {
        if (!user) {
            localStorage.setItem('ef_trades', JSON.stringify(trades));
            localStorage.setItem('ef_journal', JSON.stringify(journalEntries));
            localStorage.setItem('ef_backtest', JSON.stringify(backtestSessions));
            localStorage.setItem('ef_settings', JSON.stringify(settings));
            localStorage.setItem('ef_theme', theme);
        }
        document.documentElement.setAttribute('data-theme', theme);
    }, [trades, journalEntries, backtestSessions, settings, theme, user]);
    // Sync theme with settings
    useEffect(() => {
        setTheme(settings.theme);
    }, [settings.theme]);
    const handleLogin = async (e) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const email = formData.get('email');
        const password = formData.get('password');
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error)
            alert(error.message);
    };
    const handleSignup = async (e) => {
        if (e)
            e.preventDefault();
        const form = document.querySelector('form');
        if (!form)
            return;
        const formData = new FormData(form);
        const email = formData.get('email');
        const password = formData.get('password');
        if (!email || !password) {
            alert('Please enter email and password');
            return;
        }
        const { error } = await supabase.auth.signUp({ email, password });
        if (error)
            alert(error.message);
        else
            alert('Check your email for the confirmation link!');
    };
    const handleLogout = async () => {
        await supabase.auth.signOut();
        setIsAuthed(false);
        setUser(null);
    };
    const handleConnectBroker = (provider) => {
        setIsSyncing(true);
        // Simulate connection delay
        setTimeout(async () => {
            const newBroker = {
                id: Math.random().toString(36).substr(2, 9),
                provider: provider,
                status: 'CONNECTED',
                accountName: `Demo ${provider} Account`,
                lastSync: new Date().toISOString()
            };
            const newSettings = { ...settings, broker: newBroker };
            setSettings(newSettings);
            if (user) {
                await supabase.from('settings').upsert({ user_id: user.id, ...newSettings });
            }
            setIsSyncing(false);
            setIsBrokerModalOpen(false);
        }, 2000);
    };
    const handleExportPDF = async () => {
        const element = document.getElementById('main-content-area');
        if (!element)
            return;
        const canvas = await html2canvas(element, {
            scale: 2,
            useCORS: true,
            backgroundColor: theme === 'dark' ? '#0f1224' : '#ffffff'
        });
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`edgeflow-report-${format(new Date(), 'yyyy-MM-dd')}.pdf`);
    };
    const handleExportBackup = () => {
        const backupData = {
            trades,
            journalEntries,
            backtestSessions,
            settings,
            exportDate: new Date().toISOString(),
            version: '2.5'
        };
        const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `edgeflow-backup-${format(new Date(), 'yyyy-MM-dd')}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };
    const handleImportBackup = (event) => {
        const file = event.target.files?.[0];
        if (!file)
            return;
        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const data = JSON.parse(e.target?.result);
                if (data.trades)
                    setTrades(data.trades);
                if (data.journalEntries)
                    setJournalEntries(data.journalEntries);
                if (data.backtestSessions)
                    setBacktestSessions(data.backtestSessions);
                if (data.settings)
                    setSettings(data.settings);
                if (user) {
                    // Sync to Supabase
                    await Promise.all([
                        supabase.from('trades').upsert(data.trades.map((t) => ({ ...t, user_id: user.id }))),
                        supabase.from('journal_entries').upsert(data.journalEntries.map((j) => ({ ...j, user_id: user.id }))),
                        supabase.from('backtest_sessions').upsert(data.backtestSessions.map((b) => ({ ...b, user_id: user.id }))),
                        supabase.from('settings').upsert({ user_id: user.id, ...data.settings })
                    ]);
                }
                alert(translations[settings.language].importSuccess);
            }
            catch (err) {
                console.error('Import error:', err);
                alert(translations[settings.language].importError);
            }
        };
        reader.readAsText(file);
    };
    const handleExportCSV = () => {
        const headers = ['Symbol', 'Type', 'Status', 'Entry', 'Exit', 'Lots', 'P&L', 'Date'];
        const rows = trades.map(t => [
            t.symbol,
            t.type,
            t.status,
            t.entryPrice,
            t.exitPrice || '',
            t.pnl,
            t.date
        ]);
        const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", `edgeflow-trades-${format(new Date(), 'yyyy-MM-dd')}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const handleImportCSV = (e) => {
        const file = e.target.files?.[0];
        if (!file)
            return;
        const reader = new FileReader();
        reader.onload = async (event) => {
            const text = event.target?.result;
            const lines = text.split('\n');
            const newTrades = [];
            // Skip header
            for (let i = 1; i < lines.length; i++) {
                const cols = lines[i].split(',');
                if (cols.length < 7)
                    continue;
                newTrades.push({
                    id: Math.random().toString(36).substr(2, 9),
                    symbol: cols[0],
                    type: cols[1],
                    status: cols[2],
                    entryPrice: Number(cols[3]),
                    exitPrice: Number(cols[4]) || undefined,
                    pnl: Number(cols[5]),
                    date: cols[6] || new Date().toISOString(),
                    tags: []
                });
            }
            const updatedTrades = [...newTrades, ...trades];
            setTrades(updatedTrades);
            if (user) {
                await supabase.from('trades').upsert(newTrades.map(t => ({ ...t, user_id: user.id })));
            }
        };
        reader.readAsText(file);
    };
    const handleAddBacktestSession = async (session) => {
        const exists = backtestSessions.find(s => s.id === session.id);
        let updated;
        if (exists) {
            updated = backtestSessions.map(s => s.id === session.id ? session : s);
        }
        else {
            updated = [session, ...backtestSessions];
        }
        setBacktestSessions(updated);
        if (user) {
            await supabase.from('backtest_sessions').upsert({ ...session, user_id: user.id });
        }
    };
    const deleteBacktestSession = async (id) => {
        setBacktestSessions(backtestSessions.filter(s => s.id !== id));
        if (user) {
            await supabase.from('backtest_sessions').delete().eq('id', id);
        }
    };
    const handleAddJournalEntry = async (e) => {
        const formData = new FormData(e.currentTarget);
        const newEntry = {
            id: Math.random().toString(36).substr(2, 9),
            date: new Date().toISOString(),
            content: formData.get('content'),
            mood: formData.get('mood'),
        };
        setJournalEntries([newEntry, ...journalEntries]);
        if (user) {
            await supabase.from('journal_entries').insert([{ ...newEntry, user_id: user.id }]);
        }
    };
    const deleteJournalEntry = async (id) => {
        setJournalEntries(journalEntries.filter(e => e.id !== id));
        if (user) {
            await supabase.from('journal_entries').delete().eq('id', id);
        }
    };
    const handleAddTrade = async (e) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);
        const newTrade = {
            id: Math.random().toString(36).substr(2, 9),
            symbol: formData.get('symbol'),
            type: formData.get('type'),
            status: formData.get('status'),
            entryPrice: Number(formData.get('entryPrice')),
            exitPrice: formData.get('exitPrice') ? Number(formData.get('exitPrice')) : undefined,
            stopLoss: Number(formData.get('stopLoss')),
            takeProfit: Number(formData.get('takeProfit')),
            pnl: Number(formData.get('pnl')),
            date: formData.get('date') || new Date().toISOString(),
            entryTime: formData.get('entryTime'),
            exitTime: formData.get('exitTime'),
            propFirm: formData.get('propFirm'),
            source: formData.get('source'),
            orderType: formData.get('orderType'),
            riskPercent: Number(formData.get('riskPercent')),
            rMultiple: Number(formData.get('rMultiple')),
            setup: formData.get('setup'),
            rating: formData.get('rating'),
            emotionBefore: formData.get('emotionBefore'),
            emotionAfter: formData.get('emotionAfter'),
            notes: formData.get('notes'),
            screenshotUrl: formData.get('screenshotUrl'),
            tags: [],
        };
        setTrades([newTrade, ...trades]);
        setIsModalOpen(false);
        if (user) {
            await supabase.from('trades').insert([{ ...newTrade, user_id: user.id }]);
        }
    };
    const handleUpdateTrade = async (updatedTrade) => {
        setTrades(trades.map(t => t.id === updatedTrade.id ? updatedTrade : t));
        setSelectedTrade(null);
        if (user) {
            await supabase.from('trades').update(updatedTrade).eq('id', updatedTrade.id);
        }
    };
    const deleteTrade = async (id) => {
        setTrades(trades.filter(t => t.id !== id));
        if (user) {
            await supabase.from('trades').delete().eq('id', id);
        }
    };
    const t = translations[settings.language];
    if (!isAuthed) {
        return (React.createElement("section", { className: "hero-gradient min-h-screen flex items-center justify-center p-6 overflow-hidden relative" },
            React.createElement("div", { className: "max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center z-10" },
                React.createElement(motion.div, { initial: { opacity: 0, x: -50 }, animate: { opacity: 1, x: 0 }, className: "flex flex-col gap-6" },
                    React.createElement("div", { className: "flex items-center gap-4" },
                        React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-gradient-to-r from-[var(--brand)] to-[var(--brand2)] flex items-center justify-center shadow-lg" },
                            React.createElement(Activity, { className: "text-white", size: 24 })),
                        React.createElement("div", null,
                            React.createElement("h2", { className: "text-white font-black text-xl tracking-tight" }, "EdgeFlow"),
                            React.createElement(Badge, { className: "bg-[var(--brand)]/20 text-[var(--brand2)] border border-[var(--brand)]/30" }, "Premium"))),
                    React.createElement("h1", { className: "text-5xl lg:text-7xl font-black text-white leading-[1.05] tracking-tighter" }, t.heroTitle),
                    React.createElement("p", { className: "text-[var(--muted)] text-lg lg:text-xl max-w-lg" }, t.heroSubtitle),
                    React.createElement("ul", { className: "flex flex-col gap-3 text-white/80 font-medium" },
                        React.createElement("li", { className: "flex items-center gap-2" },
                            React.createElement("div", { className: "w-1.5 h-1.5 rounded-full bg-[var(--brand)]" }),
                            " ",
                            t.heroFeature1),
                        React.createElement("li", { className: "flex items-center gap-2" },
                            React.createElement("div", { className: "w-1.5 h-1.5 rounded-full bg-[var(--brand)]" }),
                            " ",
                            t.heroFeature2),
                        React.createElement("li", { className: "flex items-center gap-2" },
                            React.createElement("div", { className: "w-1.5 h-1.5 rounded-full bg-[var(--brand)]" }),
                            " ",
                            t.heroFeature3))),
                React.createElement(motion.div, { initial: { opacity: 0, scale: 0.9 }, animate: { opacity: 1, scale: 1 }, className: "card bg-[var(--surface)]/95 backdrop-blur-xl border-white/10 max-w-md w-full ml-auto" },
                    React.createElement("h3", { className: "text-2xl font-black mb-1 text-[var(--text)]" }, t.loginTitle),
                    React.createElement("p", { className: "text-[var(--muted)] text-sm mb-6" }, t.loginSubtitle),
                    React.createElement("form", { className: "flex flex-col gap-4", onSubmit: handleLogin },
                        React.createElement("div", { className: "flex flex-col gap-1.5" },
                            React.createElement("label", { className: "text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, t.emailLabel),
                            React.createElement("input", { name: "email", type: "email", placeholder: "toi@exemple.be", className: "input", required: true })),
                        React.createElement("div", { className: "flex flex-col gap-1.5" },
                            React.createElement("label", { className: "text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]" }, t.passwordLabel),
                            React.createElement("input", { name: "password", type: "password", placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022", className: "input", required: true })),
                        React.createElement("div", { className: "flex justify-between items-center text-xs" },
                            React.createElement("label", { className: "flex items-center gap-2 cursor-pointer" },
                                React.createElement("input", { type: "checkbox", className: "accent-[var(--brand)]" }),
                                React.createElement("span", { className: "text-[var(--muted)]" }, "Se souvenir de moi")),
                            React.createElement("a", { href: "#", className: "text-[var(--brand2)] font-bold hover:underline" }, "Oubli\u00E9 ?")),
                        React.createElement("button", { type: "submit", className: "btn btn-primary w-full mt-2" }, "Se connecter"),
                        React.createElement("button", { type: "button", onClick: handleSignup, className: "btn w-full border-[var(--line)] flex items-center justify-center gap-2" }, "Cr\u00E9er un compte"),
                        React.createElement("button", { type: "button", className: "btn w-full border-[var(--line)] flex items-center justify-center gap-2" },
                            React.createElement("img", { src: "https://www.google.com/favicon.ico", className: "w-4 h-4", alt: "Google" }),
                            "Continuer avec Google"),
                        React.createElement("div", { className: "text-center text-xs text-[var(--muted)] mt-4" },
                            "Pas de compte ? ",
                            React.createElement("button", { type: "button", onClick: () => { }, className: "text-[var(--brand2)] font-bold" }, "Cr\u00E9er un compte")),
                        React.createElement("button", { type: "button", onClick: () => setIsAuthed(true), className: "text-[var(--brand2)] text-xs font-bold hover:underline mt-2" }, "Continuer sans compte (test)")))),
            React.createElement("div", { className: "absolute bottom-6 w-full text-center text-white/30 text-[10px] font-bold tracking-widest uppercase" }, "\u00A9 EdgeFlow \u2014 Tous droits r\u00E9serv\u00E9s 2025")));
    }
    return (React.createElement("div", { className: "flex min-h-screen bg-[var(--bg)]" },
        React.createElement("aside", { className: "w-72 bg-[var(--surface)] border-r border-[var(--line)] p-8 flex flex-col gap-10 sticky top-0 h-screen overflow-y-auto" },
            React.createElement("div", { className: "flex items-center gap-4" },
                React.createElement("div", { className: "w-12 h-12 rounded-2xl bg-gradient-to-br from-[var(--brand)] to-[var(--brand2)] flex items-center justify-center shadow-xl shadow-[var(--brand-glow)]" },
                    React.createElement(Activity, { className: "text-white", size: 24 })),
                React.createElement("div", null,
                    React.createElement("h2", { className: "font-black text-xl tracking-tighter text-gradient" }, "EdgeFlow"),
                    React.createElement("div", { className: "text-[var(--muted)] text-[10px] font-black uppercase tracking-[0.2em]" }, "Mission Control"))),
            React.createElement("div", { className: "flex flex-col gap-3" },
                React.createElement("button", { onClick: () => setIsModalOpen(true), className: "btn btn-primary w-full py-4 rounded-2xl flex items-center justify-center gap-3 group" },
                    React.createElement(Plus, { size: 20, className: "group-hover:rotate-90 transition-transform duration-300" }),
                    React.createElement("span", { className: "uppercase tracking-widest text-xs" }, t.newTrade)),
                React.createElement("button", { className: "btn w-full py-4 rounded-2xl border-[var(--line)] hover:border-[var(--brand)]/30 transition-all group" },
                    React.createElement("span", { className: "uppercase tracking-widest text-[10px] font-black text-[var(--muted)] group-hover:text-white" }, t.importCSV))),
            React.createElement("div", { className: "flex flex-col gap-8" },
                React.createElement("div", { className: "flex flex-col gap-4" },
                    React.createElement("label", { className: "text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, t.parameters),
                    React.createElement("div", { className: "flex flex-col gap-3" },
                        React.createElement("div", { className: "flex flex-col gap-1.5" },
                            React.createElement("span", { className: "text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider" }, "Prop Firm"),
                            React.createElement("select", { className: "bg-[var(--bg)] border border-[var(--line)] rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[var(--brand)] transition-all" },
                                React.createElement("option", null, "FTMO 100K"),
                                React.createElement("option", null, "MFF 50K"))))),
                React.createElement("nav", { className: "flex flex-col gap-2" },
                    React.createElement("label", { className: "text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)] mb-2" }, "Navigation"),
                    [
                        { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
                        { id: 'calendar', label: t.calendar, icon: CalendarIcon },
                        { id: 'trades', label: t.trades, icon: History },
                        { id: 'lab', label: t.lab, icon: FlaskConical },
                        { id: 'settings', label: t.settings, icon: SettingsIcon },
                        ...(userRole === 'admin' ? [{ id: 'admin', label: t.admin, icon: Shield }] : []),
                    ].map((item) => (React.createElement("button", { key: item.id, onClick: () => setView(item.id), className: cn("flex items-center gap-4 px-4 py-3.5 rounded-2xl text-sm font-bold transition-all duration-200 group", view === item.id
                            ? "bg-[var(--brand)]/10 text-[var(--brand)] shadow-inner"
                            : "text-[var(--muted)] hover:bg-[var(--surface-hover)] hover:text-white") },
                        React.createElement(item.icon, { size: 18, className: cn("transition-transform duration-300", view === item.id ? "scale-110" : "group-hover:scale-110") }),
                        React.createElement("span", { className: "tracking-wide" }, item.label),
                        view === item.id && React.createElement(motion.div, { layoutId: "active-pill", className: "ml-auto w-1.5 h-1.5 rounded-full bg-[var(--brand)] shadow-[0_0_8px_var(--brand)]" })))))),
            React.createElement("div", { className: "mt-auto pt-8 border-t border-[var(--line)]" },
                React.createElement("button", { onClick: handleLogout, className: "flex items-center justify-between w-full px-4 py-4 rounded-2xl text-sm font-black text-[var(--ko)] hover:bg-[var(--ko)]/10 transition-all group" },
                    React.createElement("span", { className: "uppercase tracking-widest text-[10px]" }, "Logout"),
                    React.createElement(LogOut, { size: 18, className: "group-hover:translate-x-1 transition-transform" })))),
        React.createElement("main", { className: "flex-1 flex flex-col min-w-0 bg-[var(--bg)]" },
            React.createElement("header", { className: "h-20 bg-[var(--surface)]/80 backdrop-blur-xl border-b border-[var(--line)] flex items-center justify-between px-10 sticky top-0 z-20" },
                React.createElement("div", { className: "flex items-center gap-4" },
                    React.createElement("h1", { className: "text-xl font-black text-gradient capitalize tracking-tight" }, view),
                    React.createElement("div", { className: "h-4 w-[1px] bg-[var(--line)] mx-2" }),
                    React.createElement("p", { className: "text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, "EdgeFlow v2.5")),
                React.createElement("div", { className: "flex items-center gap-8" },
                    React.createElement("div", { className: "flex items-center gap-3 px-4 py-2 rounded-full bg-[var(--ok)]/10 border border-[var(--ok)]/20" },
                        React.createElement("span", { className: "w-2 h-2 rounded-full bg-[var(--ok)] animate-pulse shadow-[0_0_8px_var(--ok)]" }),
                        React.createElement("span", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--ok)]" }, "System Ready")),
                    React.createElement("div", { className: "flex items-center gap-4" },
                        React.createElement("button", { className: "p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all" },
                            React.createElement(Search, { size: 20 })),
                        React.createElement("button", { className: "p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all" },
                            React.createElement(Download, { size: 20 })),
                        React.createElement("button", { className: "p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all" },
                            React.createElement(Activity, { size: 20 })),
                        React.createElement("button", { onClick: () => setTheme(theme === 'light' ? 'dark' : 'light'), className: "p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all" }, theme === 'light' ? React.createElement(Moon, { size: 20 }) : React.createElement(Sun, { size: 20 }))),
                    React.createElement("div", { className: "h-8 w-[1px] bg-[var(--line)]" }),
                    React.createElement("button", { className: "flex items-center gap-4 group" },
                        React.createElement("div", { className: "text-right hidden sm:block" },
                            React.createElement("div", { className: "text-sm font-black text-white group-hover:text-[var(--brand)] transition-colors" }, "Julien Y."),
                            React.createElement("div", { className: "text-[10px] text-[var(--muted)] font-black uppercase tracking-widest" }, "Elite Trader")),
                        React.createElement("div", { className: "w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--brand)] to-[var(--brand2)] p-[1px]" },
                            React.createElement("div", { className: "w-full h-full rounded-2xl bg-[var(--surface)] flex items-center justify-center overflow-hidden" },
                                React.createElement(User, { size: 22, className: "text-[var(--brand)]" })))))),
            React.createElement("div", { id: "main-content-area", className: "p-10 flex flex-col gap-10 max-w-[1600px] mx-auto w-full" },
                React.createElement("div", { className: "flex justify-between items-end" },
                    React.createElement("div", { className: "flex flex-col gap-1" },
                        React.createElement("h1", { className: "text-4xl font-black tracking-tighter capitalize text-white" }, t[view] || view),
                        React.createElement("p", { className: "text-[var(--muted)] text-sm font-medium" }, t.welcome)),
                    React.createElement("div", { className: "flex gap-4 no-print" },
                        view === 'trades' && (React.createElement(React.Fragment, null,
                            React.createElement("label", { className: "btn gap-2 cursor-pointer" },
                                React.createElement(Plus, { size: 16 }),
                                " ",
                                t.importCSV,
                                React.createElement("input", { type: "file", accept: ".csv", className: "hidden", onChange: handleImportCSV })),
                            React.createElement("button", { onClick: handleExportCSV, className: "btn gap-2" },
                                React.createElement(Download, { size: 16 }),
                                " ",
                                t.exportCSV))),
                        React.createElement("button", { onClick: handleExportPDF, className: "btn gap-2" },
                            React.createElement(Download, { size: 16 }),
                            " ",
                            t.exportPDF),
                        React.createElement("button", { onClick: () => setIsModalOpen(true), className: "btn btn-primary gap-2" },
                            React.createElement(Plus, { size: 18 }),
                            " ",
                            t.newTrade))),
                React.createElement(AnimatePresence, { mode: "wait" },
                    React.createElement(motion.div, { key: view, initial: { opacity: 0, y: 10 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -10 }, transition: { duration: 0.2 } },
                        view === 'dashboard' && React.createElement(Dashboard, { trades: trades, theme: theme, onAddTrade: () => setIsModalOpen(true), settings: settings, setIsBrokerModalOpen: setIsBrokerModalOpen, isSyncing: isSyncing, onSync: () => handleConnectBroker(settings.broker?.provider || 'Broker'), t: t }),
                        view === 'calendar' && React.createElement(Calendar, { trades: trades, t: t }),
                        view === 'trades' && React.createElement(TradesList, { trades: trades, onDelete: deleteTrade, onSelect: setSelectedTrade, t: t }),
                        view === 'journal' && React.createElement(Journal, { entries: journalEntries, onAdd: handleAddJournalEntry, onDelete: deleteJournalEntry, t: t }),
                        view === 'lab' && React.createElement(BacktestingLab, { sessions: backtestSessions, onAddSession: handleAddBacktestSession, onDeleteSession: deleteBacktestSession, t: t }),
                        view === 'settings' && React.createElement(Settings, { settings: settings, onUpdate: setSettings, setIsBrokerModalOpen: setIsBrokerModalOpen, t: t, onExportBackup: handleExportBackup, onImportBackup: handleImportBackup }),
                        view === 'admin' && userRole === 'admin' && React.createElement(AdminView, { t: t }))))),
        React.createElement(TradeDrawer, { trade: selectedTrade, onClose: () => setSelectedTrade(null), theme: theme, onUpdate: handleUpdateTrade, t: t }),
        React.createElement(BrokerModal, { isOpen: isBrokerModalOpen, onClose: () => setIsBrokerModalOpen(false), onConnect: handleConnectBroker, isSyncing: isSyncing }),
        React.createElement(AnimatePresence, null, isModalOpen && (React.createElement("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-6" },
            React.createElement(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, onClick: () => setIsModalOpen(false), className: "absolute inset-0 bg-black/80 backdrop-blur-sm" }),
            React.createElement(motion.div, { initial: { opacity: 0, scale: 0.95, y: 20 }, animate: { opacity: 1, scale: 1, y: 0 }, exit: { opacity: 0, scale: 0.95, y: 20 }, className: "bg-[var(--surface)] border border-[var(--line)] w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl relative z-10 flex flex-col shadow-2xl" },
                React.createElement("div", { className: "p-8 border-b border-[var(--line)] flex justify-between items-center bg-[var(--surface)]/50 sticky top-0 backdrop-blur-md z-20" },
                    React.createElement("div", { className: "flex flex-col" },
                        React.createElement("h2", { className: "text-2xl font-black text-gradient" }, t.logTrade),
                        React.createElement("p", { className: "text-[var(--muted)] text-xs font-bold uppercase tracking-widest" }, t.newTradeEntry)),
                    React.createElement("button", { onClick: () => setIsModalOpen(false), className: "p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all" },
                        React.createElement(X, { size: 24 }))),
                React.createElement("form", { onSubmit: handleAddTrade, className: "p-10 flex flex-col gap-10" },
                    React.createElement("div", { className: "flex flex-col gap-6" },
                        React.createElement("div", { className: "flex items-center gap-3" },
                            React.createElement("div", { className: "w-8 h-8 rounded-lg bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]" },
                                React.createElement(Activity, { size: 16 })),
                            React.createElement("h3", { className: "text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, t.executionDetails)),
                        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6" },
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.date),
                                React.createElement("input", { name: "date", type: "date", className: "input", defaultValue: new Date().toISOString().split('T')[0] })),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" },
                                    t.time,
                                    " (In)"),
                                React.createElement("input", { name: "entryTime", type: "time", className: "input" })),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" },
                                    t.time,
                                    " (Out)"),
                                React.createElement("input", { name: "exitTime", type: "time", className: "input" })),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.status),
                                React.createElement("select", { name: "status", className: "input" },
                                    React.createElement("option", { value: "WIN" }, "TP (Win)"),
                                    React.createElement("option", { value: "LOSS" }, "SL (Loss)"),
                                    React.createElement("option", { value: "BREAKEVEN" }, "BE (Breakeven)"),
                                    React.createElement("option", { value: "PENDING" }, "Pending"))))),
                    React.createElement("div", { className: "flex flex-col gap-6" },
                        React.createElement("div", { className: "flex items-center gap-3" },
                            React.createElement("div", { className: "w-8 h-8 rounded-lg bg-[var(--brand2)]/10 flex items-center justify-center text-[var(--brand2)]" },
                                React.createElement(Filter, { size: 16 })),
                            React.createElement("h3", { className: "text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, t.assetSource)),
                        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6" },
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.symbol),
                                React.createElement("select", { name: "symbol", className: "input" },
                                    React.createElement("option", { value: "EURUSD" }, "EURUSD"),
                                    React.createElement("option", { value: "GBPUSD" }, "GBPUSD"),
                                    React.createElement("option", { value: "USDJPY" }, "USDJPY"),
                                    React.createElement("option", { value: "XAUUSD" }, "XAUUSD"),
                                    React.createElement("option", { value: "BTCUSD" }, "BTCUSD"))),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, "Prop Firm"),
                                React.createElement("select", { name: "propFirm", className: "input" },
                                    React.createElement("option", { value: "" }, "(None)"),
                                    React.createElement("option", { value: "FTMO" }, "FTMO"),
                                    React.createElement("option", { value: "MFF" }, "MFF"))),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, "Source"),
                                React.createElement("select", { name: "source", className: "input" },
                                    React.createElement("option", { value: "Journal" }, "Journal"),
                                    React.createElement("option", { value: "Telegram" }, "Telegram"))))),
                    React.createElement("div", { className: "flex flex-col gap-6" },
                        React.createElement("div", { className: "flex items-center gap-3" },
                            React.createElement("div", { className: "w-8 h-8 rounded-lg bg-[var(--ok)]/10 flex items-center justify-center text-[var(--ok)]" },
                                React.createElement(TrendingUp, { size: 16 })),
                            React.createElement("h3", { className: "text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, t.positionParameters)),
                        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6" },
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.orderType),
                                React.createElement("select", { name: "orderType", className: "input" },
                                    React.createElement("option", { value: "Manuel" }, t.manual),
                                    React.createElement("option", { value: "Limit" }, t.limit))),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.direction),
                                React.createElement("select", { name: "type", className: "input" },
                                    React.createElement("option", { value: "BUY" }, t.long),
                                    React.createElement("option", { value: "SELL" }, t.short))),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.entryPrice),
                                React.createElement("input", { name: "entryPrice", type: "number", step: "0.00001", className: "input", placeholder: "0.00000" })),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.exitPrice),
                                React.createElement("input", { name: "exitPrice", type: "number", step: "0.00001", className: "input", placeholder: "0.00000" })),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.stopLoss),
                                React.createElement("input", { name: "stopLoss", type: "number", step: "0.00001", className: "input", placeholder: "0.00000" }))),
                        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6" },
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.takeProfit),
                                React.createElement("input", { name: "takeProfit", type: "number", step: "0.00001", className: "input", placeholder: "0.00000" })),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.rMultiple),
                                React.createElement("input", { name: "rMultiple", type: "number", step: "0.1", className: "input", defaultValue: "1" })),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" },
                                    t.risk,
                                    " (%)"),
                                React.createElement("input", { name: "riskPercent", type: "number", step: "0.1", className: "input", placeholder: "0.5" })),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.setup),
                                React.createElement("select", { name: "setup", className: "input" },
                                    React.createElement("option", { value: "" }, "---"),
                                    React.createElement("option", { value: "Breakout" }, "Breakout"),
                                    React.createElement("option", { value: "Retracement" }, "Retracement"))),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.rating),
                                React.createElement("select", { name: "rating", className: "input" },
                                    React.createElement("option", { value: "" }, "---"),
                                    React.createElement("option", { value: "A+" }, "A+"),
                                    React.createElement("option", { value: "A" }, "A"),
                                    React.createElement("option", { value: "B" }, "B"),
                                    React.createElement("option", { value: "C" }, "C"),
                                    React.createElement("option", { value: "D" }, "D"),
                                    React.createElement("option", { value: "F" }, "F"))))),
                    React.createElement("div", { className: "flex flex-col gap-6" },
                        React.createElement("div", { className: "flex items-center gap-3" },
                            React.createElement("div", { className: "w-8 h-8 rounded-lg bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]" },
                                React.createElement(BookOpen, { size: 16 })),
                            React.createElement("h3", { className: "text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, t.psychologyNotes)),
                        React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6" },
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.emotionBefore),
                                React.createElement("select", { name: "emotionBefore", className: "input" },
                                    React.createElement("option", { value: "" }, "---"),
                                    React.createElement("option", { value: "Calme" }, t.calm),
                                    React.createElement("option", { value: "Anxieux" }, t.anxious),
                                    React.createElement("option", { value: "Euphorique" }, t.euphoric))),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.emotionAfter),
                                React.createElement("select", { name: "emotionAfter", className: "input" },
                                    React.createElement("option", { value: "" }, "---"),
                                    React.createElement("option", { value: "Calme" }, t.calm),
                                    React.createElement("option", { value: "Frustr\u00E9" }, t.frustrated),
                                    React.createElement("option", { value: "Satisfait" }, "Satisfait"))),
                            React.createElement("div", { className: "flex flex-col gap-2" },
                                React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, "P&L (\u20AC)"),
                                React.createElement("input", { name: "pnl", type: "number", step: "0.01", className: "input", placeholder: "0.00" }))),
                        React.createElement("div", { className: "flex flex-col gap-2" },
                            React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.notes),
                            React.createElement("textarea", { name: "notes", placeholder: "Describe your setup, context, and mistakes...", className: "input min-h-[120px]" }))),
                    React.createElement("div", { className: "flex flex-col gap-6" },
                        React.createElement("div", { className: "flex items-center gap-3" },
                            React.createElement("div", { className: "w-8 h-8 rounded-lg bg-[var(--muted)]/10 flex items-center justify-center text-[var(--muted)]" },
                                React.createElement(Download, { size: 16 })),
                            React.createElement("h3", { className: "text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]" }, t.screenshot)),
                        React.createElement("div", { className: "flex flex-col gap-2" },
                            React.createElement("label", { className: "text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1" }, t.screenshotUrl),
                            React.createElement("input", { name: "screenshotUrl", type: "text", className: "input", placeholder: "https://tradingview.com/x/..." }))),
                    React.createElement("div", { className: "flex gap-4 pt-6 border-t border-[var(--line)]" },
                        React.createElement("button", { type: "button", onClick: () => setIsModalOpen(false), className: "btn flex-1 py-4 rounded-2xl uppercase tracking-widest text-xs font-black" }, t.cancel),
                        React.createElement("button", { type: "submit", className: "btn btn-primary flex-1 py-4 rounded-2xl uppercase tracking-widest text-xs font-black" }, t.saveTrade)))))))));
};
export default App;
