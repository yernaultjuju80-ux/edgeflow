export type TradeStatus = 'WIN' | 'LOSS' | 'BREAKEVEN' | 'PENDING';

export type TradeRating = 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';

export interface Trade {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  status: TradeStatus;
  entryPrice: number;
  exitPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  pnl: number;
  date: string; // ISO string
  entryTime?: string;
  exitTime?: string;
  propFirm?: string;
  source?: string;
  orderType?: string;
  riskPercent?: number;
  rMultiple?: number;
  setup?: string;
  rating?: TradeRating;
  emotionBefore?: string;
  emotionAfter?: string;
  notes?: string;
  screenshotUrl?: string;
  tags: string[];
}

export interface JournalEntry {
  id: string;
  date: string;
  content: string;
  mood: 'HAPPY' | 'NEUTRAL' | 'SAD';
}

export interface BacktestTrade {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  status: 'WIN' | 'LOSS' | 'BREAKEVEN';
  entryPrice: number;
  exitPrice: number;
  pnl: number;
  date: string;
}

export interface BacktestSession {
  id: string;
  name: string;
  strategy: string;
  date: string;
  trades: BacktestTrade[];
  initialBalance: number;
  currentBalance: number;
}

export interface BrokerConnection {
  id: string;
  provider: 'METATRADER' | 'TRADOVATE' | 'OANDA' | 'IBKR' | 'NONE';
  status: 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  accountName?: string;
  lastSync?: string;
}

export interface AppSettings {
  theme: 'light' | 'dark';
  language: 'fr' | 'en';
  currency: string;
  balance: number;
  broker?: BrokerConnection;
}
