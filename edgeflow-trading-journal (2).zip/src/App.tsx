import React, { useState, useEffect, useMemo } from 'react';
import { 
  LayoutDashboard, 
  Calendar as CalendarIcon, 
  BookOpen, 
  History, 
  FlaskConical, 
  Settings as SettingsIcon,
  LogOut,
  Moon,
  Sun,
  Plus,
  Search,
  Bell,
  User,
  TrendingUp,
  TrendingDown,
  Activity,
  ChevronRight,
  Filter,
  Download,
  MoreVertical,
  X,
  Trash2,
  Zap,
  Target,
  Brain,
  Shield,
  Image as ImageIcon,
  PieChart as PieChartIcon,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths, isSameMonth, startOfWeek, endOfWeek } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { Trade, JournalEntry, BacktestSession, BacktestTrade, AppSettings, TradeStatus, TradeRating } from './types';
import { translations } from './translations';
import { supabase } from './lib/supabase';
import { User as SupabaseUser } from '@supabase/supabase-js';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

const Badge = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase", className)}>
    {children}
  </span>
);

const StatCard = ({ label, value, icon: Icon, trend, color }: any) => (
  <motion.div 
    whileHover={{ y: -4 }}
    className="card card-hover flex flex-col gap-4"
  >
    <div className="flex justify-between items-start">
      <div className={cn("p-3 rounded-xl bg-gradient-to-br opacity-80", color.replace('text-', 'from-').replace('text-', 'to-') + '/20')}>
        <Icon size={20} className={color} />
      </div>
      {trend && (
        <span className={cn("px-2 py-1 rounded-lg text-[10px] font-black flex items-center gap-1", trend > 0 ? "bg-[var(--ok)]/10 text-[var(--ok)]" : "bg-[var(--ko)]/10 text-[var(--ko)]")}>
          {trend > 0 ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
          {Math.abs(trend)}%
        </span>
      )}
    </div>
    <div>
      <div className="text-[var(--muted)] text-[10px] font-bold uppercase tracking-[0.1em] mb-1">{label}</div>
      <div className="text-3xl font-black tracking-tight text-gradient">{value}</div>
    </div>
  </motion.div>
);

// --- Views ---

const PropFirmTracker = ({ trades, balance }: { trades: Trade[], balance: number }) => {
  const totalPnl = useMemo(() => trades.reduce((acc, t) => acc + t.pnl, 0), [trades]);
  const dailyPnl = useMemo(() => trades
    .filter(t => isSameDay(new Date(t.date), new Date()))
    .reduce((acc, t) => acc + t.pnl, 0), [trades]);

  // Mock targets for a 100k account
  const target = 10000;
  const dailyLimit = -5000;
  const maxLimit = -10000;

  const progress = useMemo(() => Math.min(Math.max((totalPnl / target) * 100, 0), 100), [totalPnl, target]);
  const dailyDrawdown = useMemo(() => Math.min(Math.max((dailyPnl / dailyLimit) * 100, 0), 100), [dailyPnl, dailyLimit]);
  const maxDrawdown = useMemo(() => Math.min(Math.max((totalPnl / maxLimit) * 100, 0), 100), [totalPnl, maxLimit]);

  const status = useMemo(() => totalPnl >= target ? 'PASSED' : 
                 (dailyPnl <= dailyLimit * 0.8 || totalPnl <= maxLimit * 0.8) ? 'CRITICAL' :
                 (dailyPnl < 0 || totalPnl < 0) ? 'WARNING' : 'HEALTHY', [totalPnl, dailyPnl, target, dailyLimit, maxLimit]);

  return (
    <div className="card flex flex-col gap-4 bg-[var(--surface)] border-[var(--line)] relative overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-transparent to-[var(--brand2)]/5 -mr-12 -mt-12 blur-2xl" />
      <div className="flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2 text-[var(--brand2)]">
          <Activity size={18} />
          <h3 className="font-bold text-sm uppercase tracking-widest">Prop Firm Objectives</h3>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={cn(
            "text-[8px] font-black px-2 py-0.5",
            status === 'PASSED' ? "bg-[var(--ok)]/20 text-[var(--ok)]" :
            status === 'CRITICAL' ? "bg-[var(--ko)]/20 text-[var(--ko)]" :
            status === 'WARNING' ? "bg-orange-500/20 text-orange-500" :
            "bg-blue-500/20 text-blue-500"
          )}>
            {status}
          </Badge>
          <Badge className="bg-[var(--brand2)]/10 text-[var(--brand2)] text-[8px] font-black px-2 py-0.5">Phase 1</Badge>
        </div>
      </div>
      
      <div className="flex flex-col gap-4 relative z-10">
        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-[10px] font-bold uppercase">
            <span className="text-[var(--muted)]">Profit Target</span>
            <span>${totalPnl.toFixed(0)} / ${target}</span>
          </div>
          <div className="h-2 bg-[var(--line)] rounded-full overflow-hidden">
            <div className="h-full bg-[var(--brand)] transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-[10px] font-bold uppercase">
            <span className="text-[var(--muted)]">Daily Loss Limit</span>
            <span className={cn(dailyPnl < 0 ? "text-[var(--ko)]" : "text-[var(--ok)]")}>${dailyPnl.toFixed(0)} / ${dailyLimit}</span>
          </div>
          <div className="h-2 bg-[var(--line)] rounded-full overflow-hidden">
            <div className="h-full bg-[var(--ko)] transition-all duration-500" style={{ width: `${dailyDrawdown}%` }} />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-[10px] font-bold uppercase">
            <span className="text-[var(--muted)]">Max Loss Limit</span>
            <span className={cn(totalPnl < 0 ? "text-[var(--ko)]" : "text-[var(--ok)]")}>${totalPnl.toFixed(0)} / ${maxLimit}</span>
          </div>
          <div className="h-2 bg-[var(--line)] rounded-full overflow-hidden">
            <div className="h-full bg-[var(--ko)] transition-all duration-500" style={{ width: `${maxDrawdown}%` }} />
          </div>
        </div>
      </div>
    </div>
  );
};

const Dashboard = ({ trades, theme, onAddTrade, settings, setIsBrokerModalOpen, isSyncing, onSync, t }: { trades: Trade[], theme: 'light' | 'dark', onAddTrade: () => void, settings: AppSettings, setIsBrokerModalOpen: (b: boolean) => void, isSyncing: boolean, onSync: () => void, t: any }) => {
  const totalPnl = useMemo(() => trades.reduce((acc, t) => acc + t.pnl, 0), [trades]);
  const wins = useMemo(() => trades.filter(t => t.status === 'WIN'), [trades]);
  const losses = useMemo(() => trades.filter(t => t.status === 'LOSS'), [trades]);
  const winRate = useMemo(() => trades.length > 0 ? (wins.length / trades.length) * 100 : 0, [trades, wins]);
  
  const totalWinAmount = useMemo(() => wins.reduce((acc, t) => acc + t.pnl, 0), [wins]);
  const totalLossAmount = useMemo(() => Math.abs(losses.reduce((acc, t) => acc + t.pnl, 0)), [losses]);
  const profitFactor = useMemo(() => totalLossAmount > 0 ? totalWinAmount / totalLossAmount : totalWinAmount > 0 ? Infinity : 0, [totalWinAmount, totalLossAmount]);
  
  const avgWin = useMemo(() => wins.length > 0 ? totalWinAmount / wins.length : 0, [wins, totalWinAmount]);
  const avgLoss = useMemo(() => losses.length > 0 ? totalLossAmount / losses.length : 0, [losses, totalLossAmount]);
  const rrRatio = useMemo(() => avgLoss > 0 ? avgWin / avgLoss : 0, [avgWin, avgLoss]);
  
  const expectancy = useMemo(() => trades.length > 0 ? (totalPnl / trades.length) : 0, [trades, totalPnl]);

  // Advanced Stats
  const bestTrade = useMemo(() => trades.length > 0 ? Math.max(...trades.map(t => t.pnl)) : 0, [trades]);
  const worstTrade = useMemo(() => trades.length > 0 ? Math.min(...trades.map(t => t.pnl)) : 0, [trades]);
  
  // Calculate streaks
  const streaks = useMemo(() => {
    let maxWinStreak = 0;
    let maxLossStreak = 0;
    let tempStreak = 0;

    trades.slice().reverse().forEach(t => {
      if (t.status === 'WIN') {
        if (tempStreak > 0) tempStreak++;
        else tempStreak = 1;
        maxWinStreak = Math.max(maxWinStreak, tempStreak);
      } else if (t.status === 'LOSS') {
        if (tempStreak < 0) tempStreak--;
        else tempStreak = -1;
        maxLossStreak = Math.max(maxLossStreak, Math.abs(tempStreak));
      } else {
        tempStreak = 0;
      }
    });
    return { maxWinStreak, maxLossStreak };
  }, [trades]);

  // Prepare chart data
  const chartData = useMemo(() => {
    let cumulativePnl = 0;
    return trades.slice().reverse().map((t, i) => {
      cumulativePnl += t.pnl;
      return {
        name: i + 1,
        pnl: cumulativePnl,
        tradePnl: t.pnl
      };
    });
  }, [trades]);

  // Performance by Day of Week
  const pnlByDay = useMemo(() => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days.map(day => {
      const dayTrades = trades.filter(t => format(new Date(t.date), 'EEEE') === day);
      return {
        day,
        pnl: dayTrades.reduce((acc, t) => acc + t.pnl, 0),
        count: dayTrades.length
      };
    });
  }, [trades]);

  // Performance by Setup
  const pnlBySetup = useMemo(() => {
    const setups = Array.from(new Set(trades.map(t => t.setup || 'Unknown')));
    return setups.map(setup => {
      const setupTrades = trades.filter(t => (t.setup || 'Unknown') === setup);
      return {
        setup,
        pnl: setupTrades.reduce((acc, t) => acc + t.pnl, 0),
        count: setupTrades.length,
        winRate: setupTrades.length > 0 ? (setupTrades.filter(t => t.status === 'WIN').length / setupTrades.length) * 100 : 0
      };
    });
  }, [trades]);

  // Performance by Asset
  const pnlByAsset = useMemo(() => {
    const assets = Array.from(new Set(trades.map(t => t.symbol)));
    return assets.map(asset => {
      const assetTrades = trades.filter(t => t.symbol === asset);
      return {
        asset,
        pnl: assetTrades.reduce((acc, t) => acc + t.pnl, 0),
        count: assetTrades.length,
        winRate: assetTrades.length > 0 ? (assetTrades.filter(t => t.status === 'WIN').length / assetTrades.length) * 100 : 0
      };
    }).sort((a, b) => b.pnl - a.pnl).slice(0, 5);
  }, [trades]);

  // Performance by Hour
  const pnlByHour = useMemo(() => {
    const hours = Array.from({ length: 24 }, (_, i) => i);
    return hours.map(hour => {
      const hourTrades = trades.filter(t => {
        const tradeHour = parseInt((t.entryTime || '00:00').split(':')[0]);
        return tradeHour === hour;
      });
      return {
        hour: `${hour}:00`,
        pnl: hourTrades.reduce((acc, t) => acc + t.pnl, 0),
        count: hourTrades.length
      };
    }).filter(h => h.count > 0);
  }, [trades]);

  // Performance by Session
  const pnlBySession = useMemo(() => {
    const getSession = (time: string) => {
      const hour = parseInt(time.split(':')[0]);
      if (hour >= 0 && hour < 8) return 'Asia';
      if (hour >= 8 && hour < 13) return 'London';
      if (hour >= 13 && hour < 21) return 'New York';
      return 'After Hours';
    };

    const sessions = ['Asia', 'London', 'New York', 'After Hours'];
    return sessions.map(session => {
      const sessionTrades = trades.filter(t => getSession(t.entryTime || '00:00') === session);
      return {
        session,
        pnl: sessionTrades.reduce((acc, t) => acc + t.pnl, 0),
        count: sessionTrades.length,
        winRate: sessionTrades.length > 0 ? (sessionTrades.filter(t => t.status === 'WIN').length / sessionTrades.length) * 100 : 0
      };
    });
  }, [trades]);

  // Best of Highlights
  const bestDay = useMemo(() => pnlByDay.reduce((prev, current) => (prev.pnl > current.pnl) ? prev : current, pnlByDay[0] || { day: 'N/A', pnl: 0 }), [pnlByDay]);
  const bestHour = useMemo(() => pnlByHour.reduce((prev, current) => (prev.pnl > current.pnl) ? prev : current, pnlByHour[0] || { hour: 'N/A', pnl: 0 }), [pnlByHour]);
  const bestPair = useMemo(() => pnlByAsset[0] || { asset: 'N/A', pnl: 0 }, [pnlByAsset]);
  const bestSession = useMemo(() => pnlBySession.reduce((prev, current) => (prev.pnl > current.pnl) ? prev : current, pnlBySession[0] || { session: 'N/A', pnl: 0 }), [pnlBySession]);

  const pnlByRating = useMemo(() => {
    const ratings: TradeRating[] = ['A+', 'A', 'B', 'C', 'D', 'F'];
    return ratings.map(rating => {
      const ratingTrades = trades.filter(t => t.rating === rating);
      return {
        rating,
        pnl: ratingTrades.reduce((acc, t) => acc + t.pnl, 0),
        count: ratingTrades.length,
        winRate: ratingTrades.length > 0 ? (ratingTrades.filter(t => t.status === 'WIN').length / ratingTrades.length) * 100 : 0
      };
    }).filter(r => r.count > 0);
  }, [trades]);

  if (trades.length === 0) {
    return (
      <div className="flex flex-col gap-12 py-12">
        <div className="flex flex-col gap-6 max-w-2xl">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 px-4 py-2 rounded-full bg-[var(--brand)]/10 border border-[var(--brand)]/20 w-fit"
          >
            <span className="w-2 h-2 rounded-full bg-[var(--brand)] animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-widest text-[var(--brand)]">Welcome to EdgeFlow</span>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl lg:text-7xl font-black tracking-tighter leading-[0.9] text-white"
          >
            {t.yourEdge} <br />
            <span className="text-gradient">{t.quantified}</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-lg text-[var(--muted)] max-w-lg"
          >
            {t.startDocumenting}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: t.journaling, desc: t.journalingDesc, icon: BookOpen, color: 'text-[var(--brand)]' },
            { title: t.analytics, desc: t.analyticsDesc, icon: Activity, color: 'text-[var(--brand2)]' },
            { title: t.backtesting, desc: t.backtestingDesc, icon: FlaskConical, color: 'text-[var(--ok)]' },
          ].map((feature, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + (i * 0.1) }}
              className="card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-4 group hover:border-[var(--brand)]/30 transition-all"
            >
              <div className={cn("w-12 h-12 rounded-2xl bg-[var(--bg)] flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform", feature.color)}>
                <feature.icon size={24} />
              </div>
              <h3 className="text-xl font-black tracking-tight">{feature.title}</h3>
              <p className="text-sm text-[var(--muted)] leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6 }}
          className="card bg-gradient-to-br from-[var(--brand)]/20 to-[var(--brand2)]/20 border-[var(--brand)]/30 p-12 flex flex-col items-center text-center gap-8 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--brand)]/10 blur-[100px] -mr-32 -mt-32" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-[var(--brand2)]/10 blur-[100px] -ml-32 -mb-32" />
          
          <div className="flex flex-col gap-2 relative z-10">
            <h2 className="text-3xl font-black tracking-tight">{t.readyToStart}</h2>
            <p className="text-[var(--muted)] font-bold uppercase tracking-widest text-xs">{t.firstTradeWaiting}</p>
          </div>
          
          <button 
            onClick={onAddTrade} 
            className="btn btn-primary py-5 px-12 rounded-2xl text-sm font-black uppercase tracking-[0.2em] relative z-10 shadow-2xl shadow-[var(--brand-glow)]"
          >
            {t.logFirstTrade}
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-10 pb-20">
      {/* Bento Grid Header */}
      <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-6 gap-6">
        {/* Main Stat: Net P&L */}
        <div className="md:col-span-2 lg:col-span-2 card bg-gradient-to-br from-[var(--surface)] to-[var(--bg)] border-[var(--line)] p-10 flex flex-col justify-between relative overflow-hidden group min-h-[240px]">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--brand)]/10 blur-[100px] -mr-32 -mt-32 group-hover:bg-[var(--brand)]/20 transition-all duration-700" />
          <div className="flex items-center justify-between relative z-10">
            <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[var(--muted)]">{t.netPerformance}</span>
              <h2 className="text-sm font-bold text-white mt-1">{t.totalProfit}</h2>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)] shadow-inner">
              <Activity size={24} />
            </div>
          </div>
          <div className="flex flex-col relative z-10">
            <span className={cn("text-6xl font-black tracking-tighter leading-none", totalPnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
              {totalPnl >= 0 ? '+' : ''}{totalPnl.toFixed(0)}<span className="text-2xl ml-1">€</span>
            </span>
            <div className="flex items-center gap-2 mt-4">
              <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[var(--ok)]/10 text-[var(--ok)] text-[10px] font-black uppercase tracking-widest">
                <TrendingUp size={10} /> +12.4%
              </div>
              <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">{t.vsLastMonth}</span>
            </div>
          </div>
        </div>

        {/* Win Rate Circle */}
        <div className="md:col-span-2 lg:col-span-2 card bg-[var(--surface)] border-[var(--line)] p-10 flex flex-col justify-between relative overflow-hidden group min-h-[240px]">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--ok)]/5 blur-[100px] -mr-32 -mt-32 group-hover:bg-[var(--ok)]/10 transition-all duration-700" />
          <div className="flex items-center justify-between relative z-10">
            <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[var(--muted)]">{t.successRate}</span>
              <h2 className="text-sm font-bold text-white mt-1">{t.winLossDist}</h2>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-[var(--ok)]/10 flex items-center justify-center text-[var(--ok)] shadow-inner">
              <Target size={24} />
            </div>
          </div>
          <div className="flex items-end justify-between relative z-10">
            <div className="flex flex-col">
              <span className="text-6xl font-black tracking-tighter leading-none text-white">
                {winRate.toFixed(0)}<span className="text-2xl ml-1">%</span>
              </span>
              <div className="flex items-center gap-3 mt-4">
                <div className="flex flex-col">
                  <span className="text-[8px] font-black uppercase tracking-widest text-[var(--ok)]">{t.wins}</span>
                  <span className="text-sm font-black text-white">{wins.length}</span>
                </div>
                <div className="w-[1px] h-6 bg-[var(--line)]" />
                <div className="flex flex-col">
                  <span className="text-[8px] font-black uppercase tracking-widest text-[var(--ko)]">{t.losses}</span>
                  <span className="text-sm font-black text-white">{losses.length}</span>
                </div>
              </div>
            </div>
            {/* Simple Progress Circle Mockup */}
            <div className="relative w-24 h-24 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                <circle cx="48" cy="48" r="40" stroke="var(--line)" strokeWidth="8" fill="transparent" />
                <circle 
                  cx="48" cy="48" r="40" stroke="var(--ok)" strokeWidth="8" fill="transparent" 
                  strokeDasharray={251.2} 
                  strokeDashoffset={251.2 * (1 - winRate / 100)} 
                  strokeLinecap="round"
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <Zap size={20} className="text-[var(--ok)]" />
              </div>
            </div>
          </div>
        </div>

        {/* Profit Factor & Expectancy */}
        <div className="md:col-span-2 lg:col-span-2 flex flex-col gap-6">
          <div className="flex-1 card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col justify-between group overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--brand)]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[var(--brand)]/10 transition-all" />
            <div className="flex justify-between items-start relative z-10">
              <div className="flex flex-col">
                <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">{t.brokerStatus}</span>
                <div className="flex items-center gap-2 mt-1">
                  <span className={cn(
                    "text-xl font-black tracking-tighter",
                    settings.broker?.status === 'CONNECTED' ? "text-[var(--ok)]" : "text-white"
                  )}>
                    {isSyncing ? t.syncing : settings.broker?.status === 'CONNECTED' ? `${t.connected}: ${settings.broker.provider}` : t.notConnected}
                  </span>
                  {isSyncing && <RefreshCw size={14} className="animate-spin text-[var(--brand)]" />}
                </div>
                {settings.broker?.status === 'CONNECTED' && !isSyncing && (
                  <div className="flex flex-col gap-0.5 mt-2">
                    <span className="text-[10px] font-black text-white/80 tracking-tight">ID: {settings.broker.id.substring(0, 8)}...</span>
                    <span className="text-[10px] font-black text-[var(--ok)] tracking-tight">Balance: {settings.balance.toLocaleString()}€</span>
                  </div>
                )}
                {settings.broker?.lastSync && !isSyncing && (
                  <span className="text-[8px] font-bold text-[var(--muted)] uppercase tracking-widest mt-2 block">
                    {t.lastSync}: {format(new Date(settings.broker.lastSync), 'HH:mm:ss')}
                  </span>
                )}
              </div>
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-500",
                isSyncing ? "bg-[var(--brand)]/20 text-[var(--brand)] animate-pulse" :
                settings.broker?.status === 'CONNECTED' ? "bg-[var(--ok)]/10 text-[var(--ok)]" : "bg-[var(--ko)]/10 text-[var(--ko)]"
              )}>
                {isSyncing ? <RefreshCw size={18} className="animate-spin" /> : 
                 settings.broker?.status === 'CONNECTED' ? <Activity size={18} /> : <LogOut size={18} />}
              </div>
            </div>
            <div className="flex gap-2 mt-4 relative z-10">
              <button 
                onClick={() => setIsBrokerModalOpen(true)}
                disabled={isSyncing}
                className="btn btn-primary py-2 px-4 text-[8px] font-black uppercase tracking-widest flex-1 disabled:opacity-50"
              >
                {settings.broker?.status === 'CONNECTED' ? t.manage : t.connect}
              </button>
              {settings.broker?.status === 'CONNECTED' && (
                <button 
                  onClick={onSync}
                  disabled={isSyncing}
                  className="btn border-[var(--line)] py-2 px-4 text-[8px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:border-[var(--brand)] transition-all disabled:opacity-50"
                >
                  <RefreshCw size={10} className={cn(isSyncing && "animate-spin")} />
                  {t.syncNow}
                </button>
              )}
            </div>
          </div>
          <div className="flex-1 card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col justify-between group overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--brand2)]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[var(--brand2)]/10 transition-all" />
            <div className="flex justify-between items-start relative z-10">
              <div className="flex flex-col">
                <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">{t.profitFactor}</span>
                <span className="text-3xl font-black tracking-tighter text-white mt-1">
                  {profitFactor === Infinity ? '∞' : profitFactor.toFixed(2)}
                </span>
              </div>
              <div className="w-10 h-10 rounded-xl bg-[var(--brand2)]/10 flex items-center justify-center text-[var(--brand2)]">
                <Zap size={18} />
              </div>
            </div>
            <div className="h-1.5 bg-[var(--line)] rounded-full mt-4 overflow-hidden relative z-10">
              <div 
                className="h-full bg-[var(--brand2)] transition-all duration-1000" 
                style={{ width: `${Math.min((profitFactor / 3) * 100, 100)}%` }} 
              />
            </div>
          </div>
        </div>
      </div>

      {/* Highlights Bento */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex items-center gap-4 group hover:border-[var(--brand)] transition-all">
          <div className="w-12 h-12 rounded-2xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]">
            <CalendarIcon size={20} />
          </div>
          <div className="flex flex-col">
            <span className="text-[8px] font-black uppercase tracking-widest text-[var(--muted)]">{t.bestDay}</span>
            <span className="text-sm font-black text-white">{bestDay.day}</span>
            <span className="text-[10px] font-bold text-[var(--ok)]">+{bestDay.pnl.toFixed(0)}€</span>
          </div>
        </div>
        <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex items-center gap-4 group hover:border-[var(--brand2)] transition-all">
          <div className="w-12 h-12 rounded-2xl bg-[var(--brand2)]/10 flex items-center justify-center text-[var(--brand2)]">
            <Activity size={20} />
          </div>
          <div className="flex flex-col">
            <span className="text-[8px] font-black uppercase tracking-widest text-[var(--muted)]">{t.bestPair}</span>
            <span className="text-sm font-black text-white">{bestPair.asset}</span>
            <span className="text-[10px] font-bold text-[var(--ok)]">+{bestPair.pnl.toFixed(0)}€</span>
          </div>
        </div>
        <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex items-center gap-4 group hover:border-[var(--ok)] transition-all">
          <div className="w-12 h-12 rounded-2xl bg-[var(--ok)]/10 flex items-center justify-center text-[var(--ok)]">
            <TrendingUp size={20} />
          </div>
          <div className="flex flex-col">
            <span className="text-[8px] font-black uppercase tracking-widest text-[var(--muted)]">{t.bestSession}</span>
            <span className="text-sm font-black text-white">{bestSession.session}</span>
            <span className="text-[10px] font-bold text-[var(--ok)]">+{bestSession.pnl.toFixed(0)}€</span>
          </div>
        </div>
        <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex items-center gap-4 group hover:border-[var(--brand)] transition-all">
          <div className="w-12 h-12 rounded-2xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]">
            <Zap size={20} />
          </div>
          <div className="flex flex-col">
            <span className="text-[8px] font-black uppercase tracking-widest text-[var(--muted)]">{t.bestHour}</span>
            <span className="text-sm font-black text-white">{bestHour.hour}</span>
            <span className="text-[10px] font-bold text-[var(--ok)]">+{bestHour.pnl.toFixed(0)}€</span>
          </div>
        </div>
      </div>

      {/* Performance by Rating */}
      <div className="card bg-[var(--surface)] border-[var(--line)] p-10 flex flex-col gap-8">
        <div className="flex justify-between items-center">
          <div className="flex flex-col gap-1">
            <h3 className="text-xl font-black tracking-tight">Performance by Setup Rating</h3>
            <p className="text-[var(--muted)] text-xs font-bold uppercase tracking-widest">Analyze your edge based on trade quality</p>
          </div>
          <div className="p-3 rounded-xl bg-[var(--brand)]/10 text-[var(--brand)]">
            <Brain size={20} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pnlByRating.map((r, i) => (
            <div key={i} className="p-6 rounded-3xl bg-[var(--bg)] border border-[var(--line)] flex flex-col gap-4 hover:border-[var(--brand)]/30 transition-all group">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm",
                    r.rating === 'A+' || r.rating === 'A' ? "bg-[var(--ok)]/10 text-[var(--ok)]" :
                    r.rating === 'B' ? "bg-blue-500/10 text-blue-500" :
                    "bg-[var(--ko)]/10 text-[var(--ko)]"
                  )}>
                    {r.rating}
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Rating</span>
                    <span className="text-sm font-black text-white">{r.count} Trades</span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Win Rate</span>
                  <span className="text-sm font-black text-[var(--ok)]">{r.winRate.toFixed(0)}%</span>
                </div>
              </div>
              <div className="flex justify-between items-end mt-2">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Net P&L</span>
                  <span className={cn("text-xl font-black tracking-tighter", r.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                    {r.pnl >= 0 ? '+' : ''}{r.pnl.toFixed(0)}€
                  </span>
                </div>
                <div className="w-24 h-1 bg-[var(--line)] rounded-full overflow-hidden">
                  <div 
                    className={cn("h-full transition-all duration-1000", r.pnl >= 0 ? "bg-[var(--ok)]" : "bg-[var(--ko)]")}
                    style={{ width: `${Math.min(Math.abs(r.pnl) / 1000 * 100, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Analytics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Equity Curve - Large */}
        <div className="lg:col-span-8 flex flex-col gap-8">
          <div className="card bg-[var(--surface)] border-[var(--line)] p-10 flex flex-col gap-10 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[var(--brand)] via-[var(--brand2)] to-[var(--brand)] opacity-50" />
            <div className="flex justify-between items-end">
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-[var(--brand)] animate-pulse" />
                  <h3 className="font-black text-2xl tracking-tighter text-white">Equity Curve</h3>
                </div>
                <p className="text-[var(--muted)] text-[10px] font-black uppercase tracking-[0.2em]">Cumulative performance & drawdown analysis</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex flex-col items-end">
                  <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Current Drawdown</span>
                  <span className="text-sm font-black text-[var(--ko)]">-2.4%</span>
                </div>
                <div className="h-8 w-[1px] bg-[var(--line)]" />
                <div className="flex gap-2">
                  {['1W', '1M', '3M', 'ALL'].map((p) => (
                    <button key={p} className={cn(
                      "px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all",
                      p === 'ALL' ? "bg-[var(--brand)] text-white shadow-lg shadow-[var(--brand-glow)]" : "bg-[var(--bg)] text-[var(--muted)] hover:text-white"
                    )}>
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="h-[450px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorPnl" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--brand)" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="var(--brand)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" vertical={false} opacity={0.5} />
                  <XAxis 
                    dataKey="name" 
                    stroke="var(--muted)" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tick={{ fontWeight: 900 }}
                    dy={15}
                  />
                  <YAxis 
                    stroke="var(--muted)" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(value) => `${value}€`} 
                    tick={{ fontWeight: 900 }}
                    dx={-15}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'var(--surface)', border: '1px solid var(--line)', borderRadius: '24px', boxShadow: '0 30px 60px rgba(0,0,0,0.5)', padding: '24px', backdropFilter: 'blur(10px)' }}
                    itemStyle={{ color: 'var(--brand)', fontWeight: 900, fontSize: '18px' }}
                    labelStyle={{ color: 'var(--muted)', fontWeight: 900, fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.2em', marginBottom: '8px' }}
                    cursor={{ stroke: 'var(--brand)', strokeWidth: 2, strokeDasharray: '5 5' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="pnl" 
                    stroke="var(--brand)" 
                    fillOpacity={1} 
                    fill="url(#colorPnl)" 
                    strokeWidth={5} 
                    animationDuration={2000}
                    animationEasing="ease-in-out"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Performance by Day */}
            <div className="card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-8 group">
              <div className="flex justify-between items-center">
                <div className="flex flex-col">
                  <h3 className="font-black text-lg tracking-tight text-white">Daily Edge</h3>
                  <p className="text-[var(--muted)] text-[10px] font-black uppercase tracking-widest">P&L distribution by weekday</p>
                </div>
                <CalendarIcon size={18} className="text-[var(--muted)] group-hover:text-[var(--brand)] transition-colors" />
              </div>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={pnlByDay}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" vertical={false} opacity={0.3} />
                    <XAxis 
                      dataKey="day" 
                      stroke="var(--muted)" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false} 
                      tickFormatter={(val) => val.substring(0, 3)}
                      tick={{ fontWeight: 900 }}
                    />
                    <YAxis hide />
                    <Tooltip 
                      cursor={{ fill: 'var(--line)', opacity: 0.2 }}
                      contentStyle={{ backgroundColor: 'var(--surface)', border: '1px solid var(--line)', borderRadius: '16px' }}
                    />
                    <Bar dataKey="pnl" radius={[6, 6, 0, 0]}>
                      {pnlByDay.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? 'var(--ok)' : 'var(--ko)'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Session Performance */}
            <div className="card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-8 group">
              <div className="flex justify-between items-center">
                <div className="flex flex-col">
                  <h3 className="font-black text-lg tracking-tight text-white">Session Edge</h3>
                  <p className="text-[var(--muted)] text-[10px] font-black uppercase tracking-widest">P&L distribution by trading session</p>
                </div>
                <Activity size={18} className="text-[var(--muted)] group-hover:text-[var(--brand)] transition-colors" />
              </div>
              <div className="flex flex-col gap-5">
                {pnlBySession.map((s, i) => (
                  <div key={i} className="flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          "w-2 h-2 rounded-full",
                          s.session === 'London' ? "bg-blue-400" : s.session === 'New York' ? "bg-orange-400" : "bg-purple-400"
                        )} />
                        <span className="text-sm font-black text-white">{s.session}</span>
                      </div>
                      <span className={cn("text-xs font-black", s.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                        {s.pnl >= 0 ? '+' : ''}{s.pnl.toFixed(0)}€
                      </span>
                    </div>
                    <div className="h-1.5 bg-[var(--line)] rounded-full overflow-hidden">
                      <div 
                        className={cn("h-full transition-all duration-1000", s.pnl >= 0 ? "bg-[var(--ok)]" : "bg-[var(--ko)]")} 
                        style={{ width: `${Math.max(Math.min((Math.abs(s.pnl) / (totalPnl || 1000)) * 100, 100), 5)}%` }} 
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Performance by Hour */}
            <div className="card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-8 group">
              <div className="flex justify-between items-center">
                <div className="flex flex-col">
                  <h3 className="font-black text-lg tracking-tight text-white">Hourly Edge</h3>
                  <p className="text-[var(--muted)] text-[10px] font-black uppercase tracking-widest">P&L distribution by entry hour</p>
                </div>
                <Activity size={18} className="text-[var(--muted)] group-hover:text-[var(--brand)] transition-colors" />
              </div>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={pnlByHour}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" vertical={false} opacity={0.3} />
                    <XAxis 
                      dataKey="hour" 
                      stroke="var(--muted)" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false} 
                      tick={{ fontWeight: 900 }}
                    />
                    <YAxis hide />
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'var(--surface)', border: '1px solid var(--line)', borderRadius: '16px' }}
                    />
                    <Area type="monotone" dataKey="pnl" stroke="var(--brand)" fill="var(--brand)" fillOpacity={0.1} strokeWidth={3} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Asset Performance */}
            <div className="card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-8 group">
              <div className="flex justify-between items-center">
                <div className="flex flex-col">
                  <h3 className="font-black text-lg tracking-tight text-white">Top Assets</h3>
                  <p className="text-[var(--muted)] text-[10px] font-black uppercase tracking-widest">Most profitable instruments</p>
                </div>
                <PieChartIcon size={18} className="text-[var(--muted)] group-hover:text-[var(--brand2)] transition-colors" />
              </div>
              <div className="flex flex-col gap-5">
                {pnlByAsset.map((a, i) => (
                  <div key={i} className="flex items-center justify-between group/item">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-center font-black text-xs text-white group-hover/item:border-[var(--brand)] transition-colors">
                        {a.asset.substring(0, 3)}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-sm font-black text-white">{a.asset}</span>
                        <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">{a.count} Trades</span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className={cn("text-sm font-black", a.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                        {a.pnl >= 0 ? '+' : ''}{a.pnl.toFixed(0)}€
                      </span>
                      <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">{a.winRate.toFixed(0)}% WR</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Analytics */}
        <div className="lg:col-span-4 flex flex-col gap-8">
          <PropFirmTracker trades={trades} balance={100000} />

          <div className="card bg-[var(--surface)] border-[var(--line)] p-10 flex flex-col gap-8 shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--brand)]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[var(--brand)]/10 transition-all" />
            <div className="flex flex-col">
              <h3 className="font-black text-xl tracking-tighter text-white">Performance DNA</h3>
              <p className="text-[var(--muted)] text-[10px] font-black uppercase tracking-widest">Your trading behavior quantified</p>
            </div>
            
            <div className="flex flex-col gap-6">
              {/* Avg Win/Loss Bento Item */}
              <div className="p-6 rounded-3xl bg-[var(--bg)]/50 border border-[var(--line)] flex flex-col gap-4 hover:border-[var(--brand)]/30 transition-all">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Risk/Reward Efficiency</span>
                  <div className="px-2 py-1 rounded-lg bg-[var(--brand)]/10 text-[var(--brand)] text-[8px] font-black uppercase tracking-widest">
                    1:{rrRatio.toFixed(2)}
                  </div>
                </div>
                <div className="flex items-end justify-between">
                  <div className="flex flex-col">
                    <span className="text-[8px] font-black uppercase tracking-widest text-[var(--ok)]">Avg Win</span>
                    <span className="text-2xl font-black text-white">+{avgWin.toFixed(0)}€</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-[8px] font-black uppercase tracking-widest text-[var(--ko)]">Avg Loss</span>
                    <span className="text-2xl font-black text-white">-{avgLoss.toFixed(0)}€</span>
                  </div>
                </div>
                <div className="h-1.5 bg-[var(--line)] rounded-full overflow-hidden flex">
                  <div className="h-full bg-[var(--ok)]" style={{ width: `${(avgWin / (avgWin + avgLoss)) * 100}%` }} />
                  <div className="h-full bg-[var(--ko)]" style={{ width: `${(avgLoss / (avgWin + avgLoss)) * 100}%` }} />
                </div>
              </div>

              {/* Streaks Bento Item */}
              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 rounded-3xl bg-[var(--bg)]/50 border border-[var(--line)] flex flex-col gap-2 hover:border-[var(--ok)]/30 transition-all">
                  <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Win Streak</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-black text-white">{streaks.maxWinStreak}</span>
                    <span className="text-[10px] font-bold text-[var(--ok)] uppercase tracking-widest">Trades</span>
                  </div>
                </div>
                <div className="p-6 rounded-3xl bg-[var(--bg)]/50 border border-[var(--line)] flex flex-col gap-2 hover:border-[var(--ko)]/30 transition-all">
                  <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Loss Streak</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-black text-white">{streaks.maxLossStreak}</span>
                    <span className="text-[10px] font-bold text-[var(--ko)] uppercase tracking-widest">Trades</span>
                  </div>
                </div>
              </div>

              {/* Extremes Bento Item */}
              <div className="p-6 rounded-3xl bg-[var(--bg)]/50 border border-[var(--line)] flex flex-col gap-4 hover:border-[var(--brand2)]/30 transition-all">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Trade Extremes</span>
                  <Zap size={14} className="text-[var(--brand2)]" />
                </div>
                <div className="flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-[var(--muted)]">Best Trade</span>
                    <span className="text-sm font-black text-[var(--ok)]">+{bestTrade.toFixed(0)}€</span>
                  </div>
                  <div className="h-[1px] bg-[var(--line)]" />
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-[var(--muted)]">Worst Trade</span>
                    <span className="text-sm font-black text-[var(--ko)]">-{Math.abs(worstTrade).toFixed(0)}€</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

const Calendar = ({ trades, t }: { trades: Trade[], t: any }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  
  const startOfFirstWeek = startOfWeek(monthStart, { weekStartsOn: 1 });
  const endOfLastWeek = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const allDays = eachDayOfInterval({ start: startOfFirstWeek, end: endOfLastWeek });

  const weeks: Date[][] = [];
  let currentWeek: Date[] = [];
  allDays.forEach((day, i) => {
    currentWeek.push(day);
    if ((i + 1) % 7 === 0) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
  });

  const getDayTrades = (day: Date) => trades.filter(t => isSameDay(new Date(t.date), day));
  
  const totalMonthPnl = trades
    .filter(t => isSameMonth(new Date(t.date), currentDate))
    .reduce((acc, t) => acc + t.pnl, 0);

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-4">
        <div className="flex justify-between items-center">
          <div className="flex flex-col">
            <h2 className="text-3xl font-black text-gradient">Journal quotidien</h2>
            <div className="text-sm font-bold text-[var(--muted)] uppercase tracking-widest">{format(currentDate, 'MMMM yyyy')}</div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setCurrentDate(subMonths(currentDate, 1))} className="btn p-3 rounded-xl">
              <ChevronRight size={18} className="rotate-180" />
            </button>
            <button onClick={() => setCurrentDate(new Date())} className="btn px-6 rounded-xl font-black text-xs uppercase tracking-widest">Today</button>
            <button onClick={() => setCurrentDate(addMonths(currentDate, 1))} className="btn p-3 rounded-xl">
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
        <div className="flex items-center gap-4 p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
          <div className="flex flex-col">
            <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">Monthly Performance</span>
            <span className={cn("text-xl font-black", totalMonthPnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
              {totalMonthPnl >= 0 ? '+' : ''}{totalMonthPnl.toFixed(2)} €
            </span>
          </div>
          <div className="h-8 w-[1px] bg-[var(--line)]" />
          <div className="flex flex-col">
            <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">Trades</span>
            <span className="text-xl font-black">{trades.filter(t => isSameMonth(new Date(t.date), currentDate)).length}</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-10">
        {weeks.map((weekDays, wIdx) => {
          const weekPnl = weekDays.reduce((acc, day) => {
            return acc + getDayTrades(day).reduce((dAcc, t) => dAcc + t.pnl, 0);
          }, 0);

          return (
            <div key={wIdx} className="flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <div className="text-[10px] font-black text-[var(--muted)] uppercase tracking-[0.2em] whitespace-nowrap">Week {wIdx + 1}</div>
                <div className="h-[1px] flex-1 bg-gradient-to-r from-[var(--line)] to-transparent" />
                <div className={cn("text-[10px] font-black uppercase tracking-widest", weekPnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                  {weekPnl >= 0 ? '+' : ''}{weekPnl.toFixed(2)} €
                </div>
              </div>
              <div className="grid grid-cols-7 gap-4">
                {wIdx === 0 && ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(d => (
                  <div key={d} className="text-center text-[var(--muted)] text-[10px] font-black uppercase tracking-[0.2em] py-2">{d}</div>
                ))}
                {weekDays.map(day => {
                  const dayTrades = getDayTrades(day);
                  const dailyPnl = dayTrades.reduce((acc, t) => acc + t.pnl, 0);
                  const isCurrentMonth = isSameMonth(day, currentDate);

                  return (
                    <motion.div 
                      key={day.toString()} 
                      whileHover={{ y: -4 }}
                      className={cn(
                        "bg-[var(--surface)] border border-[var(--line)] min-h-[160px] p-4 rounded-2xl flex flex-col gap-3 transition-all hover:border-[var(--brand)]/50 cursor-pointer group relative overflow-hidden",
                        !isCurrentMonth && "opacity-20 grayscale",
                        isSameDay(day, new Date()) && "ring-2 ring-[var(--brand)]/50 border-[var(--brand)]"
                      )}
                    >
                      {isSameDay(day, new Date()) && (
                        <div className="absolute top-0 right-0 w-12 h-12 bg-gradient-to-bl from-[var(--brand)]/20 to-transparent rounded-bl-full" />
                      )}
                      <span className="text-xs font-black text-[var(--muted)] group-hover:text-white transition-colors">{format(day, 'dd')}</span>
                      <div className="flex flex-col gap-1.5 mt-auto">
                        {dayTrades.slice(0, 3).map(t => (
                          <div key={t.id} className={cn(
                            "text-[9px] font-black px-2 py-1 rounded-lg flex justify-between items-center",
                            t.pnl >= 0 ? "bg-[var(--ok)]/10 text-[var(--ok)]" : "bg-[var(--ko)]/10 text-[var(--ko)]"
                          )}>
                            <span>{t.symbol}</span>
                            <span>{t.pnl.toFixed(0)}€</span>
                          </div>
                        ))}
                        {dayTrades.length > 3 && (
                          <div className="text-[8px] font-bold text-[var(--muted)] text-center">+{dayTrades.length - 3} more</div>
                        )}
                        {dayTrades.length > 0 && (
                          <div className={cn(
                            "mt-2 pt-2 border-t border-[var(--line)] text-[11px] font-black text-right",
                            dailyPnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]"
                          )}>
                            {dailyPnl >= 0 ? '+' : ''}{dailyPnl.toFixed(2)}€
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const TradesList = ({ trades, onDelete, onSelect, t }: { trades: Trade[], onDelete: (id: string) => void, onSelect: (t: Trade) => void, t: any }) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<TradeStatus | 'ALL'>('ALL');

  const filteredTrades = trades.filter(t => {
    const matchesSearch = t.symbol.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || t.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="flex flex-col gap-8">
      {/* Summary Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-2">
          <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Total Trades</span>
          <span className="text-3xl font-black tracking-tight">{trades.length}</span>
        </div>
        <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-2">
          <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Win Rate</span>
          <span className="text-3xl font-black tracking-tight text-[var(--ok)]">
            {trades.length > 0 ? ((trades.filter(t => t.status === 'WIN').length / trades.length) * 100).toFixed(1) : 0}%
          </span>
        </div>
        <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-2">
          <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Net P&L</span>
          <span className={cn("text-3xl font-black tracking-tight", trades.reduce((acc, t) => acc + t.pnl, 0) >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
            {trades.reduce((acc, t) => acc + t.pnl, 0).toFixed(2)}€
          </span>
        </div>
        <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-2">
          <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Avg R</span>
          <span className="text-3xl font-black tracking-tight">
            {trades.length > 0 ? (trades.reduce((acc, t) => acc + (t.rMultiple || 0), 0) / trades.length).toFixed(2) : 0}R
          </span>
        </div>
      </div>

      <div className="card overflow-hidden p-0 flex flex-col border-[var(--line)] bg-[var(--surface)] shadow-xl">
        <div className="p-8 border-b border-[var(--line)] flex flex-col md:flex-row justify-between items-center gap-6 bg-[var(--surface)]/50">
          <div className="flex flex-col">
            <h3 className="font-black text-xl tracking-tight">Trading History</h3>
            <p className="text-[var(--muted)] text-xs font-bold uppercase tracking-widest">Detailed position logs</p>
          </div>
          <div className="flex gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:w-80">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--muted)]" size={18} />
              <input 
                type="text" 
                placeholder="Search symbol, setup, notes..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input pl-12 w-full py-3 text-sm" 
              />
            </div>
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="input w-40 py-3 text-sm font-bold"
            >
              <option value="ALL">All Status</option>
              <option value="WIN">Wins (TP)</option>
              <option value="LOSS">Losses (SL)</option>
              <option value="BREAKEVEN">Breakeven</option>
              <option value="PENDING">Pending</option>
            </select>
          </div>
        </div>
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[var(--bg)]/50">
                <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">Asset</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">Type</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">Status</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">Rating</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">Entry</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">Exit</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">P&L</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">Date</th>
                <th className="p-6"></th>
              </tr>
            </thead>
            <tbody>
              {filteredTrades.map(trade => (
                <tr 
                  key={trade.id} 
                  onClick={() => onSelect(trade)}
                  className="border-t border-[var(--line)] hover:bg-[var(--surface-hover)] transition-all group cursor-pointer"
                >
                  <td className="p-6">
                    <div className="flex flex-col">
                      <span className="font-black text-white tracking-tight">{trade.symbol}</span>
                      <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">{trade.setup || 'No Setup'}</span>
                    </div>
                  </td>
                  <td className="p-6">
                    <span className={cn(
                      "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest",
                      trade.type === 'BUY' ? "bg-[var(--ok)]/10 text-[var(--ok)]" : "bg-[var(--ko)]/10 text-[var(--ko)]"
                    )}>
                      {trade.type}
                    </span>
                  </td>
                  <td className="p-6">
                    <div className="flex items-center gap-2">
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        trade.status === 'WIN' ? "bg-[var(--ok)] shadow-[0_0_8px_var(--ok)]" : 
                        trade.status === 'LOSS' ? "bg-[var(--ko)] shadow-[0_0_8px_var(--ko)]" : 
                        trade.status === 'BREAKEVEN' ? "bg-gray-400" : "bg-[var(--brand)] shadow-[0_0_8px_var(--brand)]"
                      )} />
                      <span className="text-[10px] font-black uppercase tracking-widest text-white">{trade.status}</span>
                    </div>
                  </td>
                  <td className="p-6">
                    <div className={cn(
                      "w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs",
                      trade.rating === 'A+' || trade.rating === 'A' ? "bg-[var(--ok)]/10 text-[var(--ok)]" :
                      trade.rating === 'B' ? "bg-blue-500/10 text-blue-500" :
                      "bg-[var(--ko)]/10 text-[var(--ko)]"
                    )}>
                      {trade.rating || '-'}
                    </div>
                  </td>
                  <td className="p-6 font-mono text-xs font-bold text-[var(--muted)] group-hover:text-white transition-colors">{trade.entryPrice.toFixed(5)}</td>
                  <td className="p-6 font-mono text-xs font-bold text-[var(--muted)] group-hover:text-white transition-colors">{trade.exitPrice?.toFixed(5) || '—'}</td>
                  <td className="p-6">
                    <div className="flex flex-col">
                      <span className={cn("font-black tracking-tight", trade.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                        {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toFixed(2)}€
                      </span>
                      <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">{trade.rMultiple}R</span>
                    </div>
                  </td>
                  <td className="p-6">
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-white">{format(new Date(trade.date), 'MMM d, yyyy')}</span>
                      <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">{trade.entryTime}</span>
                    </div>
                  </td>
                  <td className="p-6 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={(e) => { e.stopPropagation(); onDelete(trade.id); }} 
                        className="p-2.5 rounded-xl text-[var(--muted)] hover:text-[var(--ko)] hover:bg-[var(--ko)]/10 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 size={18} />
                      </button>
                      <ChevronRight size={18} className="text-[var(--muted)] group-hover:translate-x-1 transition-transform" />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredTrades.length === 0 && (
            <div className="flex flex-col items-center justify-center py-32 text-center px-6">
              <div className="w-20 h-20 rounded-3xl bg-[var(--line)]/20 flex items-center justify-center text-[var(--muted)] mb-6">
                <History size={40} />
              </div>
              <h3 className="text-xl font-black tracking-tight mb-2">No positions found</h3>
              <p className="text-[var(--muted)] text-sm max-w-xs">Try adjusting your filters or search terms to find what you're looking for.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const BacktestingLab = ({ sessions, onAddSession, onDeleteSession, t }: { sessions: BacktestSession[], onAddSession: (s: BacktestSession) => void, onDeleteSession: (id: string) => void, t: any }) => {
  const [isCreating, setIsCreating] = useState(false);
  const [activeSession, setActiveSession] = useState<BacktestSession | null>(null);

  const handleCreateSession = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newSession: BacktestSession = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.get('name') as string,
      strategy: formData.get('strategy') as string,
      date: new Date().toISOString(),
      trades: [],
      initialBalance: Number(formData.get('balance')),
      currentBalance: Number(formData.get('balance')),
    };
    onAddSession(newSession);
    setIsCreating(false);
  };

  const handleAddTradeToSession = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!activeSession) return;
    const formData = new FormData(e.currentTarget);
    const pnl = Number(formData.get('pnl'));
    const newTrade: BacktestTrade = {
      id: Math.random().toString(36).substr(2, 9),
      symbol: formData.get('symbol') as string,
      type: formData.get('type') as 'BUY' | 'SELL',
      status: formData.get('status') as any,
      entryPrice: Number(formData.get('entry')),
      exitPrice: Number(formData.get('exit')),
      pnl: pnl,
      date: new Date().toISOString(),
    };
    
    const updatedSession = {
      ...activeSession,
      trades: [newTrade, ...activeSession.trades],
      currentBalance: activeSession.currentBalance + pnl
    };
    setActiveSession(updatedSession);
    onAddSession(updatedSession); // This will update the existing session in parent state
  };

  if (activeSession) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <button onClick={() => setActiveSession(null)} className="btn p-2"><TrendingDown size={16} className="rotate-90" /></button>
            <div>
              <h2 className="text-2xl font-black">{activeSession.name}</h2>
              <p className="text-[var(--muted)] text-xs uppercase font-bold tracking-widest">{activeSession.strategy}</p>
            </div>
          </div>
          <div className="flex gap-4">
            <div className="text-right">
              <div className="text-[10px] font-bold text-[var(--muted)] uppercase">Current Balance</div>
              <div className="text-xl font-black text-[var(--brand)]">${activeSession.currentBalance.toFixed(2)}</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 flex flex-col gap-6">
            <div className="card flex flex-col gap-4">
              <h3 className="font-bold text-lg">Add Backtest Trade</h3>
              <form onSubmit={handleAddTradeToSession} className="flex flex-col gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-[var(--muted)] uppercase">Symbol</label>
                    <input name="symbol" placeholder="EURUSD" className="input" required />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-[var(--muted)] uppercase">Type</label>
                    <select name="type" className="input">
                      <option value="BUY">BUY</option>
                      <option value="SELL">SELL</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-[var(--muted)] uppercase">Status</label>
                    <select name="status" className="input">
                      <option value="WIN">WIN</option>
                      <option value="LOSS">LOSS</option>
                      <option value="BREAKEVEN">BREAKEVEN</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-[var(--muted)] uppercase">P&L ($)</label>
                    <input name="pnl" type="number" step="0.01" placeholder="50.00" className="input" required />
                  </div>
                </div>
                <button type="submit" className="btn btn-primary w-full">Add Trade</button>
              </form>
            </div>
            
            <div className="card flex flex-col gap-4">
              <h3 className="font-bold text-lg">Session Stats</h3>
              <div className="flex flex-col gap-2">
                <div className="flex justify-between">
                  <span className="text-[var(--muted)] text-sm">Total Trades</span>
                  <span className="font-bold">{activeSession.trades.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--muted)] text-sm">Win Rate</span>
                  <span className="font-bold">
                    {activeSession.trades.length > 0 
                      ? ((activeSession.trades.filter(t => t.status === 'WIN').length / activeSession.trades.length) * 100).toFixed(1)
                      : 0}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--muted)] text-sm">Net Profit</span>
                  <span className={cn("font-bold", activeSession.currentBalance - activeSession.initialBalance >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                    ${(activeSession.currentBalance - activeSession.initialBalance).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 card overflow-hidden p-0">
            <div className="p-4 border-b border-[var(--line)] flex justify-between items-center">
              <h3 className="font-bold">Session Trades</h3>
              <button className="btn py-1 px-3 text-xs"><Download size={14} /> Export CSV</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[var(--line)]/30">
                    <th className="p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">Symbol</th>
                    <th className="p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">Type</th>
                    <th className="p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">Status</th>
                    <th className="p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">P&L</th>
                    <th className="p-3 text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {activeSession.trades.map(trade => (
                    <tr key={trade.id} className="border-t border-[var(--line)] hover:bg-[var(--line)]/10 transition-colors">
                      <td className="p-3 font-bold text-sm">{trade.symbol}</td>
                      <td className="p-3"><Badge className="text-[8px]">{trade.type}</Badge></td>
                      <td className="p-3">
                        <Badge className={cn(
                          "text-[8px]",
                          trade.status === 'WIN' ? "bg-green-100 text-green-700" : 
                          trade.status === 'LOSS' ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700"
                        )}>
                          {trade.status}
                        </Badge>
                      </td>
                      <td className={cn("p-3 font-black text-sm", trade.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                        {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toFixed(2)}
                      </td>
                      <td className="p-3 text-[var(--muted)] text-[10px]">{format(new Date(trade.date), 'MMM d, HH:mm')}</td>
                    </tr>
                  ))}
                  {activeSession.trades.length === 0 && (
                    <tr>
                      <td colSpan={5} className="p-10 text-center text-[var(--muted)] italic text-sm">No trades in this session yet.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black tracking-tight">Strategy Lab</h2>
          <p className="text-[var(--muted)] text-sm">Test your edge against historical data.</p>
        </div>
        <button onClick={() => setIsCreating(true)} className="btn btn-primary gap-2">
          <Plus size={18} /> New Session
        </button>
      </div>

      {isCreating && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold">Create Backtest Session</h3>
            <button onClick={() => setIsCreating(false)} className="text-[var(--muted)] hover:text-[var(--text)]"><X size={18} /></button>
          </div>
          <form onSubmit={handleCreateSession} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase">Session Name</label>
              <input name="name" placeholder="E.g. EURUSD Q1 2024" className="input" required />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase">Strategy</label>
              <input name="strategy" placeholder="E.g. SMC / ICT" className="input" required />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] font-bold text-[var(--muted)] uppercase">Initial Balance ($)</label>
              <input name="balance" type="number" defaultValue="10000" className="input" required />
            </div>
            <div className="md:col-span-3 flex gap-3 mt-2">
              <button type="button" onClick={() => setIsCreating(false)} className="btn flex-1">Cancel</button>
              <button type="submit" className="btn btn-primary flex-1">Start Session</button>
            </div>
          </form>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sessions.map(session => (
          <div key={session.id} onClick={() => setActiveSession(session)} className="card hover:border-[var(--brand)] transition-all cursor-pointer group relative">
            <button 
              onClick={(e) => { e.stopPropagation(); onDeleteSession(session.id); }} 
              className="absolute top-4 right-4 p-2 text-[var(--muted)] hover:text-[var(--ko)] opacity-0 group-hover:opacity-100 transition-all"
            >
              <X size={16} />
            </button>
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]">
                  <FlaskConical size={20} />
                </div>
                <div>
                  <h3 className="font-bold">{session.name}</h3>
                  <p className="text-[var(--muted)] text-[10px] font-bold uppercase tracking-widest">{session.strategy}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 py-4 border-y border-[var(--line)]">
                <div>
                  <div className="text-[10px] font-bold text-[var(--muted)] uppercase">Trades</div>
                  <div className="text-lg font-black">{session.trades.length}</div>
                </div>
                <div>
                  <div className="text-[10px] font-bold text-[var(--muted)] uppercase">Net P&L</div>
                  <div className={cn("text-lg font-black", session.currentBalance - session.initialBalance >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                    ${(session.currentBalance - session.initialBalance).toFixed(2)}
                  </div>
                </div>
              </div>
              <div className="flex justify-between items-center text-[10px] font-bold text-[var(--muted)] uppercase">
                <span>Created {format(new Date(session.date), 'MMM d, yyyy')}</span>
                <span className="flex items-center gap-1 text-[var(--brand)]">Open Session <ChevronRight size={12} /></span>
              </div>
            </div>
          </div>
        ))}
        {sessions.length === 0 && !isCreating && (
          <div className="col-span-full card text-center py-20">
            <FlaskConical size={48} className="mx-auto text-[var(--muted)] mb-4" />
            <h3 className="text-xl font-bold">No backtesting sessions</h3>
            <p className="text-[var(--muted)]">Start a session to test your strategy on historical data.</p>
          </div>
        )}
      </div>
    </div>
  );
};

const Journal = ({ entries, onAdd, onDelete, t }: { entries: JournalEntry[], onAdd: (e: any) => void, onDelete: (id: string) => void, t: any }) => {
  const [isAdding, setIsAdding] = useState(false);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Daily Journal</h2>
        <button onClick={() => setIsAdding(true)} className="btn btn-primary gap-2">
          <Plus size={18} /> New Entry
        </button>
      </div>

      {isAdding && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card flex flex-col gap-4">
          <div className="flex justify-between items-center">
            <h3 className="font-bold tracking-tight">New Journal Entry</h3>
            <button onClick={() => setIsAdding(false)} className="text-[var(--muted)] hover:text-[var(--text)]"><X size={18} /></button>
          </div>
          <form onSubmit={(e) => { e.preventDefault(); onAdd(e); setIsAdding(false); }} className="flex flex-col gap-4">
            <div className="flex gap-4">
              {['HAPPY', 'NEUTRAL', 'SAD'].map((mood) => (
                <label key={mood} className="flex-1 flex flex-col items-center gap-2 p-4 rounded-xl border border-[var(--line)] cursor-pointer hover:bg-[var(--line)]/30 transition-all has-[:checked]:ring-2 has-[:checked]:ring-[var(--brand)]">
                  <input type="radio" name="mood" value={mood} className="hidden" defaultChecked={mood === 'HAPPY'} />
                  <span className="text-2xl">{mood === 'HAPPY' ? '😊' : mood === 'NEUTRAL' ? '😐' : '😔'}</span>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">{mood}</span>
                </label>
              ))}
            </div>
            <textarea name="content" placeholder="How was your trading day? What did you learn?" className="input min-h-[150px]" required />
            <div className="flex gap-3">
              <button type="button" onClick={() => setIsAdding(false)} className="btn flex-1">Cancel</button>
              <button type="submit" className="btn btn-primary flex-1">Save Entry</button>
            </div>
          </form>
        </motion.div>
      )}

      <div className="flex flex-col gap-4">
        {entries.map(entry => (
          <div key={entry.id} className="card flex flex-col gap-3 group">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-3">
                <span className="text-xl">{entry.mood === 'HAPPY' ? '😊' : entry.mood === 'NEUTRAL' ? '😐' : '😔'}</span>
                <div>
                  <div className="font-bold text-sm">{format(new Date(entry.date), 'EEEE, MMMM d')}</div>
                  <div className="text-[var(--muted)] text-[10px] uppercase font-bold tracking-widest">{format(new Date(entry.date), 'HH:mm')}</div>
                </div>
              </div>
              <button onClick={() => onDelete(entry.id)} className="p-2 text-[var(--muted)] hover:text-[var(--ko)] opacity-0 group-hover:opacity-100 transition-all">
                <X size={16} />
              </button>
            </div>
            <p className="text-sm text-[var(--text)]/80 leading-relaxed whitespace-pre-wrap">{entry.content}</p>
          </div>
        ))}
        {entries.length === 0 && !isAdding && (
          <div className="card text-center py-20">
            <BookOpen size={48} className="mx-auto text-[var(--muted)] mb-4" />
            <h3 className="text-xl font-bold">No entries yet</h3>
            <p className="text-[var(--muted)]">Start documenting your trading journey to improve your psychology.</p>
          </div>
        )}
      </div>
    </div>
  );
};

const Settings = ({ settings, onUpdate, setIsBrokerModalOpen, t, onExportBackup, onImportBackup }: { settings: AppSettings, onUpdate: (s: AppSettings) => void, setIsBrokerModalOpen: (b: boolean) => void, t: any, onExportBackup: () => void, onImportBackup: (e: React.ChangeEvent<HTMLInputElement>) => void }) => {
  return (
    <div className="flex flex-col gap-6 max-w-2xl">
      <div>
        <h2 className="text-2xl font-black tracking-tight">App Settings</h2>
        <p className="text-[var(--muted)] text-sm">Configure your trading environment.</p>
      </div>

      <div className="card flex flex-col gap-6">
        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">Account Currency</label>
          <select 
            value={settings.currency} 
            onChange={(e) => onUpdate({ ...settings, currency: e.target.value })}
            className="input"
          >
            <option value="USD">USD ($)</option>
            <option value="EUR">EUR (€)</option>
            <option value="GBP">GBP (£)</option>
            <option value="JPY">JPY (¥)</option>
          </select>
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">Initial Balance</label>
          <input 
            type="number" 
            value={settings.balance} 
            onChange={(e) => onUpdate({ ...settings, balance: Number(e.target.value) })}
            className="input" 
          />
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">Broker Connection</label>
          <div className="p-6 rounded-2xl bg-[var(--bg)] border border-[var(--line)] flex flex-col gap-4">
            {settings.broker ? (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-[var(--ok)]/10 border border-[var(--ok)]/20 flex items-center justify-center text-[var(--ok)]">
                    <Activity size={24} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-sm font-black text-white">{settings.broker.provider}</span>
                    <span className="text-[10px] font-bold text-[var(--ok)] uppercase tracking-widest">Connected</span>
                    {settings.broker.lastSync && (
                      <span className="text-[8px] font-bold text-[var(--muted)] uppercase tracking-widest mt-0.5">
                        Last sync: {format(new Date(settings.broker.lastSync), 'yyyy-MM-dd HH:mm')}
                      </span>
                    )}
                  </div>
                </div>
                <button 
                  onClick={() => onUpdate({ ...settings, broker: undefined })}
                  className="btn border-[var(--ko)] text-[var(--ko)] hover:bg-[var(--ko)] hover:text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest"
                >
                  Disconnect
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-center text-[var(--muted)]">
                      <Activity size={24} />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm font-black text-white">MetaTrader 4/5</span>
                      <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">Not Connected</span>
                    </div>
                  </div>
                  <button onClick={() => setIsBrokerModalOpen(true)} className="btn btn-primary px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest">Connect</button>
                </div>
                <div className="h-[1px] bg-[var(--line)]" />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-center text-[var(--muted)]">
                      <Activity size={24} />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-sm font-black text-white">Interactive Brokers</span>
                      <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-widest">Not Connected</span>
                    </div>
                  </div>
                  <button onClick={() => setIsBrokerModalOpen(true)} className="btn btn-primary px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest">Connect</button>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">{t.theme}</label>
          <div className="flex gap-4">
            <button 
              onClick={() => onUpdate({ ...settings, theme: 'light' })}
              className={cn("flex-1 btn gap-2", settings.theme === 'light' && "bg-[var(--brand)] text-white border-none")}
            >
              <Sun size={16} /> Light
            </button>
            <button 
              onClick={() => onUpdate({ ...settings, theme: 'dark' })}
              className={cn("flex-1 btn gap-2", settings.theme === 'dark' && "bg-[var(--brand)] text-white border-none")}
            >
              <Moon size={16} /> Dark
            </button>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">{t.language}</label>
          <div className="flex gap-4">
            <button 
              onClick={() => onUpdate({ ...settings, language: 'en' })}
              className={cn("flex-1 btn gap-2", settings.language === 'en' && "bg-[var(--brand)] text-white border-none")}
            >
              English
            </button>
            <button 
              onClick={() => onUpdate({ ...settings, language: 'fr' })}
              className={cn("flex-1 btn gap-2", settings.language === 'fr' && "bg-[var(--brand)] text-white border-none")}
            >
              Français
            </button>
          </div>
        </div>
      </div>

      <div className="card flex flex-col gap-6">
        <div className="flex flex-col gap-1">
          <h3 className="text-lg font-black tracking-tight">{t.backupData}</h3>
          <p className="text-xs text-[var(--muted)]">{t.backupDesc}</p>
        </div>
        <div className="flex gap-4">
          <button onClick={onExportBackup} className="flex-1 btn btn-primary gap-2">
            <Download size={16} /> {t.exportJson}
          </button>
          <label className="flex-1 btn gap-2 cursor-pointer">
            <RefreshCw size={16} /> {t.importJson}
            <input type="file" accept=".json" className="hidden" onChange={onImportBackup} />
          </label>
        </div>
      </div>

      <div className="card border-[var(--ko)]/20 bg-[var(--ko)]/5">
        <h3 className="text-[var(--ko)] font-bold mb-2">{t.dangerZone}</h3>
        <p className="text-xs text-[var(--muted)] mb-4">Deleting your data is permanent and cannot be undone.</p>
        <button 
          onClick={() => {
            if (confirm('Are you sure you want to delete all your data?')) {
              localStorage.clear();
              window.location.reload();
            }
          }}
          className="btn border-[var(--ko)] text-[var(--ko)] hover:bg-[var(--ko)] hover:text-white"
        >
          {t.resetData}
        </button>
      </div>
    </div>
  );
};

const TradeDrawer = ({ trade, onClose, theme, onUpdate, t }: { trade: Trade | null, onClose: () => void, theme: 'light' | 'dark', onUpdate: (trade: Trade) => void, t: any }) => {
  const [notes, setNotes] = useState(trade?.notes || '');
  const [screenshot, setScreenshot] = useState(trade?.screenshotUrl || '');
  const [rating, setRating] = useState<TradeRating | undefined>(trade?.rating);

  useEffect(() => {
    if (trade) {
      setNotes(trade.notes || '');
      setScreenshot(trade.screenshotUrl || '');
      setRating(trade.rating);
    }
  }, [trade]);

  const handleSave = () => {
    if (trade) {
      onUpdate({ ...trade, notes, screenshotUrl: screenshot, rating });
    }
  };

  return (
    <AnimatePresence>
      {trade && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-md z-[60]"
          />
          <motion.div 
            id="trade-drawer-content"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 h-full w-full max-w-2xl bg-[var(--bg)] shadow-2xl z-[70] flex flex-col border-l border-[var(--line)] overflow-hidden"
          >
            {/* Header */}
            <div className="p-8 border-b border-[var(--line)] flex justify-between items-center bg-[var(--surface)]/50 backdrop-blur-xl">
              <div className="flex items-center gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg",
                  trade.status === 'WIN' ? "bg-[var(--ok)]/20 text-[var(--ok)]" : 
                  trade.status === 'LOSS' ? "bg-[var(--ko)]/20 text-[var(--ko)]" : "bg-[var(--brand)]/20 text-[var(--brand)]"
                )}>
                  <Activity size={24} />
                </div>
                <div className="flex flex-col">
                  <h2 className="text-2xl font-black tracking-tighter text-white">{trade.symbol} Position</h2>
                  <p className="text-[var(--muted)] text-[10px] font-bold uppercase tracking-widest flex items-center gap-2">
                    {format(new Date(trade.date), 'MMMM d, yyyy')} <span className="w-1 h-1 rounded-full bg-[var(--line)]" /> {trade.entryTime}
                  </p>
                </div>
              </div>
              <button onClick={onClose} className="p-3 rounded-2xl bg-[var(--line)]/50 hover:bg-[var(--line)] text-[var(--muted)] hover:text-white transition-all">
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
              <div className="flex flex-col gap-10">
                {/* Key Metrics Row */}
                <div className="grid grid-cols-3 gap-6">
                  <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-1">
                    <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Result</span>
                    <span className={cn("text-2xl font-black tracking-tight", trade.pnl >= 0 ? "text-[var(--ok)]" : "text-[var(--ko)]")}>
                      {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toFixed(2)}€
                    </span>
                  </div>
                  <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-1">
                    <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">R-Multiple</span>
                    <span className="text-2xl font-black tracking-tight text-white">{trade.rMultiple}R</span>
                  </div>
                  <div className="card bg-[var(--surface)] border-[var(--line)] p-6 flex flex-col gap-1">
                    <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Risk</span>
                    <span className="text-2xl font-black tracking-tight text-white">{trade.riskPercent}%</span>
                  </div>
                </div>

                {/* Trade Lifecycle / Timeline */}
                <div className="flex flex-col gap-4">
                  <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2">
                    <History size={14} /> Trade Lifecycle
                  </h3>
                  <div className="relative p-8 rounded-3xl bg-[var(--surface)] border border-[var(--line)] flex flex-col gap-10 overflow-hidden group">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--brand)]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[var(--brand)]/10 transition-all" />
                    
                    {/* Visual Timeline Bar */}
                    <div className="relative flex items-center justify-between">
                      <div className="absolute left-0 right-0 h-1 bg-[var(--line)] z-0" />
                      <div className={cn(
                        "absolute left-0 h-1 z-10 transition-all duration-1000",
                        trade.status === 'WIN' ? "bg-[var(--ok)]" : trade.status === 'LOSS' ? "bg-[var(--ko)]" : "bg-[var(--brand)]"
                      )} style={{ width: trade.exitPrice ? '100%' : '50%' }} />
                      
                      <div className="relative z-20 flex flex-col items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-[var(--brand)] border-4 border-[var(--bg)] shadow-[0_0_10px_var(--brand)]" />
                        <span className="text-[8px] font-black uppercase tracking-widest text-white">Entry</span>
                      </div>
                      
                      <div className="relative z-20 flex flex-col items-center gap-2">
                        <div className={cn(
                          "w-4 h-4 rounded-full border-4 border-[var(--bg)]",
                          trade.exitPrice ? (trade.status === 'WIN' ? "bg-[var(--ok)] shadow-[0_0_10px_var(--ok)]" : "bg-[var(--ko)] shadow-[0_0_10px_var(--ko)]") : "bg-[var(--line)]"
                        )} />
                        <span className="text-[8px] font-black uppercase tracking-widest text-white">Exit</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-8">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Duration</span>
                        <span className="text-sm font-black text-white">4h 22m</span>
                      </div>
                      <div className="flex flex-col gap-1 text-right">
                        <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Holding Time</span>
                        <span className="text-sm font-black text-white">Intraday</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Execution Details */}
                <div className="flex flex-col gap-4">
                  <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2">
                    <Target size={14} /> Execution Details
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex justify-between items-center p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
                      <span className="text-sm font-bold text-[var(--muted)]">Entry Price</span>
                      <span className="font-mono font-black text-white">{trade.entryPrice.toFixed(5)}</span>
                    </div>
                    <div className="flex justify-between items-center p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
                      <span className="text-sm font-bold text-[var(--muted)]">Exit Price</span>
                      <span className="font-mono font-black text-white">{trade.exitPrice?.toFixed(5) || '—'}</span>
                    </div>
                    <div className="flex justify-between items-center p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
                      <span className="text-sm font-bold text-[var(--muted)]">Stop Loss</span>
                      <span className="font-mono font-black text-[var(--ko)]">{trade.stopLoss?.toFixed(5) || '—'}</span>
                    </div>
                    <div className="flex justify-between items-center p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
                      <span className="text-sm font-bold text-[var(--muted)]">Take Profit</span>
                      <span className="font-mono font-black text-[var(--ok)]">{trade.takeProfit?.toFixed(5) || '—'}</span>
                    </div>
                  </div>
                </div>

                {/* Psychology Section */}
                <div className="flex flex-col gap-4">
                  <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2">
                    <Brain size={14} /> Psychology & Context
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-2 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
                      <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Emotion Before</span>
                      <span className="text-sm font-black text-white">{trade.emotionBefore || 'Not recorded'}</span>
                    </div>
                    <div className="flex flex-col gap-2 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
                      <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Emotion After</span>
                      <span className="text-sm font-black text-white">{trade.emotionAfter || 'Not recorded'}</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-2 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
                      <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Setup / Strategy</span>
                      <span className="text-sm font-black text-white">{trade.setup || 'No setup specified'}</span>
                    </div>
                    <div className="flex flex-col gap-2 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)]">
                      <span className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Trade Rating</span>
                      <select 
                        value={rating || ''} 
                        onChange={(e) => setRating(e.target.value as any)}
                        className="bg-transparent text-sm font-black text-white outline-none"
                      >
                        <option value="" className="bg-[var(--surface)]">No Rating</option>
                        <option value="A+" className="bg-[var(--surface)]">A+</option>
                        <option value="A" className="bg-[var(--surface)]">A</option>
                        <option value="B" className="bg-[var(--surface)]">B</option>
                        <option value="C" className="bg-[var(--surface)]">C</option>
                        <option value="D" className="bg-[var(--surface)]">D</option>
                        <option value="F" className="bg-[var(--surface)]">F</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Chart / Screenshot */}
                <div className="flex flex-col gap-4">
                  <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2">
                    <ImageIcon size={14} /> Visual Evidence
                  </h3>
                  <div className="flex flex-col gap-4">
                    <div className="h-[300px] w-full rounded-3xl overflow-hidden border border-[var(--line)] shadow-2xl">
                      <iframe
                        src={`https://s.tradingview.com/widgetembed/?frameElementId=tradingview_76d87&symbol=${trade.symbol.includes('/') ? trade.symbol.replace('/', '') : trade.symbol}&interval=D&hidesidetoolbar=1&hidetoptoolbar=1&symboledit=1&saveimage=1&toolbarbg=f1f3f6&studies=%5B%5D&theme=${theme}&style=1&timezone=Etc%2FUTC&studies_overrides=%7B%7D&overrides=%7B%7D&enabled_features=%5B%5D&disabled_features=%5B%5D&locale=en&utm_source=edgeflow&utm_medium=widget&utm_campaign=chart&utm_term=${trade.symbol}`}
                        width="100%"
                        height="100%"
                        frameBorder="0"
                        scrolling="no"
                        allowFullScreen
                      />
                    </div>
                    <div className="flex flex-col gap-3">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">Screenshot URL</label>
                      <input 
                        type="text" 
                        value={screenshot} 
                        onChange={(e) => setScreenshot(e.target.value)}
                        placeholder="https://tradingview.com/x/..." 
                        className="input"
                      />
                      {screenshot && (
                        <motion.img 
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          src={screenshot} 
                          alt="Trade Screenshot" 
                          className="rounded-3xl border border-[var(--line)] w-full shadow-2xl" 
                          referrerPolicy="no-referrer" 
                        />
                      )}
                    </div>
                  </div>
                </div>

                {/* Notes */}
                <div className="flex flex-col gap-4">
                  <h3 className="text-xs font-black uppercase tracking-[0.2em] text-[var(--muted)] flex items-center gap-2">
                    <BookOpen size={14} /> Trade Journal
                  </h3>
                  <textarea 
                    value={notes} 
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Describe your setup, emotions, and mistakes..." 
                    className="input min-h-[200px] py-6 leading-relaxed text-base"
                  />
                </div>
              </div>
            </div>

            {/* Footer Actions */}
            <div className="p-8 border-t border-[var(--line)] bg-[var(--surface)]/50 backdrop-blur-xl flex gap-4">
              <button 
                onClick={async () => {
                  const element = document.getElementById('trade-drawer-content');
                  if (!element) return;
                  const canvas = await html2canvas(element, { scale: 2, backgroundColor: theme === 'dark' ? '#05070a' : '#ffffff' });
                  const link = document.createElement('a');
                  link.download = `edgeflow-trade-${trade.symbol}-${trade.id}.png`;
                  link.href = canvas.toDataURL();
                  link.click();
                }}
                className="btn flex-1 gap-3 py-4 rounded-2xl font-black uppercase tracking-widest text-xs"
              >
                <Download size={16} /> Export Position
              </button>
              <button onClick={handleSave} className="btn btn-primary flex-1 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl shadow-[var(--brand-glow)]">
                Save Changes
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

// --- Main App ---

const BrokerModal = ({ isOpen, onClose, onConnect, isSyncing }: { isOpen: boolean, onClose: () => void, onConnect: (p: any) => void, isSyncing: boolean }) => {
  const [step, setStep] = useState<'SELECT' | 'FORM'>('SELECT');
  const [provider, setProvider] = useState<string>('');

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        />
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-md bg-[var(--surface)] border border-[var(--line)] rounded-3xl shadow-2xl overflow-hidden"
        >
          <div className="p-8 border-b border-[var(--line)] flex justify-between items-center">
            <h3 className="text-xl font-black tracking-tight">Connect Broker</h3>
            <button onClick={onClose} className="p-2 hover:bg-[var(--line)] rounded-xl transition-all"><X size={20} /></button>
          </div>

          <div className="p-8">
            {isSyncing ? (
              <div className="flex flex-col items-center justify-center py-12 gap-6">
                <div className="relative">
                  <RefreshCw size={48} className="text-[var(--brand)] animate-spin" />
                  <div className="absolute inset-0 bg-[var(--brand)]/20 blur-xl rounded-full animate-pulse" />
                </div>
                <div className="flex flex-col items-center gap-2">
                  <h4 className="text-lg font-black text-white">Connecting to {provider}...</h4>
                  <p className="text-xs text-[var(--muted)] font-bold uppercase tracking-widest">Synchronizing your trade data</p>
                </div>
              </div>
            ) : step === 'SELECT' ? (
              <div className="flex flex-col gap-4">
                <p className="text-sm text-[var(--muted)] mb-2">Select your trading platform to sync your trades automatically.</p>
                {['METATRADER', 'TRADOVATE', 'OANDA', 'IBKR'].map((p) => (
                  <button 
                    key={p}
                    onClick={() => { setProvider(p); setStep('FORM'); }}
                    className="flex items-center justify-between p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)] hover:border-[var(--brand)] transition-all group"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-[var(--surface)] flex items-center justify-center text-[var(--brand)]">
                        <Activity size={20} />
                      </div>
                      <span className="font-black text-sm">{p}</span>
                    </div>
                    <ChevronRight size={18} className="text-[var(--muted)] group-hover:translate-x-1 transition-transform" />
                  </button>
                ))}
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); onConnect(provider); }} className="flex flex-col gap-6">
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">Account ID</label>
                  <input type="text" placeholder="Enter your account number" className="input" required />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">API Key / Password</label>
                  <input type="password" placeholder="••••••••••••" className="input" required />
                </div>
                <div className="flex gap-3 mt-4">
                  <button type="button" onClick={() => setStep('SELECT')} className="btn flex-1">Back</button>
                  <button type="submit" className="btn btn-primary flex-1">Connect {provider}</button>
                </div>
                
                <div className="mt-6 p-4 rounded-2xl bg-[var(--brand)]/5 border border-[var(--brand)]/10">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-[var(--brand)] mb-2 flex items-center gap-2">
                    <Zap size={10} /> How to verify connection?
                  </h4>
                  <ul className="flex flex-col gap-2">
                    <li className="text-[9px] text-[var(--muted)] font-medium flex gap-2">
                      <span className="text-[var(--brand)]">1.</span>
                      Check the "Broker Status" card on your dashboard. It should turn green.
                    </li>
                    <li className="text-[9px] text-[var(--muted)] font-medium flex gap-2">
                      <span className="text-[var(--brand)]">2.</span>
                      Your account balance and ID will appear instantly after sync.
                    </li>
                    <li className="text-[9px] text-[var(--muted)] font-medium flex gap-2">
                      <span className="text-[var(--brand)]">3.</span>
                      Try the "Sync Now" button to see real-time data flow.
                    </li>
                  </ul>
                </div>
                
                <p className="text-[10px] text-center text-[var(--muted)] mt-4">
                  Your credentials are encrypted and never stored on our servers.
                </p>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

const AdminView = ({ t }: { t: any }) => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      // In a real app, you'd need a service role or edge function to list all users
      // For this demo, we'll fetch from a 'profiles' table
      const { data, error } = await supabase
        .from('profiles')
        .select('*');
      
      if (data) setUsers(data);
      setLoading(false);
    };
    fetchUsers();
  }, []);

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-1">
        <h2 className="text-3xl font-black text-gradient">{t.adminPanel}</h2>
        <p className="text-[var(--muted)] text-sm font-bold uppercase tracking-widest">{t.userManagement}</p>
      </div>

      <div className="card bg-[var(--surface)] border-[var(--line)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[var(--line)] bg-[var(--bg)]/50">
                <th className="p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">{t.users}</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">{t.role}</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">{t.status}</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)]">{t.lastLogin}</th>
                <th className="p-6 text-[10px] font-black uppercase tracking-widest text-[var(--muted)] text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} className="p-10 text-center text-[var(--muted)]">Loading users...</td></tr>
              ) : users.length > 0 ? users.map((user) => (
                <tr key={user.id} className="border-b border-[var(--line)] hover:bg-[var(--surface-hover)] transition-colors group">
                  <td className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--brand)] to-[var(--brand2)] flex items-center justify-center text-white font-black">
                        {(user.username || user.email || 'U').charAt(0)}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-sm font-black text-white">{user.username || 'Anonymous'}</span>
                        <span className="text-xs text-[var(--muted)]">{user.email}</span>
                      </div>
                    </div>
                  </td>
                  <td className="p-6">
                    <Badge className={cn(
                      user.role === 'admin' ? "bg-[var(--brand)]/20 text-[var(--brand)]" : "bg-[var(--muted)]/20 text-[var(--muted)]"
                    )}>
                      {user.role}
                    </Badge>
                  </td>
                  <td className="p-6">
                    <div className="flex items-center gap-2">
                      <div className={cn("w-1.5 h-1.5 rounded-full", user.status === 'active' ? "bg-[var(--ok)]" : "bg-[var(--ko)]")} />
                      <span className="text-xs font-bold text-white">{user.status === 'active' ? t.active : t.suspended}</span>
                    </div>
                  </td>
                  <td className="p-6 text-xs font-bold text-[var(--muted)]">{user.last_login ? format(new Date(user.last_login), 'yyyy-MM-dd HH:mm') : 'N/A'}</td>
                  <td className="p-6 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={async () => {
                          const newRole = user.role === 'admin' ? 'trader' : 'admin';
                          const { error } = await supabase
                            .from('profiles')
                            .update({ role: newRole })
                            .eq('id', user.id);
                          if (!error) {
                            setUsers(users.map(u => u.id === user.id ? { ...u, role: newRole } : u));
                          }
                        }}
                        className="text-[10px] font-black uppercase tracking-widest text-[var(--brand)] hover:underline"
                      >
                        {user.role === 'admin' ? 'Demote' : 'Promote'}
                      </button>
                      <button className="p-2 rounded-lg hover:bg-[var(--surface)] text-[var(--muted)] hover:text-white transition-all">
                        <MoreVertical size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr><td colSpan={5} className="p-10 text-center text-[var(--muted)]">No users found in database.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="card bg-[var(--surface)] border-[var(--line)] p-8 flex flex-col gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]">
              <SettingsIcon size={20} />
            </div>
            <h3 className="text-lg font-black tracking-tight">{t.systemSettings}</h3>
          </div>
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)]">
              <span className="text-sm font-bold text-white">Maintenance Mode</span>
              <div className="w-12 h-6 rounded-full bg-[var(--line)] relative cursor-pointer">
                <div className="absolute left-1 top-1 w-4 h-4 rounded-full bg-[var(--muted)]" />
              </div>
            </div>
            <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)]">
              <span className="text-sm font-bold text-white">New User Registration</span>
              <div className="w-12 h-6 rounded-full bg-[var(--brand)] relative cursor-pointer">
                <div className="absolute right-1 top-1 w-4 h-4 rounded-full bg-white" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const App = () => {
  const [isAuthed, setIsAuthed] = useState(false);
  const [user, setUser] = useState<SupabaseUser | null>(null);
  const [userRole, setUserRole] = useState<'admin' | 'trader'>('trader');
  const [view, setView] = useState<'dashboard' | 'calendar' | 'trades' | 'journal' | 'lab' | 'settings' | 'admin'>('dashboard');
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');
  const [settings, setSettings] = useState<AppSettings>({ theme: 'dark', language: 'fr', currency: 'USD', balance: 100000 });
  const [trades, setTrades] = useState<Trade[]>([]);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([]);
  const [backtestSessions, setBacktestSessions] = useState<BacktestSession[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBrokerModalOpen, setIsBrokerModalOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [selectedTrade, setSelectedTrade] = useState<Trade | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Auth Listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setIsAuthed(!!session);
      setAuthLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setIsAuthed(!!session);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Fetch User Profile (Role)
  useEffect(() => {
    if (user) {
      const fetchProfile = async () => {
        const { data, error } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single();
        
        if (data) {
          setUserRole(data.role as 'admin' | 'trader');
        } else if (error && error.code === 'PGRST116') {
          // Profile doesn't exist, create it
          await supabase.from('profiles').insert([
            { id: user.id, email: user.email, role: 'trader', status: 'active', username: user.email?.split('@')[0] }
          ]);
        }
      };
      fetchProfile();
    }
  }, [user]);

  // Load data from Supabase or LocalStorage
  useEffect(() => {
    const loadData = async () => {
      if (user) {
        // Load from Supabase
        const [tradesRes, journalRes, backtestRes, settingsRes] = await Promise.all([
          supabase.from('trades').select('*').eq('user_id', user.id).order('date', { ascending: false }),
          supabase.from('journal_entries').select('*').eq('user_id', user.id).order('date', { ascending: false }),
          supabase.from('backtest_sessions').select('*').eq('user_id', user.id).order('date', { ascending: false }),
          supabase.from('settings').select('*').eq('user_id', user.id).single()
        ]);

        if (tradesRes.data) setTrades(tradesRes.data);
        if (journalRes.data) setJournalEntries(journalRes.data);
        if (backtestRes.data) setBacktestSessions(backtestRes.data);
        if (settingsRes.data) {
          setSettings(settingsRes.data);
          setTheme(settingsRes.data.theme);
        }
      } else {
        // Fallback to LocalStorage
        const savedTrades = localStorage.getItem('ef_trades');
        if (savedTrades) setTrades(JSON.parse(savedTrades));
        
        const savedJournal = localStorage.getItem('ef_journal');
        if (savedJournal) setJournalEntries(JSON.parse(savedJournal));

        const savedBacktest = localStorage.getItem('ef_backtest');
        if (savedBacktest) setBacktestSessions(JSON.parse(savedBacktest));

        const savedSettings = localStorage.getItem('ef_settings');
        if (savedSettings) {
          const parsed = JSON.parse(savedSettings);
          setSettings(parsed);
          setTheme(parsed.theme);
        }
      }
    };
    loadData();
  }, [user]);

  // Save data effect (only for local storage if not authed)
  useEffect(() => {
    if (!user) {
      localStorage.setItem('ef_trades', JSON.stringify(trades));
      localStorage.setItem('ef_journal', JSON.stringify(journalEntries));
      localStorage.setItem('ef_backtest', JSON.stringify(backtestSessions));
      localStorage.setItem('ef_settings', JSON.stringify(settings));
      localStorage.setItem('ef_theme', theme);
    }
    document.documentElement.setAttribute('data-theme', theme);
  }, [trades, journalEntries, backtestSessions, settings, theme, user]);

  // Sync theme with settings
  useEffect(() => {
    setTheme(settings.theme);
  }, [settings.theme]);

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) alert(error.message);
  };

  const handleSignup = async (e: React.FormEvent<HTMLFormElement> | React.MouseEvent) => {
    if (e) e.preventDefault();
    const form = document.querySelector('form');
    if (!form) return;
    const formData = new FormData(form);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    
    if (!email || !password) {
      alert('Please enter email and password');
      return;
    }

    const { error } = await supabase.auth.signUp({ email, password });
    if (error) alert(error.message);
    else alert('Check your email for the confirmation link!');
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setIsAuthed(false);
    setUser(null);
  };

  const handleConnectBroker = (provider: any) => {
    setIsSyncing(true);
    // Simulate connection delay
    setTimeout(async () => {
      const newBroker: any = {
        id: Math.random().toString(36).substr(2, 9),
        provider: provider as any,
        status: 'CONNECTED',
        accountName: `Demo ${provider} Account`,
        lastSync: new Date().toISOString()
      };
      
      const newSettings = { ...settings, broker: newBroker };
      setSettings(newSettings);
      
      if (user) {
        await supabase.from('settings').upsert({ user_id: user.id, ...newSettings });
      }

      setIsSyncing(false);
      setIsBrokerModalOpen(false);
    }, 2000);
  };

  const handleExportPDF = async () => {
    const element = document.getElementById('main-content-area');
    if (!element) return;
    
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      backgroundColor: theme === 'dark' ? '#0f1224' : '#ffffff'
    });
    
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`edgeflow-report-${format(new Date(), 'yyyy-MM-dd')}.pdf`);
  };

  const handleExportBackup = () => {
    const backupData = {
      trades,
      journalEntries,
      backtestSessions,
      settings,
      exportDate: new Date().toISOString(),
      version: '2.5'
    };
    
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `edgeflow-backup-${format(new Date(), 'yyyy-MM-dd')}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.trades) setTrades(data.trades);
        if (data.journalEntries) setJournalEntries(data.journalEntries);
        if (data.backtestSessions) setBacktestSessions(data.backtestSessions);
        if (data.settings) setSettings(data.settings);
        
        if (user) {
          // Sync to Supabase
          await Promise.all([
            supabase.from('trades').upsert(data.trades.map((t: any) => ({ ...t, user_id: user.id }))),
            supabase.from('journal_entries').upsert(data.journalEntries.map((j: any) => ({ ...j, user_id: user.id }))),
            supabase.from('backtest_sessions').upsert(data.backtestSessions.map((b: any) => ({ ...b, user_id: user.id }))),
            supabase.from('settings').upsert({ user_id: user.id, ...data.settings })
          ]);
        }
        
        alert(translations[settings.language].importSuccess);
      } catch (err) {
        console.error('Import error:', err);
        alert(translations[settings.language].importError);
      }
    };
    reader.readAsText(file);
  };

  const handleExportCSV = () => {
    const headers = ['Symbol', 'Type', 'Status', 'Entry', 'Exit', 'Lots', 'P&L', 'Date'];
    const rows = trades.map(t => [
      t.symbol,
      t.type,
      t.status,
      t.entryPrice,
      t.exitPrice || '',
      t.pnl,
      t.date
    ]);
    
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `edgeflow-trades-${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n');
      const newTrades: Trade[] = [];
      
      // Skip header
      for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',');
        if (cols.length < 7) continue;
        
        newTrades.push({
          id: Math.random().toString(36).substr(2, 9),
          symbol: cols[0],
          type: cols[1] as any,
          status: cols[2] as any,
          entryPrice: Number(cols[3]),
          exitPrice: Number(cols[4]) || undefined,
          pnl: Number(cols[5]),
          date: cols[6] || new Date().toISOString(),
          tags: []
        });
      }
      
      const updatedTrades = [...newTrades, ...trades];
      setTrades(updatedTrades);
      
      if (user) {
        await supabase.from('trades').upsert(newTrades.map(t => ({ ...t, user_id: user.id })));
      }
    };
    reader.readAsText(file);
  };

  const handleAddBacktestSession = async (session: BacktestSession) => {
    const exists = backtestSessions.find(s => s.id === session.id);
    let updated;
    if (exists) {
      updated = backtestSessions.map(s => s.id === session.id ? session : s);
    } else {
      updated = [session, ...backtestSessions];
    }
    setBacktestSessions(updated);
    
    if (user) {
      await supabase.from('backtest_sessions').upsert({ ...session, user_id: user.id });
    }
  };

  const deleteBacktestSession = async (id: string) => {
    setBacktestSessions(backtestSessions.filter(s => s.id !== id));
    if (user) {
      await supabase.from('backtest_sessions').delete().eq('id', id);
    }
  };

  const handleAddJournalEntry = async (e: any) => {
    const formData = new FormData(e.currentTarget);
    const newEntry: JournalEntry = {
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString(),
      content: formData.get('content') as string,
      mood: formData.get('mood') as 'HAPPY' | 'NEUTRAL' | 'SAD',
    };
    setJournalEntries([newEntry, ...journalEntries]);
    
    if (user) {
      await supabase.from('journal_entries').insert([{ ...newEntry, user_id: user.id }]);
    }
  };

  const deleteJournalEntry = async (id: string) => {
    setJournalEntries(journalEntries.filter(e => e.id !== id));
    if (user) {
      await supabase.from('journal_entries').delete().eq('id', id);
    }
  };

  const handleAddTrade = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newTrade: Trade = {
      id: Math.random().toString(36).substr(2, 9),
      symbol: formData.get('symbol') as string,
      type: formData.get('type') as 'BUY' | 'SELL',
      status: formData.get('status') as any,
      entryPrice: Number(formData.get('entryPrice')),
      exitPrice: formData.get('exitPrice') ? Number(formData.get('exitPrice')) : undefined,
      stopLoss: Number(formData.get('stopLoss')),
      takeProfit: Number(formData.get('takeProfit')),
      pnl: Number(formData.get('pnl')),
      date: formData.get('date') as string || new Date().toISOString(),
      entryTime: formData.get('entryTime') as string,
      exitTime: formData.get('exitTime') as string,
      propFirm: formData.get('propFirm') as string,
      source: formData.get('source') as string,
      orderType: formData.get('orderType') as string,
      riskPercent: Number(formData.get('riskPercent')),
      rMultiple: Number(formData.get('rMultiple')),
      setup: formData.get('setup') as string,
      rating: formData.get('rating') as any,
      emotionBefore: formData.get('emotionBefore') as string,
      emotionAfter: formData.get('emotionAfter') as string,
      notes: formData.get('notes') as string,
      screenshotUrl: formData.get('screenshotUrl') as string,
      tags: [],
    };
    setTrades([newTrade, ...trades]);
    setIsModalOpen(false);
    
    if (user) {
      await supabase.from('trades').insert([{ ...newTrade, user_id: user.id }]);
    }
  };

  const handleUpdateTrade = async (updatedTrade: Trade) => {
    setTrades(trades.map(t => t.id === updatedTrade.id ? updatedTrade : t));
    setSelectedTrade(null);
    
    if (user) {
      await supabase.from('trades').update(updatedTrade).eq('id', updatedTrade.id);
    }
  };

  const deleteTrade = async (id: string) => {
    setTrades(trades.filter(t => t.id !== id));
    if (user) {
      await supabase.from('trades').delete().eq('id', id);
    }
  };

  const t = translations[settings.language];

  if (!isAuthed) {
    return (
      <section className="hero-gradient min-h-screen flex items-center justify-center p-6 overflow-hidden relative">
        <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center z-10">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col gap-6"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-r from-[var(--brand)] to-[var(--brand2)] flex items-center justify-center shadow-lg">
                <Activity className="text-white" size={24} />
              </div>
              <div>
                <h2 className="text-white font-black text-xl tracking-tight">EdgeFlow</h2>
                <Badge className="bg-[var(--brand)]/20 text-[var(--brand2)] border border-[var(--brand)]/30">Premium</Badge>
              </div>
            </div>
            <h1 className="text-5xl lg:text-7xl font-black text-white leading-[1.05] tracking-tighter">
              {t.heroTitle}
            </h1>
            <p className="text-[var(--muted)] text-lg lg:text-xl max-w-lg">
              {t.heroSubtitle}
            </p>
            <ul className="flex flex-col gap-3 text-white/80 font-medium">
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-[var(--brand)]" /> {t.heroFeature1}</li>
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-[var(--brand)]" /> {t.heroFeature2}</li>
              <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-[var(--brand)]" /> {t.heroFeature3}</li>
            </ul>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="card bg-[var(--surface)]/95 backdrop-blur-xl border-white/10 max-w-md w-full ml-auto"
          >
            <h3 className="text-2xl font-black mb-1 text-[var(--text)]">{t.loginTitle}</h3>
            <p className="text-[var(--muted)] text-sm mb-6">{t.loginSubtitle}</p>
            
            <form className="flex flex-col gap-4" onSubmit={handleLogin}>
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">{t.emailLabel}</label>
                <input name="email" type="email" placeholder="toi@exemple.be" className="input" required />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[var(--muted)]">{t.passwordLabel}</label>
                <input name="password" type="password" placeholder="••••••••" className="input" required />
              </div>
              <div className="flex justify-between items-center text-xs">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="accent-[var(--brand)]" />
                  <span className="text-[var(--muted)]">Se souvenir de moi</span>
                </label>
                <a href="#" className="text-[var(--brand2)] font-bold hover:underline">Oublié ?</a>
              </div>
              <button type="submit" className="btn btn-primary w-full mt-2">Se connecter</button>
              <button type="button" onClick={handleSignup} className="btn w-full border-[var(--line)] flex items-center justify-center gap-2">
                Créer un compte
              </button>
              <button type="button" className="btn w-full border-[var(--line)] flex items-center justify-center gap-2">
                <img src="https://www.google.com/favicon.ico" className="w-4 h-4" alt="Google" />
                Continuer avec Google
              </button>
              <div className="text-center text-xs text-[var(--muted)] mt-4">
                Pas de compte ? <button type="button" onClick={() => {}} className="text-[var(--brand2)] font-bold">Créer un compte</button>
              </div>
              <button type="button" onClick={() => setIsAuthed(true)} className="text-[var(--brand2)] text-xs font-bold hover:underline mt-2">
                Continuer sans compte (test)
              </button>
            </form>
          </motion.div>
        </div>
        <div className="absolute bottom-6 w-full text-center text-white/30 text-[10px] font-bold tracking-widest uppercase">
          © EdgeFlow — Tous droits réservés 2025
        </div>
      </section>
    );
  }

  return (
    <div className="flex min-h-screen bg-[var(--bg)]">
      {/* Sidebar */}
      <aside className="w-72 bg-[var(--surface)] border-r border-[var(--line)] p-8 flex flex-col gap-10 sticky top-0 h-screen overflow-y-auto">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[var(--brand)] to-[var(--brand2)] flex items-center justify-center shadow-xl shadow-[var(--brand-glow)]">
            <Activity className="text-white" size={24} />
          </div>
          <div>
            <h2 className="font-black text-xl tracking-tighter text-gradient">EdgeFlow</h2>
            <div className="text-[var(--muted)] text-[10px] font-black uppercase tracking-[0.2em]">Mission Control</div>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <button onClick={() => setIsModalOpen(true)} className="btn btn-primary w-full py-4 rounded-2xl flex items-center justify-center gap-3 group">
            <Plus size={20} className="group-hover:rotate-90 transition-transform duration-300" /> 
            <span className="uppercase tracking-widest text-xs">{t.newTrade}</span>
          </button>
          <button className="btn w-full py-4 rounded-2xl border-[var(--line)] hover:border-[var(--brand)]/30 transition-all group">
            <span className="uppercase tracking-widest text-[10px] font-black text-[var(--muted)] group-hover:text-white">{t.importCSV}</span>
          </button>
        </div>

        <div className="flex flex-col gap-8">
          <div className="flex flex-col gap-4">
            <label className="text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">{t.parameters}</label>
            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-bold text-[var(--muted)] uppercase tracking-wider">Prop Firm</span>
                <select className="bg-[var(--bg)] border border-[var(--line)] rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[var(--brand)] transition-all">
                  <option>FTMO 100K</option>
                  <option>MFF 50K</option>
                </select>
              </div>
            </div>
          </div>

          <nav className="flex flex-col gap-2">
            <label className="text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)] mb-2">Navigation</label>
            {[
              { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
              { id: 'calendar', label: t.calendar, icon: CalendarIcon },
              { id: 'trades', label: t.trades, icon: History },
              { id: 'lab', label: t.lab, icon: FlaskConical },
              { id: 'settings', label: t.settings, icon: SettingsIcon },
              ...(userRole === 'admin' ? [{ id: 'admin', label: t.admin, icon: Shield }] : []),
            ].map((item) => (
              <button 
                key={item.id}
                onClick={() => setView(item.id as any)} 
                className={cn(
                  "flex items-center gap-4 px-4 py-3.5 rounded-2xl text-sm font-bold transition-all duration-200 group",
                  view === item.id 
                    ? "bg-[var(--brand)]/10 text-[var(--brand)] shadow-inner" 
                    : "text-[var(--muted)] hover:bg-[var(--surface-hover)] hover:text-white"
                )}
              >
                <item.icon size={18} className={cn("transition-transform duration-300", view === item.id ? "scale-110" : "group-hover:scale-110")} />
                <span className="tracking-wide">{item.label}</span>
                {view === item.id && <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 rounded-full bg-[var(--brand)] shadow-[0_0_8px_var(--brand)]" />}
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-auto pt-8 border-t border-[var(--line)]">
          <button onClick={handleLogout} className="flex items-center justify-between w-full px-4 py-4 rounded-2xl text-sm font-black text-[var(--ko)] hover:bg-[var(--ko)]/10 transition-all group">
            <span className="uppercase tracking-widest text-[10px]">Logout</span>
            <LogOut size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-[var(--bg)]">
        <header className="h-20 bg-[var(--surface)]/80 backdrop-blur-xl border-b border-[var(--line)] flex items-center justify-between px-10 sticky top-0 z-20">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-black text-gradient capitalize tracking-tight">{view}</h1>
            <div className="h-4 w-[1px] bg-[var(--line)] mx-2" />
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-[var(--muted)]">EdgeFlow v2.5</p>
          </div>
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3 px-4 py-2 rounded-full bg-[var(--ok)]/10 border border-[var(--ok)]/20">
              <span className="w-2 h-2 rounded-full bg-[var(--ok)] animate-pulse shadow-[0_0_8px_var(--ok)]" /> 
              <span className="text-[10px] font-black uppercase tracking-widest text-[var(--ok)]">System Ready</span>
            </div>
            <div className="flex items-center gap-4">
              <button className="p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all"><Search size={20} /></button>
              <button className="p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all"><Download size={20} /></button>
              <button className="p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all"><Activity size={20} /></button>
              <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')} className="p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all">
                {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
              </button>
            </div>
            <div className="h-8 w-[1px] bg-[var(--line)]" />
            <button className="flex items-center gap-4 group">
              <div className="text-right hidden sm:block">
                <div className="text-sm font-black text-white group-hover:text-[var(--brand)] transition-colors">Julien Y.</div>
                <div className="text-[10px] text-[var(--muted)] font-black uppercase tracking-widest">Elite Trader</div>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[var(--brand)] to-[var(--brand2)] p-[1px]">
                <div className="w-full h-full rounded-2xl bg-[var(--surface)] flex items-center justify-center overflow-hidden">
                  <User size={22} className="text-[var(--brand)]" />
                </div>
              </div>
            </button>
          </div>
        </header>

        <div id="main-content-area" className="p-10 flex flex-col gap-10 max-w-[1600px] mx-auto w-full">
          <div className="flex justify-between items-end">
            <div className="flex flex-col gap-1">
              <h1 className="text-4xl font-black tracking-tighter capitalize text-white">{t[view] || view}</h1>
              <p className="text-[var(--muted)] text-sm font-medium">{t.welcome}</p>
            </div>
            <div className="flex gap-4 no-print">
              {view === 'trades' && (
                <>
                  <label className="btn gap-2 cursor-pointer">
                    <Plus size={16} /> {t.importCSV}
                    <input type="file" accept=".csv" className="hidden" onChange={handleImportCSV} />
                  </label>
                  <button onClick={handleExportCSV} className="btn gap-2"><Download size={16} /> {t.exportCSV}</button>
                </>
              )}
              <button onClick={handleExportPDF} className="btn gap-2"><Download size={16} /> {t.exportPDF}</button>
              <button onClick={() => setIsModalOpen(true)} className="btn btn-primary gap-2"><Plus size={18} /> {t.newTrade}</button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {view === 'dashboard' && <Dashboard trades={trades} theme={theme} onAddTrade={() => setIsModalOpen(true)} settings={settings} setIsBrokerModalOpen={setIsBrokerModalOpen} isSyncing={isSyncing} onSync={() => handleConnectBroker(settings.broker?.provider || 'Broker')} t={t} />}
              {view === 'calendar' && <Calendar trades={trades} t={t} />}
              {view === 'trades' && <TradesList trades={trades} onDelete={deleteTrade} onSelect={setSelectedTrade} t={t} />}
              {view === 'journal' && <Journal entries={journalEntries} onAdd={handleAddJournalEntry} onDelete={deleteJournalEntry} t={t} />}
              {view === 'lab' && <BacktestingLab sessions={backtestSessions} onAddSession={handleAddBacktestSession} onDeleteSession={deleteBacktestSession} t={t} />}
              {view === 'settings' && <Settings settings={settings} onUpdate={setSettings} setIsBrokerModalOpen={setIsBrokerModalOpen} t={t} onExportBackup={handleExportBackup} onImportBackup={handleImportBackup} />}
              {view === 'admin' && userRole === 'admin' && <AdminView t={t} />}

            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Trade Detail Drawer */}
      <TradeDrawer trade={selectedTrade} onClose={() => setSelectedTrade(null)} theme={theme} onUpdate={handleUpdateTrade} t={t} />

      <BrokerModal 
        isOpen={isBrokerModalOpen} 
        onClose={() => setIsBrokerModalOpen(false)} 
        onConnect={handleConnectBroker} 
        isSyncing={isSyncing}
      />

      {/* Trade Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-[var(--surface)] border border-[var(--line)] w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl relative z-10 flex flex-col shadow-2xl"
            >
              <div className="p-8 border-b border-[var(--line)] flex justify-between items-center bg-[var(--surface)]/50 sticky top-0 backdrop-blur-md z-20">
                <div className="flex flex-col">
                  <h2 className="text-2xl font-black text-gradient">{t.logTrade}</h2>
                  <p className="text-[var(--muted)] text-xs font-bold uppercase tracking-widest">{t.newTradeEntry}</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 rounded-xl hover:bg-[var(--surface-hover)] text-[var(--muted)] hover:text-white transition-all">
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleAddTrade} className="p-10 flex flex-col gap-10">
                {/* Section: Execution */}
                <div className="flex flex-col gap-6">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]">
                      <Activity size={16} />
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]">{t.executionDetails}</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.date}</label>
                      <input name="date" type="date" className="input" defaultValue={new Date().toISOString().split('T')[0]} />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.time} (In)</label>
                      <input name="entryTime" type="time" className="input" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.time} (Out)</label>
                      <input name="exitTime" type="time" className="input" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.status}</label>
                      <select name="status" className="input">
                        <option value="WIN">TP (Win)</option>
                        <option value="LOSS">SL (Loss)</option>
                        <option value="BREAKEVEN">BE (Breakeven)</option>
                        <option value="PENDING">Pending</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Section: Asset & Source */}
                <div className="flex flex-col gap-6">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[var(--brand2)]/10 flex items-center justify-center text-[var(--brand2)]">
                      <Filter size={16} />
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]">{t.assetSource}</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.symbol}</label>
                      <select name="symbol" className="input">
                        <option value="EURUSD">EURUSD</option>
                        <option value="GBPUSD">GBPUSD</option>
                        <option value="USDJPY">USDJPY</option>
                        <option value="XAUUSD">XAUUSD</option>
                        <option value="BTCUSD">BTCUSD</option>
                      </select>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">Prop Firm</label>
                      <select name="propFirm" className="input">
                        <option value="">(None)</option>
                        <option value="FTMO">FTMO</option>
                        <option value="MFF">MFF</option>
                      </select>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">Source</label>
                      <select name="source" className="input">
                        <option value="Journal">Journal</option>
                        <option value="Telegram">Telegram</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Section: Position Parameters */}
                <div className="flex flex-col gap-6">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[var(--ok)]/10 flex items-center justify-center text-[var(--ok)]">
                      <TrendingUp size={16} />
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]">{t.positionParameters}</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.orderType}</label>
                      <select name="orderType" className="input">
                        <option value="Manuel">{t.manual}</option>
                        <option value="Limit">{t.limit}</option>
                      </select>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.direction}</label>
                      <select name="type" className="input">
                        <option value="BUY">{t.long}</option>
                        <option value="SELL">{t.short}</option>
                      </select>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.entryPrice}</label>
                      <input name="entryPrice" type="number" step="0.00001" className="input" placeholder="0.00000" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.exitPrice}</label>
                      <input name="exitPrice" type="number" step="0.00001" className="input" placeholder="0.00000" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.stopLoss}</label>
                      <input name="stopLoss" type="number" step="0.00001" className="input" placeholder="0.00000" />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.takeProfit}</label>
                      <input name="takeProfit" type="number" step="0.00001" className="input" placeholder="0.00000" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.rMultiple}</label>
                      <input name="rMultiple" type="number" step="0.1" className="input" defaultValue="1" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.risk} (%)</label>
                      <input name="riskPercent" type="number" step="0.1" className="input" placeholder="0.5" />
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.setup}</label>
                      <select name="setup" className="input">
                        <option value="">---</option>
                        <option value="Breakout">Breakout</option>
                        <option value="Retracement">Retracement</option>
                      </select>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.rating}</label>
                      <select name="rating" className="input">
                        <option value="">---</option>
                        <option value="A+">A+</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                        <option value="F">F</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Section: Psychology & Notes */}
                <div className="flex flex-col gap-6">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[var(--brand)]/10 flex items-center justify-center text-[var(--brand)]">
                      <BookOpen size={16} />
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]">{t.psychologyNotes}</h3>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.emotionBefore}</label>
                      <select name="emotionBefore" className="input">
                        <option value="">---</option>
                        <option value="Calme">{t.calm}</option>
                        <option value="Anxieux">{t.anxious}</option>
                        <option value="Euphorique">{t.euphoric}</option>
                      </select>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.emotionAfter}</label>
                      <select name="emotionAfter" className="input">
                        <option value="">---</option>
                        <option value="Calme">{t.calm}</option>
                        <option value="Frustré">{t.frustrated}</option>
                        <option value="Satisfait">Satisfait</option>
                      </select>
                    </div>
                    <div className="flex flex-col gap-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">P&L (€)</label>
                      <input name="pnl" type="number" step="0.01" className="input" placeholder="0.00" />
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.notes}</label>
                    <textarea name="notes" placeholder="Describe your setup, context, and mistakes..." className="input min-h-[120px]" />
                  </div>
                </div>

                <div className="flex flex-col gap-6">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[var(--muted)]/10 flex items-center justify-center text-[var(--muted)]">
                      <Download size={16} />
                    </div>
                    <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[var(--muted)]">{t.screenshot}</h3>
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-[var(--muted)] ml-1">{t.screenshotUrl}</label>
                    <input name="screenshotUrl" type="text" className="input" placeholder="https://tradingview.com/x/..." />
                  </div>
                </div>

                <div className="flex gap-4 pt-6 border-t border-[var(--line)]">
                  <button type="button" onClick={() => setIsModalOpen(false)} className="btn flex-1 py-4 rounded-2xl uppercase tracking-widest text-xs font-black">{t.cancel}</button>
                  <button type="submit" className="btn btn-primary flex-1 py-4 rounded-2xl uppercase tracking-widest text-xs font-black">{t.saveTrade}</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
